
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.ORKFramework;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class StatusDevelopmentsTab : ORKGenericAssetListTab<StatusDevelopmentAsset, StatusDevelopment>
	{
		private bool editLevels = false;

		private int minLevel = 1;

		private int maxLevel = 1;

		public StatusDevelopmentsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Status Developments"; }
		}

		public override string HelpText
		{
			get
			{
				return "Status developments are used by combatants and classes to define how status values change by level ups.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/status-values/"; }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		public override void ShowTab()
		{
			int tmpIndex = this.index;
			base.ShowTab();

			if(this.editLevels && tmpIndex != this.index)
			{
				if(this.assetList.AssetExists(this.index))
				{
					StatusDevelopment development = this.CurrentSettings;
					if(development != null)
					{
						development.minLevel = this.minLevel;
						development.maxLevel = this.maxLevel;
					}
				}
				this.editLevels = false;
			}
		}

		public override void AutomationCallback(string info)
		{
			if(info == "textcodes:name")
			{
				EditorGUILayout.HelpBox("<name> = original name",
					 MessageType.Info, true);
			}
			else if(info == "textcodes:shortname")
			{
				EditorGUILayout.HelpBox("<shortname> = original short name",
					 MessageType.Info, true);
			}
			else if(info == "textcodes:description")
			{
				EditorGUILayout.HelpBox("<description> = original description",
					 MessageType.Info, true);
			}
			else if(info == "edit:minmaxlevel")
			{
				StatusDevelopment development = this.CurrentSettings;
				if(development != null)
				{
					EditorGUILayout.Separator();
					EditorTool.BoldLabel("Level Range");

					if(this.editLevels)
					{
						EditorAutomation.Automate("minLevel", development, this, true);
						EditorAutomation.Automate("maxLevel", development, this, true);

						EditorGUILayout.BeginHorizontal();
						if(EditorTool.SmallButton("Cancel", "Cancel editing the level range, all changes will be lost.", ""))
						{
							this.editLevels = false;
							development.minLevel = this.minLevel;
							development.maxLevel = this.maxLevel;
						}
						if(EditorTool.SmallButton("Ok", "End editing the level range and accept the changes.", ""))
						{
							this.editLevels = false;
							development.MaxLevelChanged();
							EditorDataHelper.StatusDevelopmentLevels(development);
						}
						GUILayout.FlexibleSpace();
						EditorGUILayout.EndHorizontal();
					}
					else
					{
						EditorTool.Label("Minimum Level: " + development.minLevel);
						EditorTool.Label("Maximum Level: " + development.maxLevel);

						if(EditorTool.Button(new GUIContent("Edit Level Range", EditorContent.Instance.EditIcon),
							"Change the minimum and maximum levels of this status development.", ""))
						{
							this.editLevels = true;
							this.minLevel = development.minLevel;
							this.maxLevel = development.maxLevel;
						}
					}
				}
			}
			else if(info == "edit:percentcurve")
			{
				StatusDevelopment development = this.CurrentSettings;
				if(development != null)
				{
					float total = 0;
					for(int i = 0; i < development.statusValue.Length; i++)
					{
						if(development.statusValue[i] != null &&
							StatDevType.Percent == development.statusValue[i].type)
						{
							total += development.statusValue[i].percentValue;
						}
					}
					EditorGUILayout.LabelField("Total Points Used", total.ToString("0.0") + "%");

					if(development.usePercentCurve)
					{
						if(development.percentLevelValue == null)
						{
							development.percentLevelValue = LearnStatusValue.InitCurve(
								1 + development.maxLevel - development.minLevel,
								10, 1000);
						}
						if(EditorTool.MediumButton(new GUIContent("Edit Curve", EditorContent.Instance.EditIcon),
							"Open the percent points development curve.\n" +
							"Confirm changes by clicking on the 'Ok' button.", ""))
						{
							this.parent.ShowCustomFullView(new StatusDevelopmentEditor(this.parent,
								"Percent Points", null, development.minLevel, ref development.percentLevelValue));
						}
						EditorGUILayout.LabelField("Level " + development.minLevel, development.percentLevelValue[0].ToString());
						EditorGUILayout.LabelField("Level " + (development.percentLevelValue.Length + development.minLevel - 1),
							development.percentLevelValue[development.percentLevelValue.Length - 1].ToString());
					}
					else if(development.percentLevelValue != null)
					{
						development.percentLevelValue = null;
					}
				}
			}
			else if(info == "button:addall")
			{
				StatusDevelopment development = this.CurrentSettings;
				if(development != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set Default", EditorContent.Instance.AddIcon),
						"Sets the value development to all 'Normal' and 'Experience' type status values.", "",
						EditorTool.WIDTH_150))
					{
						List<LearnStatusValue> learnValues = new List<LearnStatusValue>();
						GenericAssetList<StatusValueAsset> statusValues = EditorDataHandler.Instance.GetAssets<StatusValueAsset>();
						for(int i = 0; i < statusValues.Count; i++)
						{
							if(StatusValueType.Normal == statusValues.Assets[i].Settings.type ||
								StatusValueType.Experience == statusValues.Assets[i].Settings.type)
							{
								LearnStatusValue newValue = new LearnStatusValue();
								newValue.status.Source.EditorAsset = statusValues.Assets[i];
								learnValues.Add(newValue);
							}
						}
						development.statusValue = learnValues.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all value developments.", "",
						EditorTool.WIDTH_150))
					{
						development.statusValue = new LearnStatusValue[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}

		public override void InstanceCallback(string info, object instance)
		{
			if(info == "edit:statusvaluecurve")
			{
				LearnStatusValue status = instance as LearnStatusValue;

				StatusDevelopment development = this.CurrentSettings;
				if(development != null &&
					status != null)
				{
					if(StatDevType.Curve == status.type)
					{
						if(status.status.StoredAsset != null)
						{
							if(status.levelValue == null)
							{
								StatusValueSetting value = status.status.StoredAsset.Settings;
								status.levelValue = LearnStatusValue.InitCurve(
									1 + development.maxLevel - development.minLevel,
									value.minValue, value.maxValue);
							}
							if(status.levelValue != null &&
								status.levelValue.Length > 1)
							{
								int minLvl = development.minLevel;
								EditorGUILayout.HelpBox(
									"Level " + minLevel + ": " + status.levelValue[0] + "\n" +
									"Level " + (status.levelValue.Length + minLvl - 1) + ": " + status.levelValue[status.levelValue.Length - 1],
									MessageType.Info);

								if(EditorTool.MediumButton(new GUIContent("Edit Curve", EditorContent.Instance.EditIcon),
									"Open the status value development curve.\n" +
									"Confirm changes by clicking on the 'Ok' button.", ""))
								{
									this.parent.ShowCustomFullView(new StatusDevelopmentEditor(this.parent,
										status.status.StoredAsset.Settings.GetName(), status.status.StoredAsset.Settings,
										minLvl, ref status.levelValue));
								}
							}
						}
					}
					else
					{
						status.levelValue = null;
					}
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}
	}
}

