
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class AttackModifiersTab : ORKGenericAssetListTab<AttackModifierAsset, AttackModifierSetting>
	{
		public AttackModifiersTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.AttackModifiers.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.AttackModifiers.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Attack Modifiers"; }
		}

		public override string HelpText
		{
			get
			{
				return "Attack modifiers are used to influence status value changes on a percent-basis, they're assigned to attacks.\n" +
					"E.g. Elements like fire or wind are attack modifiers, they're assigned to an attack's status value change and use the target's modifier value.\n" +
					"'Element' would be the attack modifier, 'Fire' or 'Wind' are attributes of that modifier.\n" +
					"The attribute can be assigned to status value changes of abilities or items to influence the value.\n" +
					"The target's attack modifier attribute value impacts the outcome, " +
					"e.g. 100 will do 100% of the original damage, 200 will do 200% (i.e. double damage), 50 will do 50% damage (i.e. half damage).\n" +
					"0 will completely block the damage, while anything below 0 will actually cause damage to heal (or healing to damage) the target.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/attack-defence-modifiers/"; }
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			base.ShowSettings();

			AttackModifierSetting modifier = this.CurrentSettings;
			if(modifier != null)
			{
				for(int i = 0; i < modifier.attribute.Length; i++)
				{
					ValueHelper.Limit(ref modifier.attribute[i].startValue, modifier.minValue, modifier.maxValue);
				}
			}
		}

		public override void AutomationRemoveCallback(int arrayIndex, string info)
		{
			if(info == "modifier:removed")
			{
				if(this.assetList.AssetExists(this.index))
				{
					AttackModifierAsset asset = this.assetList.Assets[this.index];
					EditorDataHandler.Instance.SubDataRemoved(asset.GetType(), asset, arrayIndex);
				}
			}
			else
			{
				base.AutomationRemoveCallback(arrayIndex, info);
			}
		}
	}
}

