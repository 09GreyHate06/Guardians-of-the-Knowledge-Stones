
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.UI;
using GamingIsLove.ORKFramework.UI.Parts;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class MenuScreensTab : ORKGenericAssetListTab<MenuScreenAsset, MenuScreen>
	{
		private EditorSortedSettingInfo parts;

		private GeneralPopupSelectionButton topButton = new GeneralPopupSelectionButton();

		private GeneralPopupSelectionButton bottomButton = new GeneralPopupSelectionButton();

		public MenuScreensTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.MenuScreens.SetAssets(this.assetList.Assets);

			this.parts = EditorAttributes.GetSettingInfos(typeof(BaseMenuPart));
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Menu Screens"; }
		}

		public override string HelpText
		{
			get
			{
				return "Menu screens are used to display information, use items, abilities and other management things.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/ui-system/menu-screens/"; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings regarding menu screens.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.MenuScreens; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.MenuScreens;
				}
				return base.DisplayedSettings;
			}
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "button:menupartsbefore" ||
				info == "button:menupartsafter")
			{
				if(this.foldoutLimit == "")
				{
					MenuScreen screen = this.CurrentSettings;
					if(screen != null)
					{
						if(info == "button:menupartsbefore")
						{
							this.topButton.Show(new GUIContent("Add Menu Part", EditorContent.Instance.AddIcon),
								"Adds a menu part to this menu screen.", "",
								this.parts.names, this.parts.descriptions, "MenuScreenParts", "Menu Screen Part",
								this.SelectIndex, this.PopupClosed, this);
							if(screen.part.Length == 0)
							{
								EditorTool.Separator(3);
							}
						}
						else if(info == "button:menupartsafter" && screen.part.Length > 0)
						{
							this.bottomButton.Show(new GUIContent("Add Menu Part", EditorContent.Instance.AddIcon),
								"Adds a menu part to this menu screen.", "",
								this.parts.names, this.parts.descriptions, "MenuScreenParts", "Menu Screen Part",
								this.SelectIndex, this.PopupClosed, this);
							EditorTool.Separator(3);
						}
					}
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}

		private void SelectIndex(int index)
		{
			if(this.parts != null &&
				index >= 0 &&
				index < this.parts.Count)
			{
				System.Type type = this.parts.GetType(index);
				if(type != null)
				{
					MenuScreen screen = this.CurrentSettings;
					if(screen != null)
					{
						ArrayHelper.Add(ref screen.part,
							ReflectionTypeHandler.Instance.CreateInstance(type) as BaseMenuPart);
						this.scrollToFoldout = this.parts.names[index] + " " + (screen.part.Length - 1);
						this.Repaint();
					}
				}
			}
		}

		private void PopupClosed()
		{
			this.parent.Focus();
		}
	}
}
