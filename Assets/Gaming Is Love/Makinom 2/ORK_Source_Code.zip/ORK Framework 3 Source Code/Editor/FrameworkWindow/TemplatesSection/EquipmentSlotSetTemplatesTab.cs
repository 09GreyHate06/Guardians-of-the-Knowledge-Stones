﻿
using UnityEditor;
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	public class EquipmentSlotSetTemplatesTab : ORKGenericAssetListTab<EquipmentSlotSetTemplateAsset, EquipmentSlotSetTemplate>
	{
		public EquipmentSlotSetTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Equipment Slot Set Templates"; }
		}

		public override string HelpText
		{
			get
			{
				return "Equipment slot sets are used by equipment to define on which equipment slots it can be equipped.\n" +
					"Use the templates for easier setup and quick editing of multiple equipment's slot setup.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/equipment/"; }
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void InstanceCallback(string info, object instance)
		{
			if(info == "button:equipableon")
			{
				EquipableOn setting = instance as EquipableOn;
				if(setting != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						List<AssetSelection<EquipmentSlotAsset>> list = new List<AssetSelection<EquipmentSlotAsset>>();
						GenericAssetList<EquipmentSlotAsset> equipmentSlots = EditorDataHandler.Instance.GetAssets<EquipmentSlotAsset>();
						for(int i = 0; i < equipmentSlots.Count; i++)
						{
							AssetSelection<EquipmentSlotAsset> newSlot = new AssetSelection<EquipmentSlotAsset>();
							newSlot.Source.EditorAsset = equipmentSlots.Assets[i];
							list.Add(newSlot);
						}
						setting.equipSlot = list.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						setting.equipSlot = new AssetSelection<EquipmentSlotAsset>[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else if(info == "button:blockslot")
			{
				EquipableOn setting = instance as EquipableOn;
				if(setting != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						List<AssetSelection<EquipmentSlotAsset>> list = new List<AssetSelection<EquipmentSlotAsset>>();
						GenericAssetList<EquipmentSlotAsset> equipmentSlots = EditorDataHandler.Instance.GetAssets<EquipmentSlotAsset>();
						for(int i = 0; i < equipmentSlots.Count; i++)
						{
							AssetSelection<EquipmentSlotAsset> newSlot = new AssetSelection<EquipmentSlotAsset>();
							newSlot.Source.EditorAsset = equipmentSlots.Assets[i];
							list.Add(newSlot);
						}
						setting.blockSlot = list.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						setting.blockSlot = new AssetSelection<EquipmentSlotAsset>[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else if(info == "button:blockviewer")
			{
				EquipableOn setting = instance as EquipableOn;
				if(setting != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						List<AssetSelection<EquipmentSlotAsset>> list = new List<AssetSelection<EquipmentSlotAsset>>();
						GenericAssetList<EquipmentSlotAsset> equipmentSlots = EditorDataHandler.Instance.GetAssets<EquipmentSlotAsset>();
						for(int i = 0; i < equipmentSlots.Count; i++)
						{
							AssetSelection<EquipmentSlotAsset> newSlot = new AssetSelection<EquipmentSlotAsset>();
							newSlot.Source.EditorAsset = equipmentSlots.Assets[i];
							list.Add(newSlot);
						}
						setting.blockViewer = list.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						setting.blockViewer = new AssetSelection<EquipmentSlotAsset>[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}
	}
}

