
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class CombatantsTab : ORKGenericAssetListTab<CombatantAsset, CombatantSetting>
	{
		public CombatantsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Combatants.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Combatants.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Combatants"; }
		}

		public override string HelpText
		{
			get
			{
				return "Combatants are the basis of ORK's status system and needed to take part in battles.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/combatants/"; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up default combatant settings that are used by all combatants.\n" +
					"Individual combatants can override these settings.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.Combatants; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.Combatants;
				}
				return base.DisplayedSettings;
			}
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			base.ShowSettings();

			if(Event.current.type == EventType.Repaint)
			{
				CombatantSetting combatant = this.CurrentSettings;
				if(combatant != null)
				{
					if(combatant.HasStatusDevelopment)
					{
						combatant.statusDevelopment.StoredAsset.Settings.AdjustLevel(ref combatant.startLevel);
					}

					AvailableEquipment availableEquipment = combatant.availableEquipment.Get();
					for(int i = 0; i < combatant.startEquipment.Length; i++)
					{
						int prevLvl = 0;
						if(i > 0)
						{
							prevLvl = combatant.startEquipment[i - 1].maxLevel;
						}
						combatant.startEquipment[i].CheckEquipment(availableEquipment, prevLvl);
					}
				}
			}
		}

		public override void AutomationCallback(string info)
		{
			if(info == "textcodes:description")
			{
				EditorGUILayout.HelpBox("<bonus> = bonuses\n" +
					"<name> = name, <shortname> = short name, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
					"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
					"Class:\n" +
					"<classname> = name, <classshortname> = short name, <classdescription> = description, <classicon> = icon, <classcustomcontent=KEY> = custom content 'KEY'\n" +
					"<level> = level, <classlevel> = class level",
					MessageType.Info, true);
			}
			else if(info == "textcodes:customcontent")
			{
				EditorGUILayout.HelpBox("<bonus> = bonuses\n" +
					"<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
					"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
					"Class:\n" +
					"<classname> = name, <classshortname> = short name, <classdescription> = description, <classicon> = icon, <classcustomcontent=KEY> = custom content 'KEY'\n" +
					"<level> = level, <classlevel> = class level",
					MessageType.Info, true);
			}
			else if(info == "button:startvalues")
			{
				CombatantSetting combatant = this.CurrentSettings;
				if(combatant != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set Default", EditorContent.Instance.AddIcon),
						"Sets the start values to all 'Normal' type status values and their default start values.", "",
						EditorTool.WIDTH_150))
					{
						List<StartStatusValue> startValues = new List<StartStatusValue>();
						GenericAssetList<StatusValueAsset> statusValues = EditorDataHandler.Instance.GetAssets<StatusValueAsset>();
						for(int i = 0; i < statusValues.Count; i++)
						{
							if(StatusValueType.Normal == statusValues.Assets[i].Settings.type)
							{
								StartStatusValue newValue = new StartStatusValue();
								newValue.status.Source.EditorAsset = statusValues.Assets[i];
								newValue.startValue = statusValues.Assets[i].Settings.startValue;
								newValue.setIn = statusValues.Assets[i].Settings.startSetIn;
								newValue.rounding = statusValues.Assets[i].Settings.startRounding;
								startValues.Add(newValue);
							}
						}
						combatant.startValue = startValues.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all start values.", "",
						EditorTool.WIDTH_150))
					{
						combatant.startValue = new StartStatusValue[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else if(info == "button:defencemodifierids")
			{
				CombatantSetting combatant = this.CurrentSettings;
				if(combatant != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all defence modifiers using their first attribute.", "",
						EditorTool.WIDTH_150))
					{
						List<DefenceModifierAttributeSelection> defIDs = new List<DefenceModifierAttributeSelection>();
						GenericAssetList<DefenceModifierAsset> modifiers = EditorDataHandler.Instance.GetAssets<DefenceModifierAsset>();
						for(int i = 0; i < modifiers.Count; i++)
						{
							DefenceModifierAttributeSelection newID = new DefenceModifierAttributeSelection();
							newID.modifier.Source.EditorAsset = modifiers.Assets[i];
							newID.index = 0;
							defIDs.Add(newID);
						}
						combatant.defenceModifierID = defIDs.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all defence modifier IDs.", "",
						EditorTool.WIDTH_150))
					{
						combatant.defenceModifierID = new DefenceModifierAttributeSelection[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else if(info == "button:attackmodifierstartvalues")
			{
				CombatantSetting combatant = this.CurrentSettings;
				if(combatant != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all attack modifier attributes with their default start value.", "",
						EditorTool.WIDTH_150))
					{
						List<AttackModifierStartValue> startValues = new List<AttackModifierStartValue>();
						GenericAssetList<AttackModifierAsset> modifiers = EditorDataHandler.Instance.GetAssets<AttackModifierAsset>();
						for(int i = 0; i < modifiers.Count; i++)
						{
							for(int j = 0; j < modifiers.Assets[i].Settings.attribute.Length; j++)
							{
								AttackModifierStartValue newValue = new AttackModifierStartValue();
								newValue.modifier.modifier.Source.EditorAsset = modifiers.Assets[i];
								newValue.modifier.index = j;
								newValue.startValue = modifiers.Assets[i].Settings.attribute[j].startValue;
								startValues.Add(newValue);
							}
						}
						combatant.attackModifierStart = startValues.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all attack modifier start values.", "",
						EditorTool.WIDTH_150))
					{
						combatant.attackModifierStart = new AttackModifierStartValue[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else if(info == "button:defencemodifierstartvalues")
			{
				CombatantSetting combatant = this.CurrentSettings;
				if(combatant != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all defence modifier attributes with their default start value.", "",
						EditorTool.WIDTH_150))
					{
						List<DefenceModifierStartValue> startValues = new List<DefenceModifierStartValue>();
						GenericAssetList<DefenceModifierAsset> modifiers = EditorDataHandler.Instance.GetAssets<DefenceModifierAsset>();
						for(int i = 0; i < modifiers.Count; i++)
						{
							for(int j = 0; j < modifiers.Assets[i].Settings.attribute.Length; j++)
							{
								DefenceModifierStartValue newValue = new DefenceModifierStartValue();
								newValue.modifier.modifier.Source.EditorAsset = modifiers.Assets[i];
								newValue.modifier.index = j;
								newValue.startValue = modifiers.Assets[i].Settings.attribute[j].startValue;
								startValues.Add(newValue);
							}
						}
						combatant.defenceModifierStart = startValues.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all attack modifier start values.", "",
						EditorTool.WIDTH_150))
					{
						combatant.defenceModifierStart = new DefenceModifierStartValue[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}

		public override void InstanceCallback(string info, object instance)
		{
			if(info == "button:startequip")
			{
				CombatantSetting combatant = this.CurrentSettings;
				if(combatant != null)
				{
					EditorGUILayout.Separator();

					AvailableEquipment availableEquipment = combatant.availableEquipment.Get();
					if(availableEquipment == null ||
						(!availableEquipment.allSlots &&
							availableEquipment.equipSlot.Length == 0))
					{
						EditorGUILayout.HelpBox("No available equipment slots set up (class or own equipment).",
							MessageType.Error);
					}
					else
					{
						StartEquipment setting = instance as StartEquipment;
						if(setting != null)
						{
							EditorGUILayout.BeginHorizontal();
							if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
								"Sets up all equipment slots.", "",
								EditorTool.WIDTH_150))
							{
								List<StartEquipmentSlot> slots = new List<StartEquipmentSlot>();
								if(availableEquipment.allSlots)
								{
									GenericAssetList<EquipmentSlotAsset> equipmentSlots = EditorDataHandler.Instance.GetAssets<EquipmentSlotAsset>();
									for(int i = 0; i < equipmentSlots.Count; i++)
									{
										StartEquipmentSlot newSlot = new StartEquipmentSlot();
										newSlot.equipSlot.Source.EditorAsset = equipmentSlots.Assets[i];
										slots.Add(newSlot);
									}
								}
								else
								{
									for(int i = 0; i < availableEquipment.equipSlot.Length; i++)
									{
										if(availableEquipment.equipSlot[i].Source.EditorAsset != null)
										{
											StartEquipmentSlot newSlot = new StartEquipmentSlot();
											newSlot.equipSlot.SetData(availableEquipment.equipSlot[i].GetData());
											slots.Add(newSlot);
										}
									}
								}
								setting.equipment = slots.ToArray();
							}
							if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
								"Removes all equipment slots.", "",
								EditorTool.WIDTH_150))
							{
								setting.equipment = new StartEquipmentSlot[0];
							}
							GUILayout.FlexibleSpace();
							EditorGUILayout.EndHorizontal();
						}
					}
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<CombatantTypeAsset, CombatantType>(
							new string[] { "Combatant Type", "Filter the combatant list by combatant type.", "" }),
						new FilteredListAssetSelection<ClassAsset, Class>(
							new string[] { "Class", "Filter the combatant list by start class.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[1].Check(
				this.assetList.Assets[index].Settings.startClass.Source.EditorAsset))
			{
				if(this.Filter.assetFilterSelection[0].UseFilter)
				{
					CombatantType type = this.Filter.assetFilterSelection[0].Selection as CombatantType;
					return this.assetList.Assets[index].Settings.IsType(type, false);
				}
				return true;
			}
			return false;
		}
	}
}
