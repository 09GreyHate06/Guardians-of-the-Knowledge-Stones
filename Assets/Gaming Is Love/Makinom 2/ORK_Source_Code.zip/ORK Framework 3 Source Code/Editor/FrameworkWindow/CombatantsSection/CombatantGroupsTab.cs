
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class CombatantGroupsTab : ORKGenericAssetListTab<CombatantGroupAsset, CombatantGroup>
	{
		public CombatantGroupsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Combatant Groups"; }
		}

		public override string HelpText
		{
			get
			{
				return "Combatant groups are used to create groups of combatants (i.e. group templates) that can be used by battles.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/combatants/"; }
		}
	}
}

