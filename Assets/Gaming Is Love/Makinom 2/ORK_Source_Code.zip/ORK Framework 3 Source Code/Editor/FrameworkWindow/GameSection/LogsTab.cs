
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class LogsTab : ORKGenericAssetListTab<LogAsset, Log>
	{
		public LogsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Logs.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Logs.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Logs"; }
		}

		public override string HelpText
		{
			get
			{
				return "Logs are used to make information available to the player (e.g. via a menu screen).";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/logs/"; }
		}

		public override void ShowSettings()
		{
			base.ShowSettings();

			if(this.assetList.AssetExists(this.index))
			{
				Log log = this.DisplayedSettings as Log;

				if(log != null)
				{
					if(this.BeginFoldout("Log Text List", "Displays all log texts assigned to this log.", "", true))
					{
						GenericAssetList<LogTextAsset> assetList = EditorDataHandler.Instance.GetAssets<LogTextAsset>();
						if(EditorTool.Button(new GUIContent("Add Log Text", EditorContent.Instance.AddIcon),
							"Add a new log text to this log.", ""))
						{
							LogTextAsset asset = ScriptableObject.CreateInstance<LogTextAsset>();
							asset.Settings = new LogText("New");
							asset.Settings.log.Source.EditorAsset = this.assetList.Assets[this.index];
							assetList.Add(asset);
						}

						List<LogTextAsset> logTexts = ORK.LogTexts.GetLogTexts(log);

						for(int i = 0; i < logTexts.Count; i++)
						{
							EditorGUILayout.BeginHorizontal();

							if(EditorTool.SmallButton(new GUIContent("Edit", EditorContent.Instance.EditIcon),
								"Edit this log text.", ""))
							{
								this.parent.EditSetting(typeof(LogTextAsset), logTexts[i]);
							}
							EditorGUILayout.Separator();
							EditorTool.Label(logTexts[i].Settings.name);

							GUILayout.FlexibleSpace();
							EditorGUILayout.EndHorizontal();
							EditorGUILayout.Separator();
						}
					}
					this.EndFoldout();
				}
			}
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<LogTypeAsset, LogType>(
							new string[] { "Log Type", "Filter the log list by log type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[0].UseFilter)
			{
				LogType type = this.Filter.assetFilterSelection[0].Selection as LogType;
				return this.assetList.Assets[index].Settings.IsType(type, false);
			}
			return true;
		}
	}
}
