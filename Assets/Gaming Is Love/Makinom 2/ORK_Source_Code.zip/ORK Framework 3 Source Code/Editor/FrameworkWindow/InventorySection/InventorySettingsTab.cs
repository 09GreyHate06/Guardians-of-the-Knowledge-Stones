
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class InventorySettingsTab : ORKBaseEditorTab
	{
		public InventorySettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Inventory Settings"; }
		}

		public override string HelpText
		{
			get { return "Set up how the inventory will be handled, default inventory notifications and more."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/inventory-system-overview/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.InventorySettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.InventorySettings; }
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			base.ShowSettings();

			for(int i = 1; i < ORK.InventorySettings.fullStatusEffect.Length; i++)
			{
				if(ORK.InventorySettings.fullStatusEffect[i].percent <= ORK.InventorySettings.fullStatusEffect[i - 1].percent)
				{
					ORK.InventorySettings.fullStatusEffect[i].percent = ORK.InventorySettings.fullStatusEffect[i - 1].percent + 1;
				}
			}
		}

		public override void AutomationCallback(string info)
		{
			if(info == "label:exchangemenu")
			{
				if(ORK.InventorySettings.itemBoxCollection.useInventoryExchangeMenu &&
					ORK.InventorySettings.itemBoxCollection.menuScreen.StoredAsset != null &&
					!ORK.InventorySettings.itemBoxCollection.menuScreen.StoredAsset.Settings.IsInventoryExchange())
				{
					EditorGUILayout.HelpBox("The selected menu screen doesn't contain an 'Inventory Exchange' menu part.\n" +
						"The menu screen will not be displayed.",
						MessageType.Error);
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}
