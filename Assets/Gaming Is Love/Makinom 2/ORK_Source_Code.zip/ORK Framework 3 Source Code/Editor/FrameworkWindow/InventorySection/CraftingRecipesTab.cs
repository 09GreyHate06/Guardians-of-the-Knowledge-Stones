
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class CraftingRecipesTab : ORKGenericAssetListTab<CraftingRecipeAsset, CraftingRecipe>
	{
		public CraftingRecipesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.CraftingRecipes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.CraftingRecipes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Crafting Recipes"; }
		}

		public override string HelpText
		{
			get
			{
				return "Crafting recipes are used to create items from a list of ingredients.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/crafting-recipes/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<CraftingTypeAsset, CraftingType>(
							new string[] { "Crafting Type", "Filter the crafting recipe list by crafting type.", "" }),
						new FilteredListAssetSelection<ItemTypeAsset, ItemType>(
							new string[] { "Item Type", "Filter the crafting recipe list by item type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[0].UseFilter)
			{
				CraftingType type = this.Filter.assetFilterSelection[0].Selection as CraftingType;
				if(this.assetList.Assets[index].Settings.IsType(type, false))
				{
					if(this.Filter.assetFilterSelection[1].UseFilter)
					{
						ItemType type2 = this.Filter.assetFilterSelection[1].Selection as ItemType;
						return this.assetList.Assets[index].Settings.IsItemType(type2, false);
					}
					return true;
				}
				return false;
			}
			else if(this.Filter.assetFilterSelection[1].UseFilter)
			{
				ItemType type = this.Filter.assetFilterSelection[1].Selection as ItemType;
				return this.assetList.Assets[index].Settings.IsItemType(type, false);
			}
			return true;
		}
	}
}
