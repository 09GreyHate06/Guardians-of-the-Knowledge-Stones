﻿
using GamingIsLove.ORKFramework.AI;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class AITypesTab : ORKGenericAssetListTab<AITypeAsset, AIType>
	{
		public AITypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.AITypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.AITypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "AI Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "AI types are used to separate AI behaviours and AI rulesets.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/ai-behaviours-rulesets/"; }
		}
	}
}

