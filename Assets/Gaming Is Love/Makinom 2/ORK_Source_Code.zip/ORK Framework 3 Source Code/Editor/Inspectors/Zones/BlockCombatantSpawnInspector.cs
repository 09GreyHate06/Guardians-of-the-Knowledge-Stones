﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(BlockCombatantSpawn))]
public class BlockCombatantSpawnInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as BlockCombatantSpawn);
	}

	protected virtual void ComponentSetup(BlockCombatantSpawn target)
	{
		Undo.RecordObject(target, "Change to 'Block Combatant Spawn' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}