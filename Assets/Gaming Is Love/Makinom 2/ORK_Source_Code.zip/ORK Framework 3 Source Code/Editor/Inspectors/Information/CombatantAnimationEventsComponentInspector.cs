﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(CombatantAnimationEventsComponent))]
public class CombatantAnimationEventsComponentInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		EditorGUILayout.HelpBox("Allows using damage-related functions in animation events.", MessageType.Info);

		this.ShowInfo("CalculateCurrentAction", "", 
			"Calculates the combatant’s current action outcome.\n" +
			"Same as using a 'Calculate Action' node.");

		this.ShowInfo("CalculateCurrentAction", "(float damageFactor)",
			"Calculates the combatant’s current action outcome with the provided damage factor.\n" +
			"Same as using a 'Calculate Action' node.");

		this.ShowInfo("ActivateDamageDealers", "",
			"Activates all 'Damage Dealer' components on the combatant.\n" +
			"The damage dealers need to have an action set before activation " +
			"(e.g.via 'Set Damage Dealer Action' node used in a schematic animating an ability or item).");

		this.ShowInfo("DeactivateDamageDealers", "", 
			"Deactivates all 'Damage Dealer' components on the combatant.");

		this.ShowInfo("CurrentActionActivateDamageDealers", "",
			"Activates all 'Damage Dealer' components of the combatant’s current action (have to be set up for auto activation).");

		this.ShowInfo("CurrentActionDeactivateDamageDealers", "",
			"Deactivates all 'Damage Dealer' components of the combatant’s current action (have to be set up for auto activation).");
	}

	protected virtual void ShowInfo(string name, string parameters, string description)
	{
		EditorGUILayout.Separator();
		EditorTool.BoldLabel(name + parameters);
		EditorGUILayout.HelpBox(description, MessageType.Info);
		if(GUILayout.Button(new GUIContent("Copy to Clipboard", EditorContent.Instance.CopyToClipboardIcon, "Copy the function's name to the clipboard.")))
		{
			EditorGUIUtility.systemCopyBuffer = name;
		}
	}
}
