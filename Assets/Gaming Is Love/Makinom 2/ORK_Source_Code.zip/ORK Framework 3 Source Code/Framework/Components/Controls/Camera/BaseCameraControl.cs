
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("")]
	public abstract class BaseCameraControl : MonoBehaviour
	{
		protected GameObject cameraTarget;


		// transition
		protected CameraControlTargetTransition targetTransition;

		protected float transitionTime = -1;

		public virtual bool UseUnscaledTime
		{
			get { return false; }
		}

		public virtual float DeltaTime
		{
			get { return this.UseUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime; }
		}

		protected virtual void OnDestroy()
		{
			Maki.Control.RemoveCameraControl(this);
		}

		public virtual GameObject CameraTarget
		{
			get
			{
				if(this.cameraTarget == null)
				{
					return ORK.Game.GetPlayer();
				}
				else
				{
					return this.cameraTarget;
				}
			}
		}

		public virtual void SetCameraControlTarget(GameObject target, CameraControlTargetTransition transition)
		{
			GameObject previousTarget = this.CameraTarget;
			if(previousTarget != target &&
				(this.cameraTarget != null || target != null))
			{
				this.cameraTarget = target;
				GameObject newTarget = this.CameraTarget;

				this.targetTransition = transition;

				if(newTarget != null &&
					this.CameraTargetTransition.enabled)
				{
					this.transitionTime = 0;
					this.CameraTargetTransition.StartTransition(this.transform,
						previousTarget != null ?
							VectorHelper.Distance(newTarget.transform.position,
								previousTarget.transform.position, AxisBool.IgnoreHeight) :
							1);
				}
				else
				{
					this.transitionTime = -1;
				}
				this.CameraTargetChanged(previousTarget, newTarget);
			}
		}

		public virtual void ResetCurrentCameraTarget(CameraControlTargetTransition transition)
		{
			GameObject target = this.CameraTarget;
			this.targetTransition = transition;

			if(target != null &&
				this.CameraTargetTransition.enabled)
			{
				this.transitionTime = 0;
				this.CameraTargetTransition.StartTransition(this.transform,
					VectorHelper.Distance(this.transform.position,
						target.transform.position, AxisBool.IgnoreHeight));
			}
			else
			{
				this.transitionTime = -1;
			}

			this.CameraTargetChanged(target, target);
		}

		public virtual void CameraTargetChanged(GameObject oldTarget, GameObject newTarget)
		{

		}

		public virtual void UpdatePosition(Vector3 position, Quaternion rotation)
		{
			if(this.IsCameraTargetTransition)
			{
				this.TransitionUpdate(position, rotation);
			}
			else
			{
				this.transform.SetPositionAndRotation(position, rotation);
			}
		}


		/*
		============================================================================
		Transition functions
		============================================================================
		*/
		public virtual CameraControlTargetTransition CameraTargetTransition
		{
			get
			{
				if(this.targetTransition != null)
				{
					return this.targetTransition;
				}
				return ORK.GameControls.cameraControl.targetTransition;
			}
		}

		public virtual bool IsCameraTargetTransition
		{
			get
			{
				return this.CameraTargetTransition.enabled &&
					this.transitionTime >= 0;
			}
		}

		public virtual void TransitionUpdate(Vector3 position, Quaternion rotation)
		{
			this.transitionTime += this.DeltaTime;
			if(this.CameraTargetTransition.Transition(this.transform,
				position, rotation, this.DeltaTime, this.transitionTime))
			{
				this.transitionTime = -1;
				this.targetTransition = null;
			}
		}
	}
}
