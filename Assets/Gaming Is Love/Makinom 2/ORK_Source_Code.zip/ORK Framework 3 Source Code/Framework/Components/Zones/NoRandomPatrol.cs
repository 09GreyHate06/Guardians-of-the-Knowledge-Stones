
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Move AI/No Random Patrol")]
	public class NoRandomPatrol : RaycastColliderZone
	{
		protected virtual void OnEnable()
		{
			ORK.Game.Scene.AddNoRandomPatrol(this);
		}

		protected virtual void OnDisable()
		{
			ORK.Game.Scene.RemoveNoRandomPatrol(this);
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/NoRandomPatrol Icon.png");
		}
	}
}
