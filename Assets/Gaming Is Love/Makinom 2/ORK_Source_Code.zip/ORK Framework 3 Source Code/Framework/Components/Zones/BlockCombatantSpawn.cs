
using GamingIsLove.ORKFramework;
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Combatant/Block Combatant Spawn")]
	public class BlockCombatantSpawn : RaycastColliderZone
	{
		protected virtual void OnEnable()
		{
			ORK.Game.Scene.AddNoSpawn(this);
		}

		protected virtual void OnDisable()
		{
			ORK.Game.Scene.RemoveNoSpawn(this);
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/BlockCombatantSpawn Icon.png");
		}
	}
}
