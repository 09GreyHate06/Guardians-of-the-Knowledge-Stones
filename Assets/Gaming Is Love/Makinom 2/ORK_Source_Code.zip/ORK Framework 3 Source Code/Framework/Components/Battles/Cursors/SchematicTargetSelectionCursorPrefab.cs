﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Target Selection Cursor: Schematic")]
	public class SchematicTargetSelectionCursorPrefab : MonoBehaviour, ITargetSelectionCursorPrefab
	{
		[Tooltip("Select the schematic used when selecting a target (spawning/enabling the prefab).\n" +
			"The user (combatant) is available as 'Machine Object', the target (combatant) as 'Starting Object' of the schematic.\n" +
			"The ability or item using is available as local selected data via the data key 'action'.\n" +
			"The game object of the cursor is available as local selected data via the data key 'cursor'.")]
		public MakinomSchematicAsset startSchematicAsset;

		[Tooltip("Select the schematic used when stopping the selection on a target (destroying/disabling the prefab).\n" +
			"The user (combatant) is available as 'Machine Object', the target (combatant) as 'Starting Object' of the schematic.\n" +
			"The ability or item is available as local selected data via the data key 'action'.\n" +
			"The game object of the cursor is available as local selected data via the data key 'cursor'.")]
		public MakinomSchematicAsset stopSchematicAsset;


		// in-game
		protected Combatant user;

		protected Combatant target;

		protected IShortcut shortcut;

		public virtual void StartSelection(Combatant user, Combatant target, IShortcut shortcut)
		{
			this.user = user;
			this.target = target;
			this.shortcut = shortcut;

			if(this.startSchematicAsset != null)
			{
				Schematic.Play(this.startSchematicAsset, this, null, this.user, this.target, false, null,
					this.CreateSelectedData());
			}
		}

		public virtual void StopSelection()
		{
			if(this.stopSchematicAsset != null)
			{
				Schematic.Play(this.stopSchematicAsset, this, null, this.user, this.target, false, null,
					this.CreateSelectedData());
			}

			this.user = null;
			this.target = null;
			this.shortcut = null;
		}

		protected virtual SelectedDataHandler CreateSelectedData()
		{
			SelectedDataHandler handler = SelectedDataHelper.CreateSelectedData("action", this.shortcut);
			handler.Change("cursor", this.gameObject, ListChangeType.Set);
			return handler;
		}
	}
}
