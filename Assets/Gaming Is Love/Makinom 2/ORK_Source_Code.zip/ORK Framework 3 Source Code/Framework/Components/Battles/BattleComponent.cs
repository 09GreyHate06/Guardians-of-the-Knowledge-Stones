
using System.Collections.Generic;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.ORKFramework;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Battle")]
	public class BattleComponent : BaseBattleComponent, ISchematicStarter, ISerializationCallbackReceiver
	{
		// battle spots
		// player group
		public GameObject[] playerSpot = new GameObject[0];

		public GameObject[] playerSpotPlayerAdvantage = new GameObject[0];

		public GameObject[] playerSpotEnemyAdvantage = new GameObject[0];

		// ally group
		public GameObject[] allySpot = new GameObject[0];

		public GameObject[] allySpotPlayerAdvantage = new GameObject[0];

		public GameObject[] allySpotEnemyAdvantage = new GameObject[0];

		// enemy group
		public GameObject[] enemySpot = new GameObject[0];

		public GameObject[] enemySpotPlayerAdvantage = new GameObject[0];

		public GameObject[] enemySpotEnemyAdvantage = new GameObject[0];


		// settings
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected bool isInitialized = false;

		protected BattleSystem overrideBattleSystem;

		protected BattleOutcome outcome = BattleOutcome.None;

		// battle mode:
		// 0 == not started
		// 1 == start schematic
		// 2 == battle running
		// 3 == end schematic
		// 4 == done
		protected int battleMode = 0;

		protected bool markSceneChangeDestroy = false;

		protected bool sceneChangedDestroy = false;


		// camera
		protected Transform initialCamParent;

		protected Vector3 initialCamPosition;

		protected Quaternion initialCamRotation;

		protected float initialFieldOfView;

		protected float initialOrthographicSize;


		// started by caller
		protected ISchematicStarter starter;


		// real battle spots
		protected Dictionary<GameObject, Combatant> playerSpotList;

		protected Dictionary<GameObject, Combatant> allySpotList;

		protected Dictionary<GameObject, Combatant> enemySpotList;


		// start from combatant
		protected List<Group> startGroup;

		// joined combatants
		protected List<Combatant> joined = new List<Combatant>();

		protected List<int> additionalSceneIDs = new List<int>();

		protected virtual void Reset()
		{
			this.startSettings.triggerStartSetting.isTriggerEnter = true;
		}

		public virtual void SetBattleSystem(BattleSystem battleSystem)
		{
			this.overrideBattleSystem = battleSystem;
		}


		/*
		============================================================================
		Event handlers
		============================================================================
		*/
		protected static Notify GlobalBattleStartedHandler;
		public static event Notify GlobalNotifyBattleStarted
		{
			add { GlobalBattleStartedHandler += value; }
			remove { GlobalBattleStartedHandler -= value; }
		}

		protected static Notify GlobalBattleEndedHandler;
		public static event Notify GlobalNotifyBattleEnded
		{
			add { GlobalBattleEndedHandler += value; }
			remove { GlobalBattleEndedHandler -= value; }
		}

		protected Notify battleStartedHandler;
		public virtual event Notify NotifyBattleStarted
		{
			add { this.battleStartedHandler += value; }
			remove { this.battleStartedHandler -= value; }
		}

		protected Notify battleEndedHandler;
		public virtual event Notify NotifyBattleEnded
		{
			add { this.battleEndedHandler += value; }
			remove { this.battleEndedHandler -= value; }
		}


		/*
		============================================================================
		Scene IDs functions
		============================================================================
		*/
		public override bool UseSceneID
		{
			get { return this.settings.useSceneID; }
			set { this.settings.useSceneID = value; }
		}

		public override bool IsGlobalSceneID
		{
			get { return this.settings.isGlobalSceneID; }
			set { this.settings.isGlobalSceneID = value; }
		}

		public override int SceneID
		{
			get { return this.settings.sceneID; }
			set { this.settings.sceneID = value; }
		}

		public virtual void AddSceneID(int id)
		{
			if(!this.UseSceneID ||
				this.SceneID != id ||
				!this.additionalSceneIDs.Contains(id))
			{
				this.additionalSceneIDs.Add(id);
			}
		}

		public override void SetSceneID(bool finished)
		{
			base.SetSceneID(finished);
			for(int i = 0; i < this.additionalSceneIDs.Count; i++)
			{
				ORK.Game.Scene.BattleFinished(this.IsGlobalSceneID ? null : this.sceneName, this.additionalSceneIDs[i], finished);
			}
			this.joined.Clear();
		}


		/*
		============================================================================
		Combatants functions
		============================================================================
		*/
		protected virtual Group CreateGroup(int index)
		{
			if(ORK.Access.Combatant.HasSpawnCreationAuthority &&
				index >= 0 && index < this.settings.combatant.Length)
			{
				Group group = this.settings.combatant[index].GetGroup(true, this.transform.position);
				if(group != null)
				{
					group.BattleSystem = this.overrideBattleSystem != null ?
						this.overrideBattleSystem :
						this.settings.battleSystem.GetBattleSystem();
					return group;
				}
			}
			return null;
		}

		public virtual void JoinOnStart(Combatant combatant)
		{
			if(!this.joined.Contains(combatant))
			{
				this.joined.Add(combatant);
			}
		}

		public virtual void JoinOnStart(List<Combatant> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(!this.joined.Contains(list[i]))
				{
					this.joined.Add(list[i]);
				}
			}
		}


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		protected override void Start()
		{
			bool destroyed = false;

			if(ConditionAutoCheckType.Start == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				if(!this.isInitialized)
				{
					this.DoStartSetup(this.startSettings.autoStartSetting.isStart);
				}
				else if(this.startSettings.autoStartSetting.isStart)
				{
					this.AutoStartCheck();
				}
			}
		}

		protected override void OnEnable()
		{
			Maki.Instance.SceneLoaded += this.OnAutoSceneLoaded;
			bool destroyed = false;

			if(ConditionAutoCheckType.Enable == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				this.Register();

				if(this.startSettings.autoStartSetting.isEnable)
				{
					if(!this.isInitialized)
					{
						this.DoStartSetup(true);
					}
					else
					{
						this.AutoStartCheck();
					}
				}
			}
		}

		protected override void OnDisable()
		{
			base.OnDisable();
			if(this.markSceneChangeDestroy)
			{
				Maki.Control.SceneChangeInfo -= this.OnSceneLoaded;
			}
		}

		protected override void OnDestroy()
		{
			base.OnDestroy();
			Maki.Control.StartSceneChangeCalled -= this.DontDestroy;
			Maki.Control.SceneChangeInfo -= this.OnSceneLoaded;
		}

		public override void OnAutoSceneLoaded()
		{
			if(this.startSettings.autoStartSetting.isLevelWasLoaded)
			{
				if(!this.isInitialized)
				{
					this.DoStartSetup(true);
				}
				else
				{
					this.AutoStartCheck();
				}
			}
		}

		protected virtual void DoStartSetup(bool doStart)
		{
			if(!this.isInitialized)
			{
				this.isInitialized = true;
				if(!this.settings.useAppearingChance ||
					Maki.GameSettings.CheckRandom(this.settings.appearingChance))
				{
					if(!this.CheckAutoDestroy())
					{
						if(this.IsSceneIDSet())
						{
							UnityWrapper.Destroy(this.gameObject);
						}
						else if(doStart)
						{
							this.CheckAutoStart();
						}
					}
				}
				else if(this.settings.useAppearingChance)
				{
					if(this.settings.appearingChanceFailSetID)
					{
						this.SetSceneID(true);
					}
					UnityWrapper.Destroy(this.gameObject);
				}
			}
		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		protected override void Update()
		{
			if(this.battleMode == 0)
			{
				base.Update();
			}
			else if(this.battleMode == 2)
			{
				if(this.settings.keepAtCenter &&
					!Maki.Game.Paused)
				{
					this.transform.position = ORKTransformHelper.GetCenterPosition(ORK.Game.Combatants.GetInBattle());
				}
			}
		}

		public virtual void StartInteraction(ISchematicStarter starter)
		{
			this.starter = starter;
			this.StartBattle();
		}

		public virtual void StartGroup(Group g, ISchematicStarter starter)
		{
			this.startGroup = new List<Group>();
			this.startGroup.Add(g);
			this.starter = starter;
			this.StartInteraction(ORK.Game.GetPlayer());
		}

		public virtual void StartGroups(List<Group> g, ISchematicStarter starter)
		{
			this.startGroup = g;
			this.starter = starter;
			this.StartInteraction(ORK.Game.GetPlayer());
		}

		public virtual bool IsPartOfBattle(Group group)
		{
			if(this.startGroup != null &&
				this.startGroup.Contains(group))
			{
				return true;
			}
			for(int i = 0; i < this.joined.Count; i++)
			{
				if(this.joined[i] != null &&
					this.joined[i].Group == group)
				{
					return true;
				}
			}
			return false;
		}

		public virtual void RespawnGroups(bool destroyInstances)
		{
			if(this.startGroup != null)
			{
				for(int i = 0; i < this.startGroup.Count; i++)
				{
					if(this.startGroup[i] != null &&
						this.startGroup[i].SpawnOrigin != null)
					{
						this.startGroup[i].SpawnOrigin.CheckRespawn(true, destroyInstances);
					}
				}
			}
			for(int i = 0; i < this.joined.Count; i++)
			{
				if(this.joined[i] != null &&
					this.joined[i].Group.SpawnOrigin != null)
				{
					this.joined[i].Group.SpawnOrigin.CheckRespawn(true, destroyInstances);
				}
			}
		}

		public override void StartInteraction(GameObject startingObject)
		{
			if(this.battleMode == 0 &&
				!ORK.Control.InBattle && !this.IsSceneIDSet())
			{
				this.DoTurns(startingObject);
				this.StartBattle();
			}
			else if(ComponentHelper.IsAlive(this.starter))
			{
				ISchematicStarter tmpStarter = this.starter;
				this.starter = null;
				tmpStarter.SchematicFinished(null);
			}
		}

		protected virtual void StartBattle()
		{
			this.battleMode = 1;

			this.playerSpotList = null;
			this.allySpotList = null;
			this.enemySpotList = null;

			// set up battle
			ORK.Battle.ClearBattle();
			ORK.Battle.SetBattleArena(this);

			// allies/enemies join
			if(this.startGroup != null && this.startGroup.Count > 0)
			{
				ORK.Battle.CheckAdvantage(this.startGroup[0].Leader);
				for(int i = 0; i < this.startGroup.Count; i++)
				{
					ORK.Battle.Join(this.startGroup[i].GetBattle());
				}
			}
			else
			{
				if(this.settings.allGroups)
				{
					bool setAdvantage = true;
					if(this.settings.useFactionGroups)
					{
						if(ORK.Access.Combatant.HasSpawnCreationAuthority)
						{
							Dictionary<FactionSetting, Group> factionGroups = new Dictionary<FactionSetting, Group>();
							for(int i = 0; i < this.settings.combatant.Length; i++)
							{
								if(Maki.GameSettings.CheckRandom(this.settings.combatant[i].chance))
								{
									Group group;
									FactionSetting faction = FactionSetting.Get(this.settings.combatant[i].faction);
									if(!factionGroups.TryGetValue(faction, out group))
									{
										group = new Group(faction);
										group.BattleSystem = this.overrideBattleSystem != null ?
											this.overrideBattleSystem :
											this.settings.battleSystem.GetBattleSystem();
										factionGroups.Add(faction, group);
									}
									this.settings.combatant[i].JoinGroup(group, true, this.transform.position);
								}
							}
							foreach(KeyValuePair<FactionSetting, Group> pair in factionGroups)
							{
								if(setAdvantage)
								{
									ORK.Battle.CheckAdvantage(pair.Value.Leader);
									setAdvantage = false;
								}
								ORK.Battle.Join(pair.Value.GetBattle());
							}
						}
					}
					else
					{
						for(int i = 0; i < this.settings.combatant.Length; i++)
						{
							if(Maki.GameSettings.CheckRandom(this.settings.combatant[i].chance))
							{
								Group enemyGroup = this.CreateGroup(i);
								if(enemyGroup != null)
								{
									if(setAdvantage)
									{
										ORK.Battle.CheckAdvantage(enemyGroup.Leader);
										setAdvantage = false;
									}
									ORK.Battle.Join(enemyGroup.GetBattle());
								}
							}
						}
					}
				}
				else if(this.settings.useChanceSelection)
				{
					int index = -1;
					float random = Maki.GameSettings.GetRandom();
					float tmpChance = 0;

					for(int i = 0; i < this.settings.combatant.Length; i++)
					{
						if(random >= tmpChance && random <= tmpChance + this.settings.combatant[i].chance)
						{
							index = i;
							break;
						}
						else
						{
							tmpChance += this.settings.combatant[i].chance;
						}
					}

					if(index >= 0 && index < this.settings.combatant.Length)
					{
						Group enemyGroup = this.CreateGroup(index);
						if(enemyGroup != null)
						{
							ORK.Battle.CheckAdvantage(enemyGroup.Leader);
							ORK.Battle.Join(enemyGroup.GetBattle());
						}
					}
				}
				else if(this.settings.combatant.Length > 0)
				{
					int index = UnityWrapper.Range(0, this.settings.combatant.Length);
					if(Maki.GameSettings.CheckRandom(this.settings.combatant[index].chance))
					{
						Group enemyGroup = this.CreateGroup(index);
						if(enemyGroup != null)
						{
							ORK.Battle.CheckAdvantage(enemyGroup.Leader);
							ORK.Battle.Join(enemyGroup.GetBattle());
						}
					}
				}
			}

			// auto join
			if(this.settings.ownAutoJoin)
			{
				this.settings.autoJoin.GetCombatants(ref this.joined, this.transform.position);
			}
			else
			{
				ORK.BattleSettings.autoJoin.GetCombatants(ref this.joined, this.transform.position);
			}
			if(this.joined.Count > 0)
			{
				ORK.Battle.Join(this.joined);
			}

			// check if any enemies are in the battle
			if(ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader,
				false, null, Consider.Yes, Consider.No, Consider.Yes, null).Count > 0)
			{
				Maki.Control.StartSceneChangeCalled += this.DontDestroy;

				if(BattleComponent.GlobalBattleStartedHandler != null)
				{
					BattleComponent.GlobalBattleStartedHandler();
				}
				if(this.battleStartedHandler != null)
				{
					this.battleStartedHandler();
				}

				// player group joins
				ORK.Battle.Join(ORK.Game.ActiveGroup.GetBattle());

				this.outcome = BattleOutcome.None;
				ORK.Battle.SetType(this.overrideBattleSystem != null ?
					this.overrideBattleSystem :
					this.settings.battleSystem.GetBattleSystem());

				Camera cam = Maki.Game.Camera;
				if(cam != null)
				{
					this.initialCamParent = cam.transform.parent;
					this.initialCamPosition = cam.transform.position;
					this.initialCamRotation = cam.transform.rotation;
					this.initialFieldOfView = cam.fieldOfView;
					this.initialOrthographicSize = cam.orthographicSize;
				}

				ORK.Control.SetInBattle(1);
				ORK.Battle.DoBattleBlock(1);

				MakinomSchematicAsset schematicAsset = this.settings.ownStartSchematic ?
					this.settings.startSchematicAsset.StoredAsset :
					ORK.Battle.System.startSchematicAsset.StoredAsset;
				if(schematicAsset != null)
				{
					Schematic.Play(schematicAsset, this, this, this.gameObject, ORK.Game.GetPlayer());
				}
				else
				{
					this.SchematicFinished(null);
				}
			}
			// no enemies, no battle
			else
			{
				if(this.settings.noBattleSetID)
				{
					this.SetSceneID(true);
				}
				this.battleMode = 0;
				ORK.Battle.ClearBattle();
				if(ComponentHelper.IsAlive(this.starter))
				{
					ISchematicStarter tmpStarter = this.starter;
					this.starter = null;
					tmpStarter.SchematicFinished(null);
				}
			}
		}

		public virtual void DontDestroy()
		{
			if(!this.markSceneChangeDestroy &&
				Maki.Game.Running)
			{
				this.markSceneChangeDestroy = true;
				Maki.Control.SceneChangeInfo += this.OnSceneLoaded;
				this.sceneChangedDestroy = false;
				this.transform.SetParent(null);
				GameObject.DontDestroyOnLoad(this.transform.root);
				this.RespawnGroups(false);
			}
		}

		public virtual void OnSceneLoaded(bool inOldScene, bool beforeFade, GlobalMachineSceneChangeType loadType, string customType)
		{
			if(beforeFade)
			{
				if(inOldScene)
				{
					ORK.Game.Combatants.LockBattle();
				}
				else
				{
					ORK.Game.Combatants.UnlockBattle();
					if(this.markSceneChangeDestroy)
					{
						this.sceneChangedDestroy = true;
					}
					this.PlaceSpotsOnGround();

					if(this.battleMode == 1)
					{
						ORK.Game.Combatants.SpawnBattle();
					}
				}
			}
		}

		public virtual void PlaceSpotsOnGround()
		{
			// replace spots on ground
			if(this.playerSpotList != null)
			{
				this.SpotListOnGround(this.playerSpotList);
			}
			if(this.allySpotList != null)
			{
				this.SpotListOnGround(this.allySpotList);
			}
			if(this.enemySpotList != null)
			{
				this.SpotListOnGround(this.enemySpotList);
			}
		}

		public virtual void BattleFinished(BattleOutcome outcome)
		{
			this.outcome = outcome;
			this.SchematicFinished(null);
		}

		public virtual void SchematicFinished(Schematic schematic)
		{
			// start schematic finished
			if(this.battleMode == 1)
			{
				this.battleMode = 2;

				ORK.Game.Combatants.UnlockBattle();
				ORK.Game.Combatants.SpawnBattle();
				if(this.settings.setLooks)
				{
					ORK.Battle.SetLooks(null);
				}
				ORK.Battle.StartBattle(this.settings.canEscape);
			}
			// battle finished
			else if(this.battleMode == 2)
			{
				this.battleMode = 3;
				this.settings.variableChanges.SetVariables(new DataCall());
				this.SetSceneID(true);

				MakinomSchematicAsset schematicAsset = null;
				if(BattleOutcome.Victory == this.outcome)
				{
					schematicAsset = this.settings.ownEndSchematic ?
						this.settings.victorySchematicAsset.StoredAsset :
						ORK.Battle.System.victorySchematicAsset.StoredAsset;
				}
				else if(BattleOutcome.Escape == this.outcome)
				{
					schematicAsset = this.settings.ownEndSchematic ?
						this.settings.escapeSchematicAsset.StoredAsset :
						ORK.Battle.System.escapeSchematicAsset.StoredAsset;
				}
				else if(BattleOutcome.Defeat == this.outcome)
				{
					schematicAsset = this.settings.ownEndSchematic ?
						this.settings.defeatSchematicAsset.StoredAsset :
						ORK.Battle.System.defeatSchematicAsset.StoredAsset;
				}
				else if(BattleOutcome.LeaveArena == this.outcome)
				{
					schematicAsset = this.settings.ownEndSchematic ?
						this.settings.leaveArenaSchematicAsset.StoredAsset :
						ORK.Battle.System.leaveArenaSchematicAsset.StoredAsset;
				}

				if(schematicAsset != null)
				{
					Schematic battleEndSchematic = new Schematic(schematicAsset);
					battleEndSchematic.SetInitialCameraPosition(this.initialCamParent,
						this.initialCamPosition, this.initialCamRotation, this.initialFieldOfView, this.initialOrthographicSize);
					battleEndSchematic.PlaySchematic(this, this, this.gameObject, ORK.Game.GetPlayer(),
						false, MachineUpdateType.Update, Maki.Control.InputID);
				}
				else
				{
					this.SchematicFinished(null);
				}
			}
			// end schematic finished
			else if(this.battleMode == 3)
			{
				this.battleMode = 0;

				ORK.Battle.ClearObjectsAndAnimations();
				ORK.Game.Combatants.EndBattle();

				ORK.Battle.DoBattleBlock(-1);
				ORK.Battle.DoMoveAIBlock(-1);
				ORK.Control.SetInBattle(-1);
				ORK.Battle.ClearBattle();

				// call source that started the battle
				if(ComponentHelper.IsAlive(this.starter))
				{
					if(this.starter is Schematic &&
						((Schematic)this.starter).IsBlocking)
					{
						Maki.Control.SetMachineBlock(1);
					}
					ISchematicStarter tmpStarter = this.starter;
					this.starter = null;
					tmpStarter.SchematicFinished(null);
				}
				this.RespawnGroups(true);

				if(BattleComponent.GlobalBattleEndedHandler != null)
				{
					BattleComponent.GlobalBattleEndedHandler();
				}
				if(this.battleEndedHandler != null)
				{
					this.battleEndedHandler();
				}

				Maki.Control.StartSceneChangeCalled -= this.DontDestroy;
				Maki.Control.SceneChangeInfo -= this.OnSceneLoaded;
				if(this.markSceneChangeDestroy && this.sceneChangedDestroy)
				{
					UnityWrapper.Destroy(this.gameObject);
				}
				else
				{
					this.EndCheck();
				}
			}
		}


		/*
		============================================================================
		Battle spot functions
		============================================================================
		*/
		public virtual void CreateDefaultSpotGameObjects()
		{
			List<GameObject> spots = new List<GameObject>();
			List<GameObject> spotsPA = new List<GameObject>();
			List<GameObject> spotsEA = new List<GameObject>();
			// player
			this.CreateDefaultSpots("_Player_", ORK.BattleSpots.playerSpot, ref spots, ref spotsPA, ref spotsEA);
			this.settings.ownPlayerSpots = spots.Count > 0;
			this.playerSpot = spots.ToArray();
			this.playerSpotPlayerAdvantage = spotsPA.ToArray();
			this.playerSpotEnemyAdvantage = spotsEA.ToArray();
			// ally
			this.CreateDefaultSpots("_Ally_", ORK.BattleSpots.allySpot, ref spots, ref spotsPA, ref spotsEA);
			this.settings.ownAllySpots = spots.Count > 0;
			this.allySpot = spots.ToArray();
			this.allySpotPlayerAdvantage = spotsPA.ToArray();
			this.allySpotEnemyAdvantage = spotsEA.ToArray();
			// enemy
			this.CreateDefaultSpots("_Enemy_", ORK.BattleSpots.enemySpot, ref spots, ref spotsPA, ref spotsEA);
			this.settings.ownEnemySpots = spots.Count > 0;
			this.enemySpot = spots.ToArray();
			this.enemySpotPlayerAdvantage = spotsPA.ToArray();
			this.enemySpotEnemyAdvantage = spotsEA.ToArray();
		}

		protected virtual void CreateDefaultSpots(string prefix, BattleSpotSettings[] settings,
			ref List<GameObject> spots, ref List<GameObject> spotsPA, ref List<GameObject> spotsEA)
		{
			spots.Clear();
			spotsPA.Clear();
			spotsEA.Clear();
			for(int i = 0; i < settings.Length; i++)
			{
				GameObject spot = new GameObject(prefix + i);
				settings[i].spot.SetSpot(this.transform, spot.transform);
				spot.transform.SetParent(this.transform, true);
				this.SpotOnGround(spot);
				spots.Add(spot);
				// player advantage
				if(settings[i].usePlayerAdvantageSpot)
				{
					spot = new GameObject(prefix + "PA_" + i);
					settings[i].playerAdvantageSpot.SetSpot(this.transform, spot.transform);
					spot.transform.SetParent(this.transform, true);
					this.SpotOnGround(spot);
					spotsPA.Add(spot);
				}
				// enemy advantage
				if(settings[i].useEnemyAdvantageSpot)
				{
					spot = new GameObject(prefix + "EA_" + i);
					settings[i].enemyAdvantageSpot.SetSpot(this.transform, spot.transform);
					spot.transform.SetParent(this.transform, true);
					this.SpotOnGround(spot);
					spotsEA.Add(spot);
				}
			}
		}

		public virtual void SetSpot(Combatant oldUser, Combatant newUser)
		{
			if(this.playerSpotList != null)
			{
				foreach(KeyValuePair<GameObject, Combatant> pair in this.playerSpotList)
				{
					if(pair.Value == oldUser)
					{
						this.playerSpotList[pair.Key] = newUser;
						return;
					}
				}
			}
			if(this.allySpotList != null)
			{
				foreach(KeyValuePair<GameObject, Combatant> pair in this.allySpotList)
				{
					if(pair.Value == oldUser)
					{
						this.allySpotList[pair.Key] = newUser;
						return;
					}
				}
			}
			if(this.enemySpotList != null)
			{
				foreach(KeyValuePair<GameObject, Combatant> pair in this.enemySpotList)
				{
					if(pair.Value == oldUser)
					{
						this.enemySpotList[pair.Key] = newUser;
						return;
					}
				}
			}
		}

		protected virtual void SpotListOnGround(Dictionary<GameObject, Combatant> list)
		{
			foreach(KeyValuePair<GameObject, Combatant> pair in list)
			{
				if(pair.Key != null)
				{
					pair.Key.transform.position = new Vector3(
						pair.Key.transform.position.x,
						ORK.BattleSpots.onGround ?
							this.transform.position.y + 1 :
							pair.Key.transform.position.y,
						pair.Key.transform.position.z);
					this.SpotOnGround(pair.Key);
				}
			}
		}

		public virtual void SpotOnGround(GameObject obj)
		{
			if(ORK.BattleSpots.onGround)
			{
				RaycastOutput hit;
				if(RaycastHelper.Raycast(obj.transform.position, -Vector3.up, out hit,
					ORK.BattleSpots.distance, ORK.BattleSpots.layerMask))
				{
					obj.transform.position = hit.point + ORK.BattleSpots.rayOffset.GetValue();
				}
			}
		}

		public virtual void SetNextPlayerSpot(Combatant combatant, GroupAdvantageType advantage)
		{
			if(!combatant.IsBodyPart)
			{
				GameObject spot = null;
				if((this.settings.useCombatantPositionSpots || combatant.Object.OwnPositionSpot) &&
					combatant.GameObject != null)
				{
					spot = new GameObject("_PlayerSpot " + combatant.GetName());
					spot.transform.SetPositionAndRotation(combatant.GameObject.transform.position, combatant.GameObject.transform.rotation);
					this.SpotOnGround(spot);
					spot.transform.SetParent(this.transform);
					combatant.Object.BattleSpot = spot;
				}
				else
				{
					if(this.playerSpotList == null)
					{
						this.playerSpotList = new Dictionary<GameObject, Combatant>();
					}
					int index = combatant.Battle.BattleGroupIndex;
					if(index < 0)
					{
						index = this.playerSpotList.Count;
					}
					// check already added spots
					foreach(KeyValuePair<GameObject, Combatant> pair in this.playerSpotList)
					{
						if(pair.Value == null)
						{
							spot = pair.Key;
						}
					}
					// check spots added to battle component
					if(spot == null &&
						this.settings.ownPlayerSpots &&
						index < this.playerSpot.Length)
					{
						if(GroupAdvantageType.Player == advantage)
						{
							spot = this.playerSpotPlayerAdvantage[index];
						}
						else if(GroupAdvantageType.Enemy == advantage)
						{
							spot = this.playerSpotEnemyAdvantage[index];
						}
						if(spot == null)
						{
							spot = this.playerSpot[index];
						}
					}
					// no spot found > create new spot
					if(spot == null)
					{
						spot = new GameObject("_PlayerSpot" + index);
						if(combatant.Object.CustomBattleSpot != null)
						{
							combatant.Object.CustomBattleSpot.SetSpot(advantage, this.transform, spot.transform);
						}
						else
						{
							ORK.BattleSpots.SetPlayerSpot(combatant, index, advantage, this.transform, spot.transform);
						}
						this.SpotOnGround(spot);
						spot.transform.SetParent(this.transform);
					}
					// add/update list, set spot to combatant
					combatant.Object.BattleSpot = spot;
					this.playerSpotList[spot] = combatant;
				}
			}
		}

		public virtual void SetNextAllySpot(Combatant combatant, GroupAdvantageType advantage)
		{
			if(!combatant.IsBodyPart)
			{
				GameObject spot = null;
				if((this.settings.useCombatantPositionSpots || combatant.Object.OwnPositionSpot) &&
					combatant.GameObject != null)
				{
					spot = new GameObject("_AllySpot " + combatant.GetName());
					spot.transform.SetPositionAndRotation(combatant.GameObject.transform.position, combatant.GameObject.transform.rotation);
					this.SpotOnGround(spot);
					spot.transform.SetParent(this.transform);
					combatant.Object.BattleSpot = spot;
				}
				else
				{
					if(this.allySpotList == null)
					{
						this.allySpotList = new Dictionary<GameObject, Combatant>();
					}
					int index = combatant.Battle.BattleGroupIndex;
					if(index < 0)
					{
						index = this.allySpotList.Count;
					}
					// check already added spots
					foreach(KeyValuePair<GameObject, Combatant> pair in this.allySpotList)
					{
						if(pair.Value == null)
						{
							spot = pair.Key;
						}
					}
					// check spots added to battle component
					if(spot == null &&
						this.settings.ownAllySpots &&
						index < this.allySpot.Length)
					{
						if(GroupAdvantageType.Player == advantage)
						{
							spot = this.allySpotPlayerAdvantage[index];
						}
						else if(GroupAdvantageType.Enemy == advantage)
						{
							spot = this.allySpotEnemyAdvantage[index];
						}
						if(spot == null)
						{
							spot = this.allySpot[index];
						}
					}
					// no spot found > create new spot
					if(spot == null)
					{
						spot = new GameObject("_AllySpot" + index);
						if(combatant.Object.CustomBattleSpot != null)
						{
							combatant.Object.CustomBattleSpot.SetSpot(advantage, this.transform, spot.transform);
						}
						else
						{
							ORK.BattleSpots.SetAllySpot(combatant, index, advantage, this.transform, spot.transform);
						}
						this.SpotOnGround(spot);
						spot.transform.SetParent(this.transform);
					}
					// add/update list, set spot to combatant
					combatant.Object.BattleSpot = spot;
					this.allySpotList[spot] = combatant;
				}
			}
		}

		public virtual void SetNextEnemySpot(Combatant combatant, GroupAdvantageType advantage)
		{
			if(!combatant.IsBodyPart)
			{
				GameObject spot = null;
				if((this.settings.useCombatantPositionSpots || combatant.Object.OwnPositionSpot) &&
					combatant.GameObject != null)
				{
					spot = new GameObject("_EnemySpot " + combatant.GetName());
					spot.transform.SetPositionAndRotation(combatant.GameObject.transform.position, combatant.GameObject.transform.rotation);
					this.SpotOnGround(spot);
					spot.transform.SetParent(this.transform);
					combatant.Object.BattleSpot = spot;
				}
				else
				{
					if(this.enemySpotList == null)
					{
						this.enemySpotList = new Dictionary<GameObject, Combatant>();
					}
					int index = combatant.Battle.BattleGroupIndex;
					if(index < 0)
					{
						index = this.enemySpotList.Count;
					}
					// check already added spots
					foreach(KeyValuePair<GameObject, Combatant> pair in this.enemySpotList)
					{
						if(pair.Value == null)
						{
							spot = pair.Key;
						}
					}
					// check spots added to battle component
					if(spot == null &&
						this.settings.ownEnemySpots &&
						index < this.enemySpot.Length)
					{
						if(GroupAdvantageType.Player == advantage)
						{
							spot = this.enemySpotPlayerAdvantage[index];
						}
						else if(GroupAdvantageType.Enemy == advantage)
						{
							spot = this.enemySpotEnemyAdvantage[index];
						}
						if(spot == null)
						{
							spot = this.enemySpot[index];
						}
					}
					// no spot found > create new spot
					if(spot == null)
					{
						spot = new GameObject("_EnemySpot" + index);
						if(combatant.Object.CustomBattleSpot != null)
						{
							combatant.Object.CustomBattleSpot.SetSpot(advantage, this.transform, spot.transform);
						}
						else
						{
							ORK.BattleSpots.SetEnemySpot(combatant, index, advantage, this.transform, spot.transform);
						}
						this.SpotOnGround(spot);
						spot.transform.SetParent(this.transform);
					}
					// add/update list, set spot to combatant
					combatant.Object.BattleSpot = spot;
					this.enemySpotList[spot] = combatant;
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public static BattleComponent CreateBattle(List<Combatant> enemy)
		{
			if(enemy != null && enemy.Count > 0 &&
				ORK.Game.ActiveGroup.Leader != null &&
				ORK.Game.ActiveGroup.Leader.GameObject != null)
			{
				List<Group> groupList = new List<Group>();

				// add groups to list and calculate battle position
				List<GameObject> tmp = Maki.Pooling.GameObjectLists.Get();
				for(int i = 0; i < enemy.Count; i++)
				{
					if(enemy[i] != null)
					{
						Group g = enemy[i].Group;
						groupList.Add(g);
						List<Combatant> battleGroup = g.GetBattle();
						for(int j = 0; j < battleGroup.Count; j++)
						{
							if(battleGroup[j] != null &&
								battleGroup[j].GameObject != null)
							{
								tmp.Add(battleGroup[j].GameObject);
							}
						}
					}
				}
				tmp.Add(ORK.Game.ActiveGroup.Leader.GameObject);

				Vector3 center = TransformHelper.GetCenterPosition(tmp);
				Maki.Pooling.GameObjectLists.Add(tmp);
				BattleComponent battle = null;

				for(int i = 0; i < enemy.Count; i++)
				{
					if(enemy[i] != null)
					{
						if(enemy[i].Group.SpawnOrigin != null &&
							enemy[i].Group.SpawnOrigin.Spawner != null)
						{
							battle = enemy[i].Group.SpawnOrigin.Spawner.GetBattleComponent(center,
								ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles, null);
						}
						else if(enemy[i].Object.Component != null &&
							enemy[i].Object.Component.AddCombatantComponent != null)
						{
							battle = enemy[i].Object.Component.AddCombatantComponent.GetBattleComponent(center,
								ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles, null);
						}
						if(battle != null)
						{
							break;
						}
					}
				}

				if(battle == null)
				{
					battle = new GameObject("_Battle").AddComponent<BattleComponent>();
					if(ORK.Game.ActiveGroup.Leader.Setting.AutoStartBattles.setRotation)
					{
						battle.transform.SetPositionAndRotation(center,
							Quaternion.Euler(ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles));
					}
					else
					{
						battle.transform.position = center;
					}

					for(int i = 0; i < enemy.Count; i++)
					{
						if(enemy[i] != null)
						{
							battle.SetBattleSystem(enemy[i].Group.BattleSystem);
							break;
						}
					}
					battle.UseSceneID = false;
				}

				if(battle != null)
				{
					battle.startGroup = groupList;
				}
				return battle;
			}
			return null;
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/BattleComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// scene ID
			[EditorHide]
			public bool useSceneID = true;

			[EditorHide]
			public bool isGlobalSceneID = false;

			[EditorHide]
			public int sceneID = -1;


			// battle settings
			// chance
			[EditorHelp("Use Appearing Chance", "Use a chance check if this battle is used.")]
			[EditorFoldout("Battle Settings", "Define the used battle system.")]
			public bool useAppearingChance = false;

			[EditorHelp("Chance (%)", "Define the chance this battle can appear.")]
			[EditorIndent]
			[EditorCondition("useAppearingChance", true)]
			public float appearingChance = 100;

			[EditorHelp("Fail Set Scene ID", "Failing the chance check will set the scene ID of the battle (if used).")]
			[EditorIndent]
			[EditorEndCondition]
			public bool appearingChanceFailSetID = false;


			// battle settings
			[EditorSeparator]
			public BattleSystemSelection battleSystem = new BattleSystemSelection();

			[EditorHelp("Can Escape", "The player can escpae the battle using the 'Escape' command.")]
			public bool canEscape = true;

			[EditorHelp("Look At Enemies", "The combatants will look at their enemies after the battle start schematic finished.")]
			public bool setLooks = false;

			[EditorHelp("Keep At Center", "Keep the battle's game object at the center of all participating combatants.")]
			public bool keepAtCenter = false;

			// grid settings
			[EditorHelp("Grid Use Type", "Select if and which 'Battle Grid' component will be used:\n" +
				"- No Grid: No 'Battle Grid' component is used.\n" +
				"- Nearest Grid: Uses the nearest 'Battle Grid' component.\n" +
				"- Defined Grid: Uses a defined 'Battle Grid' component.")]
			[EditorSeparator]
			public GridUseBattleType gridUseType = GridUseBattleType.NearestGrid;

			[EditorHelp("Battle Grid", "Select the 'Battle Grid' component that will be used.")]
			[EditorInfo(allowSceneObjects = true)]
			[EditorCondition("gridUseType", GridUseBattleType.DefinedGrid)]
			[EditorEndCondition]
			public BattleGridComponent gridObject;

			// battle advantages
			// player advantage
			[EditorHelp("Enable Player Advantage", "This battle allows using player advantage.")]
			[EditorFoldout("Advantage Settings", "Define if battle advantages are used.",
				initialState = false)]
			public bool enablePlayerAdvantage = true;

			[EditorHelp("Own Chance", "This battle uses it's own player advantage chance.")]
			[EditorIndent]
			[EditorCondition("enablePlayerAdvantage", true)]
			public bool overridePlayerAdvantageChance = false;

			[EditorHelp("Advantage Chance (%)", "The player advantage chance.")]
			[EditorIndent]
			[EditorCondition("overridePlayerAdvantageChance", true)]
			[EditorEndCondition(2)]
			public float playerAdvantageChance = 0;

			// enemy advantage
			[EditorHelp("Enable Enemy Advantage", "This battle allows using enemy advantage.")]
			[EditorSeparator]
			public bool enableEnemyAdvantage = true;

			[EditorHelp("Own Chance", "This battle uses it's own enemy advantage chance.")]
			[EditorIndent]
			[EditorCondition("enableEnemyAdvantage", true)]
			public bool overrideEnemyAdvantageChance = false;

			[EditorHelp("Advantage Chance (%)", "The enemy advantage chance.")]
			[EditorIndent]
			[EditorEndFoldout]
			[EditorCondition("overrideEnemyAdvantageChance", true)]
			[EditorEndCondition(2)]
			public float enemyAdvantageChance = 0;

			// scheamtics
			// start schematic
			[EditorHelp("Own Start Schematic", "Override the default battle start schematic (defined in the used battle system).")]
			[EditorFoldout("Battle Start/End Schematics", "Optionally use different battle start/end schematics in this battle.",
				initialState = false)]
			public bool ownStartSchematic = false;

			[EditorHelp("Start Schematic", "Select the schematic asset used to start the battle.\n" +
				"If none is selected, the battle will start right away and place all combatants at their battle spots.", "")]
			[EditorCondition("ownStartSchematic", true)]
			[EditorEndCondition]
			[EditorAutoInit]
			public AssetSource<MakinomSchematicAsset> startSchematicAsset;

			// end schematics
			[EditorHelp("Own End Schematic", "Override the default battle end schematics (defined in the used battle system).")]
			[EditorSeparator]
			public bool ownEndSchematic = false;

			[EditorHelp("Victory Schematic", "Select the schematic asset used to end this battle when the player group won.\n" +
				"If none is selected, the battle will end right away and collect all battle gains (without displaying them).", "")]
			[EditorCondition("ownEndSchematic", true)]
			[EditorAutoInit]
			public AssetSource<MakinomSchematicAsset> victorySchematicAsset;

			[EditorHelp("Escape Schematic", "Select the schematic asset used to end this battle when the player group escaped.\n" +
				"If none is selected, the battle will end right away and collect all battle gains (without displaying them).", "")]
			[EditorAutoInit]
			public AssetSource<MakinomSchematicAsset> escapeSchematicAsset;

			[EditorHelp("Defeat Schematic", "Select the schematic asset used to end this battle when the player group has been defeated.\n" +
				"If none is selected, the battle will end right away and collect all battle gains (without displaying them), no game over will be called.", "")]
			[EditorAutoInit]
			public AssetSource<MakinomSchematicAsset> defeatSchematicAsset;

			[EditorHelp("Leave Arena Schematic", "Select the schematic asset used to end this battle when the player has left the battle arena.\n" +
				"If none is selected, the battle will end right away and collect all battle gains (without displaying them).", "")]
			[EditorEndCondition]
			[EditorAutoInit]
			[EditorEndFoldout]
			public AssetSource<MakinomSchematicAsset> leaveArenaSchematicAsset;

			// auto join
			[EditorHelp("Own Auto Join", "Override the default auto join settings (defined in the battle settings).")]
			[EditorFoldout("Auto Join", "Optionally use different auto join settings in this battle.",
				initialState = false)]
			public bool ownAutoJoin = false;

			[EditorEndFoldout(2)]
			[EditorCondition("ownAutoJoin", true)]
			[EditorEndCondition]
			[EditorAutoInit]
			public AutoJoinBattle autoJoin;


			// combatant teams
			[EditorHelp("No Battle Sets ID", "The battle's scene ID will be set if no battle occurs (e.g. due to no enemy combatant being added).")]
			[EditorFoldout("Combatant Settings", "Define the combatants or groups that will be in this battle.")]
			public bool noBattleSetID = false;

			[EditorHelp("All Groups/Combatants", "All defined combatants/groups will be used.\n" +
				"If disabled, a random combatant/group is used.")]
			public bool allGroups = false;

			[EditorHelp("Use Faction Groups", "Combatants of the same faction will be put into a single group.")]
			[EditorIndent]
			[EditorCondition("allGroups", true)]
			public bool useFactionGroups = false;

			[EditorHelp("Use Chance Selection", "Use the combatant's chance setting to determine which combatant will be used.\n" +
				"E.g. combatant 0 has 35% chance, combatant 1 has 50% chance, combatant 2 has 15% chance. " +
				"i.e. combatant 0 is used for 0-35 chance range, combatant 1 for 35-85 and combatant 2 for 85-100.\n" +
				"- chance check results in 15: combatant 0 is used\n" +
				"- chance check results in 62: combatant 1 is used\n" +
				"- chance check results in 90: combatant 2 is used")]
			[EditorElseCondition]
			[EditorEndCondition]
			public bool useChanceSelection = false;

			[EditorEndFoldout]
			[EditorArray("Add Combatant/Group", "Adds a combatant or group.", "",
				"Remove", "Removes this combatant/group.", "",
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Combatant", "Define the combatant or group that will be used.", ""
				})]
			public ChanceBattleCombatant[] combatant = new ChanceBattleCombatant[] { new ChanceBattleCombatant() };


			// additional loot
			[EditorFoldout("Additional Loot", "Add additional loot to this battle.",
				initialState = false)]
			[EditorEndFoldout]
			[EditorArray("Add Item", "Add an item to the battle's loot.", "",
				"Remove", "Removes this item.", "",
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Item", "Define the item that will be used.", ""
				})]
			public ItemGain<GameObjectSelection>[] itemGains = new ItemGain<GameObjectSelection>[0];


			// set after battle
			[EditorFoldout("Variables After Battle", "Optionally change variables after finishing the battle.",
				initialState = false)]
			[EditorEndFoldout]
			public VariableSetter<GameObjectSelection> variableChanges = new VariableSetter<GameObjectSelection>();


			// battle spots
			[EditorHide]
			public bool useCombatantPositionSpots = false;

			[EditorHide]
			public bool ownPlayerSpots = false;

			[EditorHide]
			public bool ownAllySpots = false;

			[EditorHide]
			public bool ownEnemySpots = false;

			public Settings()
			{

			}
		}
	}
}
