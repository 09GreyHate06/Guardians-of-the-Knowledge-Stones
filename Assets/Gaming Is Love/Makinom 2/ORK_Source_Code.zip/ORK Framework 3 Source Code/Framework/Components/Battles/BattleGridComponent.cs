﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Battle Grid")]
	public class BattleGridComponent : SerializedBehaviour<BattleGridComponent.Settings>
	{
		// editor display
		public bool showEditorGrid = false;

		public bool showEditorPrefabs = false;

		public bool showEditorUnselected = false;

		public bool showDeploymentInfo = false;

		protected bool editorPrefabsShowing = false;


		// generated battle grid
		public bool autoShowGrid = false;

		public BattleGridCellRow[] cellRow;

		public bool connectionsInitialized = false;


		// in-game
		protected bool highlightsHiddenByUI = false;

		protected bool markFireChanged = false;

		protected Dictionary<CubeCoord, BattleGridCellComponent> cellLookup;

		protected List<BattleGridCellComponent> deploymentCells;

		protected bool deploymentCellsSearched = false;

		protected Dictionary<GridCellHighlight, RuntimeLineGridHighlight> lineHighlight;

		// notify
		protected Notify gridChangedHandler;
		public virtual event Notify GridChanged
		{
			add { this.gridChangedHandler += value; }
			remove { this.gridChangedHandler -= value; }
		}

		public virtual void FireGridChanged()
		{
			if(this.gridChangedHandler != null)
			{
				this.gridChangedHandler();
			}
			this.markFireChanged = false;
		}

		public virtual void MarkFireChanged()
		{
			this.markFireChanged = true;
		}

		public virtual void Start()
		{
			this.CreateLookup();
			if(this.autoShowGrid)
			{
				this.ShowGridPrefabs();
			}
		}

		public virtual void Init()
		{
			this.CreateLookup();
			if(ORK.Battle.BattleArena != null)
			{
				this.JoinDeploymentCombatants(ORK.Battle.BattleArena.settings.battleSystem.GetBattleSystem());
			}
			if(!this.connectionsInitialized)
			{
				this.InitConnections();
			}
		}

		public virtual void InitConnections()
		{
			if(this.cellLookup == null)
			{
				this.CreateLookup();
			}
			if(ORK.BattleGridSettings.IsSquare)
			{
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellRow[i].cell[j].InitConnectionsSquare();
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellRow[i].cell[j].InitConnectionsHexagonal();
						}
					}
				}
			}
			this.connectionsInitialized = true;
		}

		public virtual void RemoveBlockedConnections()
		{
			if(this.cellLookup == null)
			{
				this.CreateLookup();
			}
			if(!this.connectionsInitialized)
			{
				this.InitConnections();
			}
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				for(int j = 0; j < this.cellRow[i].cell.Length; j++)
				{
					if(this.cellRow[i].cell[j] != null)
					{
						this.cellRow[i].cell[j].RemoveBlockedConnections();
					}
				}
			}
		}

		public virtual void BattleEnd()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				for(int j = 0; j < this.cellRow[i].cell.Length; j++)
				{
					if(this.cellRow[i].cell[j] != null)
					{
						this.cellRow[i].cell[j].ClearTemporaryCellEvents();
					}
				}
			}
		}

		public virtual void CreateLookup()
		{
			if(this.cellLookup == null)
			{
				this.cellLookup = new Dictionary<CubeCoord, BattleGridCellComponent>();
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellLookup.Add(this.cellRow[i].cell[j].CubeCoord, this.cellRow[i].cell[j]);
						}
					}
				}
			}
		}

		public virtual void ClearLookup()
		{
			this.cellLookup = null;
		}

		protected virtual void Update()
		{
			if(this.markFireChanged)
			{
				this.FireGridChanged();
			}
		}


		/*
		============================================================================
		Grid functions
		============================================================================
		*/
		public virtual void RemoveGrid()
		{
			if(this.cellRow != null)
			{
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							GameObject.DestroyImmediate(this.cellRow[i].cell[j].gameObject);
						}
					}
				}
			}
			this.cellRow = null;
		}

		public virtual BattleGridCellComponent GetCell(int row, int column)
		{
			if(this.cellRow != null &&
				row >= 0 && row < this.cellRow.Length &&
				column >= 0 && column < this.cellRow[row].cell.Length)
			{
				return this.cellRow[row].cell[column];
			}
			return null;
		}

		public virtual BattleGridCellComponent GetCell(CubeCoord coord)
		{
			BattleGridCellComponent cell;
			if(this.cellLookup.TryGetValue(coord, out cell))
			{
				return cell;
			}
			return null;
		}

		public virtual void GetCells(ref List<BattleGridCellComponent> cells, GridCellCheck check)
		{
			if(check == null)
			{
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					if(this.cellRow[i] != null)
					{
						for(int j = 0; j < this.cellRow[i].cell.Length; j++)
						{
							if(this.cellRow[i].cell[j] != null)
							{
								cells.Add(this.cellRow[i].cell[j]);
							}
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					if(this.cellRow[i] != null)
					{
						for(int j = 0; j < this.cellRow[i].cell.Length; j++)
						{
							if(this.cellRow[i].cell[j] != null &&
								check(this.cellRow[i].cell[j]))
							{
								cells.Add(this.cellRow[i].cell[j]);
							}
						}
					}
				}
			}
		}

		public virtual BattleGridCellComponent GetNearestCell(Vector3 position, float maxDistance,
			NearestCheck<BattleGridCellComponent> check)
		{
			BattleGridCellComponent nearest = null;

			if(this.cellRow != null)
			{
				float distance = Mathf.Infinity;
				int rowMax = (this.cellRow.Length / 2) - 1;
				int columnMax = (this.cellRow[0].cell.Length / 2) - 1;
				int row = -1;
				int column = -1;
				BattleGridHelper.GetRoughArea(this, position,
					0, 0, this.cellRow.Length, this.cellRow[0].cell.Length,
					ref row, ref column, ref rowMax, ref columnMax);

				if(row > 0 && column > 0)
				{
					for(int i = row - rowMax; i < row + rowMax; i++)
					{
						if(i >= 0 && i < this.cellRow.Length)
						{
							for(int j = column - columnMax; j < column + columnMax; j++)
							{
								if(j >= 0 && j < this.cellRow[i].cell.Length &&
									this.cellRow[i].cell[j] != null &&
									this.cellRow[i].cell[j].enabled &&
									this.cellRow[i].cell[j].gameObject.activeInHierarchy &&
									(check == null || check(this.cellRow[i].cell[j])))
								{
									float tmp = Vector3.Distance(position,
										this.cellRow[i].cell[j].transform.position);
									if(tmp < distance &&
										tmp <= maxDistance)
									{
										nearest = this.cellRow[i].cell[j];
										distance = tmp;
									}
								}
							}
						}
					}
				}

				// check all cells if not yet found
				if(nearest == null)
				{
					distance = Mathf.Infinity;
					for(int i = 0; i < this.cellRow.Length; i++)
					{
						for(int j = 0; j < this.cellRow[i].cell.Length; j++)
						{
							if(this.cellRow[i].cell[j] != null &&
								this.cellRow[i].cell[j].enabled &&
								this.cellRow[i].cell[j].gameObject.activeInHierarchy &&
								(check == null || check(this.cellRow[i].cell[j])))
							{
								float tmp = Vector3.Distance(position,
									this.cellRow[i].cell[j].transform.position);
								if(tmp < distance &&
									tmp <= maxDistance)
								{
									nearest = this.cellRow[i].cell[j];
									distance = tmp;
								}
							}
						}
					}
				}
			}
			return nearest;
		}

		public virtual BattleGridCellComponent GetNearestFreeCell(Combatant combatant)
		{
			BattleGridCellComponent nearest = null;

			if(this.cellRow != null &&
				combatant != null)
			{
				Vector3 position = combatant.GameObject != null ?
					combatant.GameObject.transform.position :
					(combatant.Object.BattleSpot != null ?
						combatant.Object.BattleSpot.transform.position :
						this.transform.position);

				float distance = Mathf.Infinity;
				int rowMax = (this.cellRow.Length / 2) - 1;
				int columnMax = (this.cellRow[0].cell.Length / 2) - 1;
				int row = -1;
				int column = -1;
				BattleGridHelper.GetRoughArea(this, position,
					0, 0, this.cellRow.Length, this.cellRow[0].cell.Length,
					ref row, ref column, ref rowMax, ref columnMax);

				if(row > 0 && column > 0)
				{
					for(int i = row - rowMax; i < row + rowMax; i++)
					{
						if(i >= 0 && i < this.cellRow.Length)
						{
							for(int j = column - columnMax; j < column + columnMax; j++)
							{
								if(j >= 0 && j < this.cellRow[i].cell.Length &&
									this.cellRow[i].cell[j] != null &&
									this.cellRow[i].cell[j].enabled &&
									this.cellRow[i].cell[j].gameObject.activeInHierarchy &&
									!this.cellRow[i].cell[j].IsBlocked &&
									this.cellRow[i].cell[j].IsEmpty)
								{
									float tmp = Vector3.Distance(position,
										this.cellRow[i].cell[j].transform.position);
									if(tmp < distance)
									{
										nearest = this.cellRow[i].cell[j];
										distance = tmp;
									}
								}
							}
						}
					}
				}

				if(nearest == null)
				{
					for(int i = 0; i < this.cellRow.Length; i++)
					{
						for(int j = 0; j < this.cellRow[i].cell.Length; j++)
						{
							if(this.cellRow[i].cell[j] != null &&
								this.cellRow[i].cell[j].enabled &&
								this.cellRow[i].cell[j].gameObject.activeInHierarchy &&
								!this.cellRow[i].cell[j].IsBlocked &&
								this.cellRow[i].cell[j].IsEmpty)
							{
								float tmp = Vector3.Distance(position,
									this.cellRow[i].cell[j].transform.position);
								if(tmp < distance)
								{
									nearest = this.cellRow[i].cell[j];
									distance = tmp;
								}
							}
						}
					}
				}
			}
			return nearest;
		}

		public virtual BattleGridCellComponent GetNearestDeploymentCell(Combatant combatant, bool checkMemberIndex)
		{
			BattleGridCellComponent nearest = null;

			if(this.cellRow != null &&
				combatant != null)
			{
				this.FindDeploymentCells();

				float distance = Mathf.Infinity;
				Vector3 position = combatant.GameObject != null ?
					combatant.GameObject.transform.position :
					(combatant.Object.BattleSpot != null ?
						combatant.Object.BattleSpot.transform.position :
						this.transform.position);
				int memberIndex = checkMemberIndex ? combatant.Group.GetBattleMemberIndex(combatant) : -1;

				for(int i = 0; i < this.deploymentCells.Count; i++)
				{
					if(this.deploymentCells[i] != null &&
						this.deploymentCells[i].enabled &&
						this.deploymentCells[i].gameObject.activeInHierarchy &&
						this.deploymentCells[i].CanDeploy(combatant) &&
						(!checkMemberIndex || this.deploymentCells[i].Deployment.preferredMemberIndex == memberIndex))
					{
						float tmp = Vector3.Distance(position,
							this.deploymentCells[i].transform.position);
						if(tmp < distance)
						{
							nearest = this.deploymentCells[i];
							distance = tmp;
						}
					}
				}

				if(checkMemberIndex &&
					nearest == null)
				{
					return this.GetNearestDeploymentCell(combatant, false);
				}
			}

			return nearest;
		}

		public virtual void JoinDeploymentCombatants(BattleSystem battleSystem)
		{
			this.FindDeploymentCells();

			for(int i = 0; i < this.deploymentCells.Count; i++)
			{
				if(this.deploymentCells[i] != null &&
					this.deploymentCells[i].enabled &&
					this.deploymentCells[i].gameObject.activeInHierarchy &&
					GridDeploymentType.Combatant == this.deploymentCells[i].Deployment.type)
				{
					Combatant combatant = this.deploymentCells[i].Deployment.GetDeploymentCombatant(battleSystem, this.deploymentCells[i]);
					if(combatant != null)
					{
						this.deploymentCells[i].SetCombatant(combatant, false);
						ORK.Battle.Join(combatant);
					}
				}
			}
		}

		protected virtual void FindDeploymentCells()
		{
			if(!this.deploymentCellsSearched)
			{
				this.deploymentCellsSearched = true;
				this.deploymentCells = new List<BattleGridCellComponent>();

				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null &&
							this.cellRow[i].cell[j].IsDeployment)
						{
							this.deploymentCells.Add(this.cellRow[i].cell[j]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public virtual void ShowGridPrefabs()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellRow[i].cell[j].ShowPrefab();
						}
					}
				}
			}
		}

		public virtual void HideGridPrefabs()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellRow[i].cell[j].HidePrefab();
						}
					}
				}
			}
		}

		public virtual void RemoveGridPrefabs()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellRow[i].cell[j].DestroyPrefab();
						}
					}
				}
			}
		}

		public virtual void ResetGridCellTypeOverrides()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellRow[i].cell[j].CellTypeOverride = null;
						}
					}
				}
			}
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public virtual bool HighlightsHiddenByUI
		{
			get { return this.highlightsHiddenByUI; }
			set
			{
				if(this.highlightsHiddenByUI != value)
				{
					this.highlightsHiddenByUI = value;
					this.UpdateHighlightHideState();
				}
			}
		}

		public virtual void UpdateHighlightHideState()
		{
			bool systemHideState = ORK.BattleGridHighlights.HideGridHighlights;

			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellRow[i].cell[j].HideHighlights(this.highlightsHiddenByUI, systemHideState);
						}
					}
				}
			}

			if(this.lineHighlight != null)
			{
				foreach(KeyValuePair<GridCellHighlight, RuntimeLineGridHighlight> pair in this.lineHighlight)
				{
					pair.Value.Hidden = systemHideState ||
						ORK.BattleGridHighlights.IsHidden(pair.Key);
				}
			}
		}

		public virtual void LineHighlight(GridCellHighlight type, LineGridHighlight settings, BattleGridCellComponent cell)
		{
			if(this.lineHighlight == null)
			{
				this.lineHighlight = new Dictionary<GridCellHighlight, RuntimeLineGridHighlight>();
			}
			RuntimeLineGridHighlight highlight;
			if(!this.lineHighlight.TryGetValue(type, out highlight))
			{
				highlight = new RuntimeLineGridHighlight(settings, type);
				this.lineHighlight.Add(type, highlight);
			}
			highlight.Highlight(cell);
		}

		public virtual void LineHighlight(GridCellHighlight type, LineGridHighlight settings, List<BattleGridCellComponent> cells)
		{
			if(this.lineHighlight == null)
			{
				this.lineHighlight = new Dictionary<GridCellHighlight, RuntimeLineGridHighlight>();
			}
			RuntimeLineGridHighlight highlight;
			if(!this.lineHighlight.TryGetValue(type, out highlight))
			{
				highlight = new RuntimeLineGridHighlight(settings, type);
				this.lineHighlight.Add(type, highlight);
			}
			highlight.Highlight(cells);
		}

		public virtual void StopLineHighlight(GridCellHighlight type, LineGridHighlight settings, BattleGridCellComponent cell)
		{
			if(this.lineHighlight != null &&
				Application.isPlaying)
			{
				RuntimeLineGridHighlight highlight;
				if(this.lineHighlight.TryGetValue(type, out highlight))
				{
					highlight.StopHighlight(cell);
				}
			}
		}

		public virtual void StopLineHighlight(GridCellHighlight type, LineGridHighlight settings, List<BattleGridCellComponent> cells)
		{
			if(this.lineHighlight != null &&
				Application.isPlaying)
			{
				RuntimeLineGridHighlight highlight;
				if(this.lineHighlight.TryGetValue(type, out highlight))
				{
					highlight.StopHighlight(cells);
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/BattleGridComponent Icon.png");

			if(this.showEditorGrid &&
				this.showEditorPrefabs &&
				this.showEditorUnselected &&
				!Application.isPlaying)
			{
				this.EditorShowPrefabs();
			}
		}

		public virtual void EditorShowPrefabs()
		{
			if(this.cellRow != null &&
				!this.editorPrefabsShowing)
			{
				this.editorPrefabsShowing = true;

				for(int i = 0; i < this.cellRow.Length; i++)
				{
					if(this.cellRow[i] != null)
					{
						for(int j = 0; j < this.cellRow[i].cell.Length; j++)
						{
							if(this.cellRow[i].cell[j] != null)
							{
								this.cellRow[i].cell[j].EditorShowPrefab();
							}
						}
					}
				}
			}
		}

		public virtual void EditorDestroyPrefabs()
		{
			this.editorPrefabsShowing = false;

			if(this.cellRow != null)
			{
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					if(this.cellRow[i] != null)
					{
						for(int j = 0; j < this.cellRow[i].cell.Length; j++)
						{
							if(this.cellRow[i].cell[j] != null &&
								this.cellRow[i].cell[j].PrefabInstance != null)
							{
								GameObject.DestroyImmediate(this.cellRow[i].cell[j].PrefabInstance);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// generation settings
			[EditorHelp("Rows", "The number of rows the generated grid will have.")]
			[EditorLimit(1, false)]
			public int rows = 10;

			[EditorHelp("Columns", "The number of columns the generated grid will have.")]
			[EditorLimit(1, false)]
			public int columns = 10;

			[EditorHelp("Position Anchor", "Select which point of the grid will be placed at this game object's position.")]
			public TextAnchor positionAnchor = TextAnchor.MiddleCenter;


			// cell settings
			[EditorSeparator]
			[EditorTitleLabel("Cell Settings")]
			[EditorHelp("Use Slope", "Use the slope of the ground hit by the raycast to rotate the cell.\n" +
				"The slope isn't used in 2D grids (i.e. XY horizontal plane).")]
			public bool useSlope = false;

			[EditorHelp("Minimum Slope", "The minimum slope to use the slope for the cell's rotation.")]
			[EditorIndent]
			[EditorLimit(0, false)]
			[EditorCondition("useSlope", true)]
			[EditorEndCondition]
			public float minSlope = 0;

			[EditorHelp("Cell Type", "Select the grid cell type that will be used for regular cells.")]
			public AssetSelection<BattleGridCellTypeAsset> cellType = new AssetSelection<BattleGridCellTypeAsset>();

			[EditorHelp("Empty Cell Type", "Select the grid cell type that will be used for empty cells (i.e. where nothing was hit by the raycst).")]
			public AssetSelection<BattleGridCellTypeAsset> emptyCellType = new AssetSelection<BattleGridCellTypeAsset>();

			[EditorHelp("Use Blocked Type", "Use a different cell type for cells that are considered blocked due to the ground's slope.")]
			public bool useBlockedType = false;

			[EditorHelp("Block Slope", "A cell will use the blocked cell type if the ground's slope exceeds this value.")]
			[EditorCondition("useBlockedType", true)]
			public float blockedTypeSlope = 45;

			[EditorHelp("Blocked Cell Type", "Select the grid cell type that will be used for blocked cells.")]
			[EditorEndCondition]
			public AssetSelection<BattleGridCellTypeAsset> blockedCellType = new AssetSelection<BattleGridCellTypeAsset>();

			[EditorHelp("No Blocked Connections", "Blocked cells will not have connections to other cells.")]
			public bool noBlockedConnections = false;


			// raycast settings
			[EditorSeparator]
			[EditorTitleLabel("Raycast Settings")]
			[EditorHelp("Layer Mask", "The layer mask used by the raycast.")]
			public LayerMask rayLayerMask = -1;

			[EditorHelp("Source Offset", "The offset added to the raycast's source (position of this game object + checked cell position).")]
			public Vector3 raySourceOffset = new Vector3(0, 0, 0);

			[EditorHelp("Distance", "The distance used by the raycast.")]
			public float rayDistance = 100;

			[EditorHelp("Hit Offset", "The offset added to the hit position when placing the cells.")]
			public Vector3 rayHitOffset = Vector3.zero;

			[EditorHelp("Use Blocked Layer Mask", "Use a different layer mask to determine blocked cells.")]
			[EditorCondition("useBlockedType", true)]
			[EditorDefaultValue(false)]
			public bool useBlockedLayerMask = false;

			[EditorHelp("Blocked Layer Mask", "The layer mask used to determine blocked cells.")]
			[EditorCondition("useBlockedLayerMask", true)]
			[EditorEndCondition(2)]
			public LayerMask blockedLayerMask = -1;

			[EditorHelp("Use Empty Layer Mask", "Use a different layer mask to determine empty cells.")]
			public bool useEmptyLayerMask = false;

			[EditorHelp("Empty Layer Mask", "The layer mask used to determine empty cells.")]
			[EditorCondition("useEmptyLayerMask", true)]
			[EditorEndCondition]
			public LayerMask emptyLayerMask = -1;

			[EditorHelp("Check Cell Size Factor", "Blocked/Empty raycast checks use sphere casts with the cell size defined in the ORK editor.\n" +
				"You can change how much of the cell size is used via the cell size factor, i.e. when a cell is considered blocked/empty due to hitting something.")]
			[EditorCondition("useBlockedLayerMask", true)]
			[EditorCondition("useEmptyLayerMask", true)]
			[EditorEndCondition]
			[EditorLimit(0, 2)]
			public float sphereCastSize = 0.7f;


			// generation
			[EditorSeparator]
			[EditorHelp("Keep Old Cells", "Regenerating the grid will keep the old cells and only change their positions.")]
			public bool generateKeepOldCells = false;

			public Settings()
			{

			}
		}
	}
}
