
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	[AddComponentMenu("")]
	public sealed class ORKHandler : MonoBehaviour
	{
		// only to show ORK game information in the inspector
	}
}
