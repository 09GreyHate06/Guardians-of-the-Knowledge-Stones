﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.UI
{
	public class InvertSortingInputSettings : BaseData
	{
		// options
		[EditorHelp("Hidden Without Sorting", "This input is hidden if UI box's control doesn't use sorting.")]
		public bool hiddenWithoutSorting = true;

		[EditorHelp("Toggle Invert Key", "The key used to toggle inverting on/off.")]
		public AssetSelection<InputKeyAsset> toggleInvertKey = new AssetSelection<InputKeyAsset>();


		// content
		[EditorHelp("Add Tooltip", "Hovering the cursor over this input will show a tooltip.\n" +
			"The tooltip will use the content and description defined here.")]
		[EditorFoldout("Content", "The content of the invert sorting input, e.g. the name of the toggle or button.", "")]
		[EditorLabel("Current Sorting:\n" +
			"<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'")]
		public bool addTooltip = false;

		// main content
		[EditorFoldout("Normal Sorting Content", "The content of this input when normal (non-inverted) sorting is used.")]
		[EditorEndFoldout]
		[EditorLanguageExport("NormalSorting")]
		public Content normalContent = new Content("Ascend");

		[EditorFoldout("Inverted Sorting Content", "The content of this input when inverted sorting is used.")]
		[EditorEndFoldout]
		[EditorLanguageExport("InvertedSorting")]
		public Content invertedContent = new Content("Descend");

		// description
		[EditorHelp("Add Description", "Add a description to the input.", "")]
		[EditorFoldout("Description", "Optionally add a description to the input.", "")]
		public bool addDescription = false;

		[EditorHelp("Description Content", "The description content of this input.", "")]
		[EditorEndFoldout(2)]
		[EditorCondition("addDescription", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		[EditorLanguageExport("Description")]
		public LanguageData<TextImageContent> description;

		public InvertSortingInputSettings()
		{

		}

		public virtual V CreateContent<V>(IContent currentSorting, bool inverted) where V : UIInputContent, new()
		{
			Content usedContent = inverted ? this.invertedContent : this.normalContent;
			V content = usedContent.GetContent<V>();
			content.ReplaceContent(currentSorting);
			if(this.addDescription)
			{
				content.Description = this.description.Current;
			}
			if(this.addTooltip)
			{
				UIText name = usedContent.mainContent.Current.text;
				name.ReplaceContent(currentSorting);

				UIText description = this.addDescription ? this.description.Current.text : null;
				if(description != null)
				{
					description.ReplaceContent(currentSorting);
				}

				content.Tooltip = new TooltipContent(name.Text, null,
					description != null ? description.Text : "",
					usedContent.mainContent.Current.image.sprite,
					usedContent.mainContent.Current.image.texture);
			}
			return content;
		}
	}
}
