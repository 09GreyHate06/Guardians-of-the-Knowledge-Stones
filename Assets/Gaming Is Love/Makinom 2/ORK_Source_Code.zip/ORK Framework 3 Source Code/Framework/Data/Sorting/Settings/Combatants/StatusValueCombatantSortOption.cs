﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Status Value", "Sort the combatants by a status value.", "")]
	public class StatusValueCombatantSortOption<T> : BaseCombatantSortOption<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Status Value", "Select the status value that will be used to sort.\n" +
			"The combatants will be sorted from lowest to highest value.", "")]
		public AssetSelection<StatusValueAsset> status = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Min Value: The preview minimum value, displaying changes when an equipment would be equipped.\n" +
			"- Last Change Value: The last value used to change the status value.\n" +
			"- Last Combined Change Value: The combined value of the last changes to the status value.\n" +
			"- Last Combined Change Value Positive: The combined value of the last positive changes to the status value.\n" +
			"- Last Combined Change Value Negative: The combined value of the last negative changes to the status value.", "")]
		public StatusValueGetValue usedValue = StatusValueGetValue.CurrentValue;

		[EditorHelp("Invert Order", "Invert the sort order, i.e. sorting from highest to lowest value.")]
		public bool invertOrder = false;

		public StatusValueCombatantSortOption()
		{

		}

		public override string ToString()
		{
			return "Status Value(" + this.status.ToString() + ")";
		}

		public override void Sort(List<Combatant> list, IDataCall call)
		{
			list.Sort(new StatusValueSorter(this.status.StoredAsset.Settings, this.usedValue, this.invertOrder));
		}
	}
}
