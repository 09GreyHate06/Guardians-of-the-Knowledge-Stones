
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class StatusEffectSorter : IComparer<StatusEffect>
	{
		public int Compare(StatusEffect x , StatusEffect y)
		{
			if(x.Setting.priority == y.Setting.priority)
			{
				return x.ID.CompareTo(y.ID);
			}
			else
			{
				return x.Setting.priority.CompareTo(y.Setting.priority);
			}
		}
	}
}
