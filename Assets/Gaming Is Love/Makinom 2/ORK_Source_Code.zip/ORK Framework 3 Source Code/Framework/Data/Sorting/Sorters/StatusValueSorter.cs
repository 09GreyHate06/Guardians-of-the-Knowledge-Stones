﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class StatusValueSorter : IComparer<Combatant>
	{
		private StatusValueSetting statusValue;

		private StatusValueGetValue usedValue = StatusValueGetValue.CurrentValue;

		private bool inverse = false;

		public StatusValueSorter(StatusValueSetting statusValue, StatusValueGetValue usedValue, bool inverse)
		{
			this.statusValue = statusValue;
			this.usedValue = usedValue;
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(inverse)
			{
				return y.Status.Get(this.statusValue).GetTypeValue(this.usedValue).CompareTo(
					x.Status.Get(this.statusValue).GetTypeValue(this.usedValue));
			}
			else
			{
				return x.Status.Get(this.statusValue).GetTypeValue(this.usedValue).CompareTo(
					y.Status.Get(this.statusValue).GetTypeValue(this.usedValue));
			}
		}
	}
}
