﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

// TODO: support for sorting options in battle menus and item boxes
namespace GamingIsLove.ORKFramework
{
	public interface IUIBoxSortable
	{
		bool InvertSorting
		{
			get;
			set;
		}

		int SortingIndex
		{
			get;
			set;
		}

		int SortOptionCount
		{
			get;
		}

		SortOption GetCurrentSorting();

		SortOption[] GetSortOptions();

		event Notify SortingHasChanged;
	}

	public class SortingOptionSettings : BaseData
	{
		[EditorFoldout("Change Sorting Key", "Select the input key used to change the sorting.", "")]
		[EditorEndFoldout]
		public AudioInputSelection changeSortingKey = new AudioInputSelection();

		[EditorHelp("Remember Sorting", "Remember the current sorting option.", "")]
		public bool rememberSorting = false;

		[EditorArray("Add Sort Option", "Adds a sort option.", "",
			"Remove", "Removes this sort option.", "",
			isCopy = true, isMove = true, noRemoveCount = 1,
			foldout = true, foldoutText = new string[] {
				"Sort Option", "Define the sorting that will be used by this sort option.", ""
		})]
		public SortOption[] sortOption = new SortOption[]
		{
			new SortOption()
		};

		public SortingOptionSettings()
		{

		}

		public bool ChangeSorting(int inputID, ref int currentSorting)
		{
			if(this.sortOption.Length > 0)
			{
				if(this.changeSortingKey.GetButton(inputID))
				{
					currentSorting++;
					if(currentSorting >= this.sortOption.Length)
					{
						currentSorting = 0;
					}
					return true;
				}
				else
				{
					for(int i = 0; i < this.sortOption.Length; i++)
					{
						if(this.sortOption[i].useSortKey &&
							this.sortOption[i].sortKey.GetButton(inputID))
						{
							currentSorting = i;
							return true;
						}
					}
				}
			}
			return false;
		}
	}
}
