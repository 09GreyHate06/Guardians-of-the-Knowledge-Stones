﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.UI
{
	public class SortingCycleButtonSettings : BaseData
	{
		[EditorHelp("Hidden Without Sorting", "This input is hidden if UI box's control doesn't use sorting.")]
		public bool hiddenWithoutSorting = true;

		[EditorHelp("Cycle Sorting Key", "The key used to cycle through sorting options.")]
		public AssetSelection<InputKeyAsset> cycleSortingKey = new AssetSelection<InputKeyAsset>();


		// content
		[EditorHelp("Add Tooltip", "Hovering the cursor over this input will show a tooltip.\n" +
			"The tooltip will use the content and description defined here.")]
		[EditorFoldout("Content", "The content of the invert sorting input, e.g. the name of the toggle or button.", "")]
		[EditorLabel("Current Sorting:\n" +
			"<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'")]
		public bool addTooltip = false;

		// main content
		[EditorFoldout("Content", "The content of this input.")]
		[EditorEndFoldout]
		[EditorLanguageExport("NormalSorting")]
		public Content content = new Content("<name>");

		// description
		[EditorHelp("Add Description", "Add a description to the input.", "")]
		[EditorFoldout("Description", "Optionally add a description to the input.", "")]
		public bool addDescription = false;

		[EditorHelp("Description Content", "The description content of this input.", "")]
		[EditorEndFoldout(2)]
		[EditorCondition("addDescription", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		[EditorLanguageExport("Description")]
		public LanguageData<TextImageContent> description;

		public SortingCycleButtonSettings()
		{

		}

		public virtual UIButtonInputContent GetContent(IContent currentSorting)
		{
			UIButtonInputContent content = this.content.GetContent<UIButtonInputContent>();
			content.ReplaceContent(currentSorting);
			if(this.addDescription)
			{
				content.Description = this.description.Current;
			}
			if(this.addTooltip)
			{
				UIText name = this.content.mainContent.Current.text;
				name.ReplaceContent(currentSorting);

				UIText description = this.addDescription ? this.description.Current.text : null;
				if(description != null)
				{
					description.ReplaceContent(currentSorting);
				}

				content.Tooltip = new TooltipContent(name.Text, null,
					description != null ? description.Text : "",
					this.content.mainContent.Current.image.sprite,
					this.content.mainContent.Current.image.texture);
			}
			return content;
		}
	}
}
