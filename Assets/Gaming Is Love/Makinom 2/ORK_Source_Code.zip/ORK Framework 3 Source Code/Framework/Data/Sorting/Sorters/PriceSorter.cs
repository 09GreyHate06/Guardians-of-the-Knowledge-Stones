﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class BuyPriceSorter : IComparer<IPriceShortcut>
	{
		private Combatant user;

		private bool quantityPrice = false;

		private bool invert = false;

		public BuyPriceSorter(Combatant user, bool quantityPrice, bool invert)
		{
			this.user = user;
			this.quantityPrice = quantityPrice;
			this.invert = invert;
		}

		public int Compare(IPriceShortcut x, IPriceShortcut y)
		{
			if(this.invert)
			{
				int result = y.GetBuyPriceSorting(user, this.quantityPrice ? y.Quantity : 1).CompareTo(x.GetBuyPriceSorting(user, this.quantityPrice ? x.Quantity : 1));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
			else
			{
				int result = x.GetBuyPriceSorting(user, this.quantityPrice ? x.Quantity : 1).CompareTo(y.GetBuyPriceSorting(user, this.quantityPrice ? y.Quantity : 1));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
		}
	}

	public class SellPriceSorter : IComparer<IPriceShortcut>
	{
		private Combatant user;

		private bool quantityPrice = false;

		private bool invert = false;

		public SellPriceSorter(Combatant user, bool quantityPrice, bool invert)
		{
			this.user = user;
			this.quantityPrice = quantityPrice;
			this.invert = invert;
		}

		public int Compare(IPriceShortcut x, IPriceShortcut y)
		{
			if(this.invert)
			{
				int result = y.GetSellPriceSorting(user, this.quantityPrice ? y.Quantity : 1).CompareTo(x.GetSellPriceSorting(user, this.quantityPrice ? x.Quantity : 1));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
			else
			{
				int result = x.GetSellPriceSorting(user, this.quantityPrice ? x.Quantity : 1).CompareTo(y.GetSellPriceSorting(user, this.quantityPrice ? y.Quantity : 1));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
		}
	}
}
