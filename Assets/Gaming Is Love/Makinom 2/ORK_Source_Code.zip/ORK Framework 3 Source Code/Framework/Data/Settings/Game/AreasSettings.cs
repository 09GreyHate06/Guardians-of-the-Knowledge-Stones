
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class AreasSettings : GenericAssetListSettings<AreaAsset, Area>
	{
		public AreasSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Areas"; }
		}
	}
}

