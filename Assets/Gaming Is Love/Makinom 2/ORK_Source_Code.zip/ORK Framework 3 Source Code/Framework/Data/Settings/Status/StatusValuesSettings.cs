
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class StatusValuesSettings : GenericAssetListSettings<StatusValueAsset, StatusValueSetting>
	{
		// in-game
		protected StatusValueSetting baseLevelExp;

		protected StatusValueSetting classLevelExp;

		protected bool hasCombined = false;

		public StatusValuesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			// check if combined values are used
			this.hasCombined = false;
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i].Settings.IsNormal() &&
					this.assets[i].Settings.combined)
				{
					this.hasCombined = true;
					break;
				}
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Status Values"; }
		}

		public virtual bool HasCombined
		{
			get { return this.hasCombined; }
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public void SetStatusValueType(StatusValueSetting statusValue, StatusValueType val)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i].Settings.IsConsumable() &&
					this.assets[i].Settings.barrier != null)
				{
					for(int j = 0; j < this.assets[i].Settings.barrier.Length; j++)
					{
						if(this.assets[i].Settings.barrier[j].status.Is(statusValue))
						{
							ArrayHelper.RemoveAt(ref this.assets[i].Settings.barrier, j--);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual StatusValueSetting GetBaseLevel()
		{
			if(this.baseLevelExp == null)
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i].Settings.IsExperience() &&
						ExperienceType.Level == this.assets[i].Settings.expType)
					{
						this.baseLevelExp = this.assets[i].Settings;
						break;
					}
				}
			}
			return this.baseLevelExp;
		}

		public virtual StatusValueSetting GetClassLevel()
		{
			if(this.classLevelExp == null)
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i].Settings.IsExperience() &&
						ExperienceType.ClassLevel == this.assets[i].Settings.expType)
					{
						this.classLevelExp = this.assets[i].Settings;
						break;
					}
				}
			}
			return this.classLevelExp;
		}
	}
}
