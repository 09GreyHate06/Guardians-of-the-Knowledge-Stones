﻿
using UnityEngine;
using GamingIsLove.ORKFramework.UI;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework
{
	public class CombatantSelectionsSettings : BaseSettings
	{
		// menu user
		[EditorHelp("Menu User", "Used when the user of a menu is selected.", "")]
		[EditorFoldout("Default Combatant Selections", "Define the default combatant selection options.", "")]
		public AssetSelection<CombatantSelectionAsset> menuUser = new AssetSelection<CombatantSelectionAsset>();

		// ability
		[EditorHelp("Ability Target", "Used when the target of an ability is selected.", "")]
		public AssetSelection<CombatantSelectionAsset> abilityTarget = new AssetSelection<CombatantSelectionAsset>();

		// item
		[EditorHelp("Item Target", "Used when the target of an item is selected.", "")]
		public AssetSelection<CombatantSelectionAsset> itemTarget = new AssetSelection<CombatantSelectionAsset>();

		// equipment
		[EditorHelp("Equip Target", "Used when equipping an equipment on another combatant.", "")]
		public AssetSelection<CombatantSelectionAsset> equipTarget = new AssetSelection<CombatantSelectionAsset>();

		// give
		[EditorHelp("Give Target", "Used when giving items to another combatant.", "")]
		[EditorEndFoldout]
		public AssetSelection<CombatantSelectionAsset> giveTarget = new AssetSelection<CombatantSelectionAsset>();

		public CombatantSelectionsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Combatant Selections"; }
		}
	}
}
