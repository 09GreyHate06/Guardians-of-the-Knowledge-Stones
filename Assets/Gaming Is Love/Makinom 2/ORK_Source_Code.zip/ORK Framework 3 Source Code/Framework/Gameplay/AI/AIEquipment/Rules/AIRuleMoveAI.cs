﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIRuleMoveAI : BaseData
	{
		[EditorHelp("Change On Use", "Only change the move AI when an action of this AI ruleset is used.", "")]
		public bool moveAIChangeOnUse = false;

		[EditorSeparator]
		public MoveAIChange moveAIChange = new MoveAIChange();

		public AIRuleMoveAI()
		{

		}
	}
}
