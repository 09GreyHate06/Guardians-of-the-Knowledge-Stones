
using UnityEngine;
using GamingIsLove.ORKFramework.Combatants;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using System.Text;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Check Turn", "Checks a combatant's turn number (i.e. the number of actions/turns performed by the combatant).\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckTurnNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// turn
		[EditorHelp("Every n Turns", "The check is true every set number of turns " +
			"(e.g. every 2nd turn when 'turn' is set to 2).\n" +
			"If disabled, the check is true at the specific turn number " +
			"(e.g. the 5th turn of a combatant).", "")]
		[EditorSeparator]
		[EditorTitleLabel("Turn")]
		public bool everyTurn = false;

		[EditorHelp("Turn", "Set the turn that will be checked for.", "")]
		[EditorLimit(1, false)]
		[EditorCondition("everyTurn", true)]
		public int turn = 1;

		[EditorElseCondition]
		[EditorEndCondition]
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>(1);

		public CheckTurnNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check turns of all possible targets, add to found targets
			for(int i = 0; i < list.Count; i++)
			{
				call.checkTarget = list[i];
				if(list[i] != null &&
					(this.everyTurn ?
						((list[i].Battle.Turn % this.turn) == 0) :
						this.check.Check(list[i].Battle.Turn, call)))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() + ": " + (this.everyTurn ?
				(this.turn == 1 ? "Every turn" : "Every " + this.turn + " turns") :
				this.check + " " + this.turn);
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Turn Value", "Checks a combatant's turn value.\n" +
		"The turn value is used to generate the turn order in 'Turn Based Battles' using 'Multi Turns'.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckTurnValueNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();

		[EditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		[EditorSeparator]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;


		// check
		[EditorSeparator]
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public CheckTurnValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check turns of all possible targets, add to found targets
			for(int i = 0; i < list.Count; i++)
			{
				call.checkTarget = list[i];
				if(list[i] != null &&
					this.check.Check(
						this.useAverage ?
							(this.onlyBattle ?
								list[i].Group.AverageBattleTurnValue :
								list[i].Group.AverageTurnValue) :
							list[i].Battle.TurnValue,
						call))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() + ": " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Action Bar", "Checks a combatant's action bar.\n" +
		"In 'Turn Based Battles' and 'Phase Battles', the action bar represents the actions per turn of the combatant.\n" +
		"In 'Active Time Battles', the action bar represents the timebar of the combatant.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckActionBarNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();

		[EditorHelp("Used Action Bar", "Check the 'Used Action Bar' instead of the 'Action Bar'.\n" +
			"The 'Used Action Bar' defines how much of the action bar is already used by actions.\n" +
			"In 'Turn Based Battles' and 'Phase Battles', the used action bar will be increased by the actions the combatant selected.\n" +
			"In 'Active Time Battles', the used action bar defines how much of the timebar has already been used.\n" +
			"E.g. use this to check if a combatant already chose actions by checking if the used action bar equals 0.", "")]
		[EditorSeparator]
		public bool usedActionBar = false;

		[EditorHelp("Use Average", "Use the average action bar value of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		// check
		[EditorSeparator]
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public CheckActionBarNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				call.checkTarget = list[i];
				if(list[i] != null &&
					this.check.Check(
						this.useAverage ?
							(this.onlyBattle ?
								(this.usedActionBar ?
									list[i].Group.AverageBattleUsedActionBar :
									list[i].Group.AverageBattleActionBar) :
								(this.usedActionBar ?
									list[i].Group.AverageUsedActionBar :
									list[i].Group.AverageActionBar)) :
							(this.usedActionBar ?
								list[i].Battle.UsedActionBar :
								list[i].Battle.ActionBar),
						call))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() + ": " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Action Time", "Checks a combatant's action time.\n" +
		"The action time is an optional feature to limit the time a combatant has to perform actions.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckActionTimeNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();

		[EditorHelp("Use Maximum", "Use the maximum action time of the combatant.", "")]
		[EditorSeparator]
		public bool useMax = false;

		[EditorHelp("Use Average", "Use the average action time of the combatant's group.", "")]
		public bool useAverage = false;

		[EditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[EditorCondition("useAverage", true)]
		[EditorEndCondition]
		public bool onlyBattle = true;

		// check
		[EditorSeparator]
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public CheckActionTimeNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				call.checkTarget = list[i];
				if(list[i] != null &&
					this.check.Check(
						this.useAverage ?
							(this.onlyBattle ?
								(this.useMax ?
									list[i].Group.AverageBattleActionTimeMax :
									list[i].Group.AverageBattleActionTime) :
								(this.useMax ?
									list[i].Group.AverageActionTimeMax :
									list[i].Group.AverageActionTime)) :
							(this.useMax ?
								list[i].Battle.ActionTimeMax :
								list[i].Battle.ActionTime),
						call))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() + ": " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Status", "Checks a combatant for defined status conditions, e.g. status value.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the conditions will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckStatusNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();

		[EditorHelp("Force Knowledge", "Force status checks to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		[EditorSeparator]
		public bool forceKnowledge = false;

		[EditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[EditorSeparator]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[EditorHelp("Combatants Needed", "Either all or only one combatant must match the defined status conditions.", "")]
		[EditorCondition("combatantScope", MenuCombatantScope.Current)]
		[EditorElseCondition]
		[EditorEndCondition]
		public Needed combatantsNeeded = Needed.All;


		// status
		[EditorSeparator]
		[EditorTitleLabel("Status Conditions")]
		public StatusConditionSettings statusConditions = new StatusConditionSettings();

		public CheckStatusNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status contisions
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					this.CheckConditions(call.user, list[i]))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckConditions(Combatant user, Combatant target)
		{
			// bestiary
			if(!this.forceKnowledge &&
				ORK.Game.Bestiary.UseInBattleAI &&
				user.IsPlayerControlled() && user.IsEnemy(target))
			{
				if(MenuCombatantScope.Current == this.combatantScope)
				{
					return this.statusConditions.CheckBestiary(target);
				}
				else
				{
					List<Combatant> group = new List<Combatant>();
					target.Group.GetMembers(this.combatantScope, ref group);
					for(int i = 0; i < group.Count; i++)
					{
						if(this.statusConditions.CheckBestiary(group[i]))
						{
							if(Needed.One == this.combatantsNeeded)
							{
								return true;
							}
						}
						else if(Needed.All == this.combatantsNeeded)
						{
							return false;
						}
					}
					return Needed.All == this.combatantsNeeded;
				}
			}
			// normal
			else
			{
				if(MenuCombatantScope.Current == this.combatantScope)
				{
					return this.statusConditions.Check(target);
				}
				else
				{
					List<Combatant> group = new List<Combatant>();
					target.Group.GetMembers(this.combatantScope, ref group);
					for(int i = 0; i < group.Count; i++)
					{
						if(this.statusConditions.Check(group[i]))
						{
							if(Needed.One == this.combatantsNeeded)
							{
								return true;
							}
						}
						else if(Needed.All == this.combatantsNeeded)
						{
							return false;
						}
					}
					return Needed.All == this.combatantsNeeded;
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			string text = this.targetSettings.ToString() + ": " + this.statusConditions.needed;
			for(int i = 0; i < this.statusConditions.condition.Length; i++)
			{
				text += "\n- " + this.statusConditions.condition[i].ToString();
			}
			return text;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Get Status Value", "The combatant with the highest or lowest value of a " +
		"selected status value will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant")]
	public class GetStatusValueNode : BaseAINode
	{
		public BattleAISingleTargetSettings targetSettings = new BattleAISingleTargetSettings();

		[EditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		[EditorSeparator]
		public bool forceKnowledge = false;


		// status
		[EditorHelp("Status Value", "Select the status value that will be checked.", "")]
		[EditorSeparator]
		public AssetSelection<StatusValueAsset> status = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"selected status value will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the selected status value will be added to the target list.", "")]
		public bool getHighest = false;

		[EditorHelp("All Matching", "Use all combatants that have the highest/lowest value (i.e. matching values).\n" +
			"If disabled, only the first found combatant will be used.", "")]
		public bool allMatching = false;

		public GetStatusValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.status.StoredAsset != null)
			{
				this.targetSettings.Use(call, this.Check);
			}
			currentNode = this.next;
			return null;
		}

		private void Check(BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			int tmpVal = this.getHighest ? int.MinValue : int.MaxValue;

			// check for highest/lowest status value
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(!this.forceKnowledge &&
						ORK.Game.Bestiary.UseInBattleAI &&
						call.user.IsPlayerControlled() &&
						call.user.IsEnemy(list[i]))
					{
						if(list[i].Bestiary != null &&
							(list[i].Bestiary.IsComplete ||
							list[i].Bestiary.status.statusValues))
						{
							int statVal = list[i].Status.Get(this.status.StoredAsset.Settings).GetValue();
							if((this.getHighest && tmpVal < statVal) ||
								(!this.getHighest && tmpVal > statVal))
							{
								tmpVal = statVal;
								found = i;
							}
						}
					}
					else
					{
						int statVal = list[i].Status.Get(this.status.StoredAsset.Settings).GetValue();
						if((this.getHighest && tmpVal < statVal) ||
							(!this.getHighest && tmpVal > statVal))
						{
							tmpVal = statVal;
							found = i;
						}
					}
				}
			}

			if(found >= 0)
			{
				if(this.allMatching)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(!this.forceKnowledge &&
								ORK.Game.Bestiary.UseInBattleAI &&
								call.user.IsPlayerControlled() &&
								call.user.IsEnemy(list[i]))
							{
								if(list[i].Bestiary != null &&
									(list[i].Bestiary.IsComplete ||
									list[i].Bestiary.status.statusValues))
								{
									if(tmpVal == list[i].Status.Get(this.status.StoredAsset.Settings).GetValue() &&
										!foundTargets.Contains(list[i]))
									{
										foundTargets.Add(list[i]);
									}
								}
							}
							else
							{
								if(tmpVal == list[i].Status.Get(this.status.StoredAsset.Settings).GetValue() &&
									!foundTargets.Contains(list[i]))
								{
									foundTargets.Add(list[i]);
								}
							}
						}
					}
				}
				else if(!foundTargets.Contains(list[found]))
				{
					foundTargets.Add(list[found]);
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") + this.status.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Get Attack Modifier", "The combatant with the highest or lowest value of a " +
		"selected attack modifier will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant")]
	public class GetAttackModifierNode : BaseAINode
	{
		public BattleAISingleTargetSettings targetSettings = new BattleAISingleTargetSettings();

		[EditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		[EditorSeparator]
		public bool forceKnowledge = false;


		// status
		public AttackModifierAttributeSelection attackModifier = new AttackModifierAttributeSelection();

		[EditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"selected attack modifier attribute will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the " +
			"selected attack modifier attribute will be added to the target list.", "")]
		public bool getHighest = false;

		[EditorHelp("All Matching", "Use all combatants that have the highest/lowest value (i.e. matching values).\n" +
			"If disabled, only the first found combatant will be used.", "")]
		public bool allMatching = false;

		public GetAttackModifierNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			this.targetSettings.Use(call, this.Check);

			currentNode = this.next;
			return null;
		}

		private void Check(BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			float tmpVal = this.getHighest ? Mathf.NegativeInfinity : Mathf.Infinity;

			// check for highest/lowest value
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(!this.forceKnowledge &&
						ORK.Game.Bestiary.UseInBattleAI &&
						call.user.IsPlayerControlled() &&
						call.user.IsEnemy(list[i]))
					{
						if(list[i].Bestiary != null &&
							(list[i].Bestiary.IsComplete ||
								this.attackModifier.CheckBestiary(list[i])))
						{
							float value = this.attackModifier.GetValue(list[i], ModifierGetValue.CurrentValue);
							if((this.getHighest && tmpVal < value) ||
								(!this.getHighest && tmpVal > value))
							{
								tmpVal = value;
								found = i;
							}
						}
					}
					else
					{
						float value = this.attackModifier.GetValue(list[i], ModifierGetValue.CurrentValue);
						if((this.getHighest && tmpVal < value) ||
							(!this.getHighest && tmpVal > value))
						{
							tmpVal = value;
							found = i;
						}
					}
				}
			}

			if(found >= 0)
			{
				if(this.allMatching)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(!this.forceKnowledge &&
								ORK.Game.Bestiary.UseInBattleAI &&
								call.user.IsPlayerControlled() &&
								call.user.IsEnemy(list[i]))
							{
								if(list[i].Bestiary != null &&
									(list[i].Bestiary.IsComplete ||
										this.attackModifier.CheckBestiary(list[i])))
								{
									if(tmpVal == this.attackModifier.GetValue(list[i], ModifierGetValue.CurrentValue) &&
										!foundTargets.Contains(list[i]))
									{
										foundTargets.Add(list[i]);
									}
								}
							}
							else
							{
								if(tmpVal == this.attackModifier.GetValue(list[i], ModifierGetValue.CurrentValue) &&
									!foundTargets.Contains(list[i]))
								{
									foundTargets.Add(list[i]);
								}
							}
						}
					}
				}
				else if(!foundTargets.Contains(list[found]))
				{
					foundTargets.Add(list[found]);
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") + this.attackModifier.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Get Defence Modifier", "The combatant with the highest or lowest value of a " +
		"selected defence modifier will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant")]
	public class GetDefenceModifierNode : BaseAINode
	{
		public BattleAISingleTargetSettings targetSettings = new BattleAISingleTargetSettings();

		[EditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		[EditorSeparator]
		public bool forceKnowledge = false;


		// status
		public DefenceModifierAttributeSelection defenceModifier = new DefenceModifierAttributeSelection();

		[EditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"selected defence modifier attribute will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the " +
			"selected defence modifier attribute will be added to the target list.", "")]
		public bool getHighest = false;

		[EditorHelp("All Matching", "Use all combatants that have the highest/lowest value (i.e. matching values).\n" +
			"If disabled, only the first found combatant will be used.", "")]
		public bool allMatching = false;

		public GetDefenceModifierNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			this.targetSettings.Use(call, this.Check);

			currentNode = this.next;
			return null;
		}

		private void Check(BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			float tmpVal = this.getHighest ? Mathf.NegativeInfinity : Mathf.Infinity;

			// check for highest/lowest value
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(!this.forceKnowledge &&
						ORK.Game.Bestiary.UseInBattleAI &&
						call.user.IsPlayerControlled() &&
						call.user.IsEnemy(list[i]))
					{
						if(list[i].Bestiary != null &&
							(list[i].Bestiary.IsComplete ||
								this.defenceModifier.CheckBestiary(list[i])))
						{
							float value = this.defenceModifier.GetValue(list[i], ModifierGetValue.CurrentValue);
							if((this.getHighest && tmpVal < value) ||
								(!this.getHighest && tmpVal > value))
							{
								tmpVal = value;
								found = i;
							}
						}
					}
					else
					{
						float value = this.defenceModifier.GetValue(list[i], ModifierGetValue.CurrentValue);
						if((this.getHighest && tmpVal < value) ||
							(!this.getHighest && tmpVal > value))
						{
							tmpVal = value;
							found = i;
						}
					}
				}
			}

			if(found >= 0)
			{
				if(this.allMatching)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(!this.forceKnowledge &&
								ORK.Game.Bestiary.UseInBattleAI &&
								call.user.IsPlayerControlled() &&
								call.user.IsEnemy(list[i]))
							{
								if(list[i].Bestiary != null &&
									(list[i].Bestiary.IsComplete ||
										this.defenceModifier.CheckBestiary(list[i])))
								{
									if(tmpVal == this.defenceModifier.GetValue(list[i], ModifierGetValue.CurrentValue) &&
										!foundTargets.Contains(list[i]))
									{
										foundTargets.Add(list[i]);
									}
								}
							}
							else
							{
								if(tmpVal == this.defenceModifier.GetValue(list[i], ModifierGetValue.CurrentValue) &&
									!foundTargets.Contains(list[i]))
								{
									foundTargets.Add(list[i]);
								}
							}
						}
					}
				}
				else if(!foundTargets.Contains(list[found]))
				{
					foundTargets.Add(list[found]);
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") + this.defenceModifier.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Compare Status Value", "Checks the status value of targets against the user's value and adds them to the target list.\n" +
		"E.g. add all enemies that have less HP than the user.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant")]
	public class CompareStatusValueNode : BaseAINode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();

		[EditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		[EditorSeparator]
		public bool forceKnowledge = false;


		// check failed
		[EditorHelp("Use 'Failed' Next", "Enables using a different 'Next' node when the check fails.\n" +
			"If the check fails, the combatants that failed will be added to the found targets " +
			"(the previously found targets will also be filtered to only contain those who failed when using 'Check' found targets).", "")]
		[EditorSeparator]
		public bool useFailedNext = false;

		[EditorHide]
		[EditorCondition("useFailedNext", true)]
		[EditorEndCondition]
		[EditorDefaultValue(-1)]
		public int nextFail = -1;


		// status
		[EditorHelp("Status Value", "Select the status value that will be checked.", "")]
		[EditorSeparator]
		public AssetSelection<StatusValueAsset> status = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Check Type", "Checks if the target's status value is equal, not equal, less or greater than the user's status value.\n" +
			"Range inclusive checks if the target's status value is between two defined status values, including them.\n" +
			"Range exclusive checks if the target's status value is between two defined status values, excluding them.\n" +
			"Approximately checks if the target's status value is equal to the defined status value.", "")]
		public ValueCheckType checkType = ValueCheckType.IsEqual;

		[EditorHelp("Status Value 2", "Select the status value used for the check (upper limit).", "")]
		[EditorCondition("checkType", ValueCheckType.RangeInclusive)]
		[EditorCondition("checkType", ValueCheckType.RangeExclusive)]
		[EditorEndCondition]
		public AssetSelection<StatusValueAsset> status2 = new AssetSelection<StatusValueAsset>();


		// percent
		[EditorHelp("Check In", "Check either in percent of the maximum status value or the actual value.", "")]
		[EditorSeparator]
		public ValueSetter checkIn = ValueSetter.Value;

		[EditorHelp("Use Percent Value", "Define a percent value that will be checked.\n" +
			"E.g. 50 to check the target's status value against 50 % of the user's status value.", "")]
		[EditorCondition("checkIn", ValueSetter.Percent)]
		public bool usePercentValue = false;

		[EditorHelp("Percent Value", "The percent value that will be checked.")]
		[EditorCondition("usePercentValue", true)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public FloatValue<BattleAIObjectSelection> percentValue;


		// check other
		[EditorHelp("Check Other SV", "Check a different status value on the targets.\n" +
			"E.g. comparing the user's HP ('Status Value' setting) to the target's MP ('Target Status Value' setting).", "")]
		[EditorSeparator]
		public bool checkOther = false;

		[EditorHelp("Target Status Value", "Select the status value that will be checked.", "")]
		[EditorCondition("checkOther", true)]
		[EditorEndCondition]
		public AssetSelection<StatusValueAsset> targetStatus = new AssetSelection<StatusValueAsset>();

		public CompareStatusValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(FoundTargets.Clear == this.targetSettings.foundType)
			{
				call.foundTargets.Clear();
			}

			bool any = false;
			List<Combatant> targets = this.targetSettings.targetSettings.GetTargetList(call);

			if(this.useFailedNext)
			{
				List<Combatant> validFound = new List<Combatant>();
				if(targets.Count == 0 &&
					(FoundTargets.Check == this.targetSettings.foundType ||
						FoundTargets.CheckKeep == this.targetSettings.foundType))
				{
					this.Check(ref any, call, call.user, call.foundTargets, validFound, true);
					validFound.Clear();
				}
				else
				{
					this.Check(ref any, call, call.user, targets, validFound, true);
				}

				if(any)
				{
					if(FoundTargets.Check == this.targetSettings.foundType)
					{
						List<Combatant> tmp = new List<Combatant>(call.foundTargets);
						call.foundTargets.Clear();
						this.Check(ref any, call, call.user, tmp, call.foundTargets, true);
					}
					else if(FoundTargets.CheckKeep == this.targetSettings.foundType)
					{
						this.Check(ref any, call, call.user, call.foundTargets, call.foundTargets, true);
					}
					for(int i = 0; i < validFound.Count; i++)
					{
						if(!this.targetSettings.dontAddTargets &&
							!call.foundTargets.Contains(validFound[i]))
						{
							call.foundTargets.Add(validFound[i]);
						}
					}

					currentNode = this.next;
				}
				else
				{
					if(FoundTargets.Check == this.targetSettings.foundType)
					{
						List<Combatant> tmp = new List<Combatant>(call.foundTargets);
						call.foundTargets.Clear();
						this.Check(ref any, call, call.user, tmp, call.foundTargets, false);
					}
					else if(FoundTargets.CheckKeep == this.targetSettings.foundType)
					{
						this.Check(ref any, call, call.user, call.foundTargets, call.foundTargets, false);
					}
					this.Check(ref any, call, call.user, targets, call.foundTargets, false);

					currentNode = this.nextFail;
				}
			}
			else
			{
				if(FoundTargets.Check == this.targetSettings.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, call, call.user, tmp, call.foundTargets, true);
				}
				else if(FoundTargets.CheckKeep == this.targetSettings.foundType)
				{
					this.Check(ref any, call, call.user, call.foundTargets, call.foundTargets, true);
				}

				// check all possible targets
				this.Check(ref any, call, call.user, targets, call.foundTargets, true);

				currentNode = this.next;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, Combatant user, List<Combatant> list, List<Combatant> foundTargets, bool valid)
		{
			if(this.status.StoredAsset != null &&
				((ValueCheckType.RangeInclusive != this.checkType &&
						ValueCheckType.RangeExclusive != this.checkType) ||
					this.status2.StoredAsset != null))
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						bool doCheck = true;

						if(!this.forceKnowledge &&
							ORK.Game.Bestiary.UseInBattleAI &&
							user.IsPlayerControlled() && user.IsEnemy(list[i]))
						{
							doCheck = false;
							if(list[i].Bestiary != null &&
								(list[i].Bestiary.IsComplete ||
								list[i].Bestiary.status.statusValues))
							{
								doCheck = true;
							}
						}

						if(doCheck)
						{
							if(ValueSetter.Percent == this.checkIn)
							{
								if(this.usePercentValue)
								{
									call.checkTarget = list[i];
									float tmpValue = user.Status.Get(this.status.StoredAsset.Settings).GetValue() *
										(this.percentValue.GetValue(call) / 100.0f);
									float tmpValue2 = 0;
									if(ValueCheckType.RangeInclusive == this.checkType ||
										ValueCheckType.RangeExclusive == this.checkType)
									{
										tmpValue2 = user.Status.Get(this.status2.StoredAsset.Settings).GetValue() *
											(this.percentValue.GetValue(call) / 100.0f);
									}

									if(ValueHelper.CheckValue(
										list[i].Status.Get(this.checkOther && this.targetStatus.StoredAsset != null ?
											this.targetStatus.StoredAsset.Settings :
											this.status.StoredAsset.Settings).GetValue(),
										tmpValue, tmpValue2, this.checkType) == valid)
									{
										any = true;
										if(!this.targetSettings.dontAddTargets &&
											!foundTargets.Contains(list[i]))
										{
											foundTargets.Add(list[i]);
										}
									}
								}
								else if(ValueHelper.CheckValue(
									list[i].Status.Get(this.checkOther && this.targetStatus.StoredAsset != null ?
										this.targetStatus.StoredAsset.Settings :
										this.status.StoredAsset.Settings).Percent,
									user.Status.Get(this.status.StoredAsset.Settings).Percent,
									ValueCheckType.RangeInclusive == this.checkType || ValueCheckType.RangeExclusive == this.checkType ?
										user.Status.Get(this.status2.StoredAsset.Settings).Percent : 0,
									this.checkType) == valid)
								{
									any = true;
									if(!this.targetSettings.dontAddTargets &&
										!foundTargets.Contains(list[i]))
									{
										foundTargets.Add(list[i]);
									}
								}
							}
							else
							{
								if(ValueHelper.CheckValue(
									list[i].Status.Get(this.checkOther && this.targetStatus.StoredAsset != null ?
										this.targetStatus.StoredAsset.Settings :
										this.status.StoredAsset.Settings).GetValue(),
									user.Status.Get(this.status.StoredAsset.Settings).GetValue(),
									ValueCheckType.RangeInclusive == this.checkType || ValueCheckType.RangeExclusive == this.checkType ?
										user.Status.Get(this.status2.StoredAsset.Settings).GetValue() : 0,
									this.checkType) == valid)
								{
									any = true;
									if(!this.targetSettings.dontAddTargets &&
										!foundTargets.Contains(list[i]))
									{
										foundTargets.Add(list[i]);
									}
								}
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.status.ToString() + " " + this.checkType +
				(this.checkOther ? " " + this.targetStatus.ToString() : "");
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(this.useFailedNext)
			{
				if(index == 0)
				{
					return "Success";
				}
				else if(index == 1)
				{
					return "Failed";
				}
			}
			return "Next";
		}

		public override int GetNextCount()
		{
			return this.useFailedNext ? 2 : 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Add Temporary Ability", "Adds a temporary ability to a combatant.", "")]
	[NodeInfo("Combatant")]
	public class AddTemporaryAbilityNode : BaseAINode
	{
		public AbilitySelection ability = new AbilitySelection();

		[EditorSeparator]
		public TemporaryAbilitySettings<BattleAIObjectSelection> temporarySettings = new TemporaryAbilitySettings<BattleAIObjectSelection>();


		// target
		[EditorHelp("Use Found Targets", "Add the temporary ability to the targets found by previous nodes.\n" +
			"If disabled, you need to define the used target.", "")]
		[EditorSeparator]
		public bool onFound = false;

		[EditorCondition("onFound", false)]
		[EditorEndCondition]
		public BattleAITargetSettings targetSettings = new BattleAITargetSettings();

		public AddTemporaryAbilityNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("targetType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			this.Change(call, call.user,
				this.onFound ?
					call.foundTargets :
					this.targetSettings.GetTargetList(call));
			currentNode = this.next;
			call.checkTarget = null;
			return null;
		}

		private void Change(BattleAICall call, Combatant user, List<Combatant> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					call.checkTarget = list[i];
					this.temporarySettings.Add(list[i], this.ability.CreateShortcut(AbilityState.Temporary), call);
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.onFound ? "Found Targets: " : this.targetSettings.ToString() + ": ") +
				this.ability.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Remove Temporary Ability", "Removes a temporary ability from a combatant.", "")]
	[NodeInfo("Combatant")]
	public class RemoveTemporaryAbilityNode : BaseAINode
	{
		[EditorHelp("Remove All", "All temporary abilities will be removed.", "")]
		public bool all = false;

		[EditorHelp("Ability", "Select the ability that will be removes from temporary abilities.", "")]
		[EditorCondition("all", false)]
		[EditorEndCondition]
		public AssetSelection<AbilityAsset> ability = new AssetSelection<AbilityAsset>();


		// target
		[EditorHelp("Use Found Targets", "Remove the temporary ability from the targets found by previous nodes.\n" +
			"If disabled, you need to define the used target.", "")]
		[EditorSeparator]
		public bool onFound = false;

		[EditorCondition("onFound", false)]
		[EditorEndCondition]
		public BattleAITargetSettings targetSettings = new BattleAITargetSettings();

		public RemoveTemporaryAbilityNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("targetType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			this.Change(this.onFound ?
				call.foundTargets :
				this.targetSettings.GetTargetList(call));
			currentNode = this.next;
			return null;
		}

		private void Change(List<Combatant> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.all)
					{
						list[i].Abilities.ClearTemporaryAbilities();
					}
					else if(this.ability.StoredAsset != null)
					{
						list[i].Abilities.RemoveTemporaryAbility(this.ability.StoredAsset.Settings);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.onFound ? "Found Targets: " : this.targetSettings.ToString() + ": ") +
				(this.all ? ": All" : ": " + this.ability.ToString());
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Status Value Sort Targets", "Sort the found targets based on a defined status value.", "")]
	[NodeInfo("Combatant")]
	public class StatusValueSortTargetsNode : BaseAINode
	{
		[EditorHelp("Status Value", "Select the status value that will be used to sort.\n" +
			"The combatants will be sorted from lowest to highest value.", "")]
		public AssetSelection<StatusValueAsset> status = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Min Value: The preview minimum value, displaying changes when an equipment would be equipped.\n" +
			"- Last Change Value: The last value used to change the status value.\n" +
			"- Last Combined Change Value: The combined value of the last changes to the status value.\n" +
			"- Last Combined Change Value Positive: The combined value of the last positive changes to the status value.\n" +
			"- Last Combined Change Value Negative: The combined value of the last negative changes to the status value.", "")]
		public StatusValueGetValue usedValue = StatusValueGetValue.CurrentValue;

		[EditorHelp("Inverse Order", "Inverse the sorting - sorts from highest to lowest value.", "")]
		public bool inverseOrder = false;

		public StatusValueSortTargetsNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.status.StoredAsset != null)
			{
				call.foundTargets.Sort(new StatusValueSorter(this.status.StoredAsset.Settings, this.usedValue, this.inverseOrder));
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.status.ToString() + " (" + this.usedValue.ToString() + ")" + (this.inverseOrder ? ": Inverse" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Get Battle Statistic", "The combatant with the highest or lowest defined battle statistic will be added to the target list.\n" +
		"E.g. use this to get the combatant that dealt the most damage to the user.\n" +
		"Requires using the 'Combatant Battle Statistics' settings defined in 'Battle System > Battle Settings'.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant")]
	public class GetBattleStatisticNode : BaseAINode
	{
		public BattleAISingleTargetSettings targetSettings = new BattleAISingleTargetSettings();


		// statistic
		[EditorHelp("Statistic Key", "The key used to identify the statistic value.", "")]
		[EditorSeparator]
		[EditorWidth(true)]
		public string statisticKey = "";

		[EditorHelp("Value Source", "Select which statistic value will be used:\n" +
			"- Decrease Received: A value decrease the combatant received (e.g. received damage).\n" +
			"- Decrease Given: A value decrease the combatant gave (e.g. dealt damage).\n" +
			"- Increase Received: A value increase the combatant received (e.g. getting healed).\n" +
			"- Increase Given: A value increase the combatant gave (e.g. healing others).", "")]
		public ValueStatistic.Source valueSource = ValueStatistic.Source.DecreaseReceived;

		[EditorHelp("Use Total Change", "Use the total change the combatant registered.\n" +
			"If disabled, uses the change registered from the user (requires using 'Per Combatant' statistics).", "")]
		public bool useTotalChange = true;

		[EditorHelp("Highest/Lowest", "If enabled, the combatant with the " +
			"highest received damage will be added to the target list.\n" +
			"If disabled, the combatant with the lowest received damage will be added to the target list.", "")]
		public bool getHighest = false;

		[EditorHelp("All Matching", "Use all combatants that have the highest/lowest received damage (i.e. matching values).\n" +
			"If disabled, only the first found combatant will be used.", "")]
		public bool allMatching = false;

		public GetBattleStatisticNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			Combatant source = this.useTotalChange ? null : call.user;
			this.targetSettings.Use(call, source, this.Check);

			currentNode = this.next;
			return null;
		}

		private void Check(BattleAICall call, Combatant source, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(ORK.BattleSettings.battleStatistics.useStatictics &&
				(this.useTotalChange ||
					ORK.BattleSettings.battleStatistics.usePerCombatant))
			{
				int found = -1;
				int tmpVal = this.getHighest ? int.MinValue : int.MaxValue;

				// check for highest/lowest value
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						int value = source != null ?
							list[i].Battle.Statistic[this.statisticKey].PerCombatant(source).GetValue(this.valueSource) :
							list[i].Battle.Statistic[this.statisticKey].Total.GetValue(this.valueSource);
						if((this.getHighest && tmpVal < value) ||
							(!this.getHighest && tmpVal > value))
						{
							tmpVal = value;
							found = i;
						}
					}
				}

				if(found >= 0)
				{
					if(this.allMatching)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i] != null)
							{
								int value = source != null ?
									list[i].Battle.Statistic[this.statisticKey].PerCombatant(source).GetValue(this.valueSource) :
									list[i].Battle.Statistic[this.statisticKey].Total.GetValue(this.valueSource);
								if(tmpVal == value &&
									!foundTargets.Contains(list[i]))
								{
									foundTargets.Add(list[i]);
								}
							}
						}
					}
					else if(!foundTargets.Contains(list[found]))
					{
						foundTargets.Add(list[found]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") +
				(this.useTotalChange ? "total change: " : "from user: ") +
				this.statisticKey + " " + this.valueSource;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Store Combatant Count", "Stores the number of combatants in the scene into a float variable.\n" +
		"The found combatants can be filtered by different settings, e.g. being enemy of the user or status conditions.", "")]
	[NodeInfo("Combatant", "Variable")]
	public class StoreCombatantCountNode : BaseAINode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<BattleAIObjectSelection> variable = new VariableSet<BattleAIObjectSelection>();


		// variable key
		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator(new SetFloatOperator());


		// range
		[EditorHelp("Check Range", "Only search within a defined range of the user or a position.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Range Settings")]
		public bool checkRange = false;

		[EditorHelp("From Position", "Check the range from a defined position.\n" +
			"If disabled, the range will be checked from the user's position.", "")]
		[EditorCondition("checkRange", true)]
		public bool checkPosition = false;

		[EditorAutoInit]
		public RangeValue range;

		[EditorSeparator]
		[EditorTitleLabel("Search Position")]
		[EditorCondition("checkPosition", true)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public Vector3Value<BattleAIObjectSelection> position;


		// search settings
		[EditorSeparator]
		public SearchCombatantSettings search = new SearchCombatantSettings();

		public StoreCombatantCountNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			List<Combatant> found = this.checkRange && this.checkPosition ?
				this.search.Search(this.position.GetValue(call), call.user, this.checkRange ? this.range : null) :
				this.search.Search(call.user, this.checkRange ? this.range : null);

			string tmpKey = this.variable.key.GetValue(call);
			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeFloat(call, handlers[i], tmpKey,
					found.Count, this.floatOperator);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Change Formation", "Changes the formation of the user's group.", "")]
	[NodeInfo("Combatant")]
	public class ChangeFormationNode : BaseAINode
	{
		[EditorHelp("Stop Formation", "Stops using a formation.", "")]
		public bool stopFormation = false;

		[EditorHelp("Formation", "Select the formation that will be used.", "")]
		[EditorCondition("stopFormation", false)]
		[EditorEndCondition]
		public AssetSelection<FormationAsset> formation = new AssetSelection<FormationAsset>();

		public ChangeFormationNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.formation.StoredAsset != null)
			{
				call.user.Group.SetFormation(this.formation.StoredAsset.Settings);
			}
			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.stopFormation ? "Stop" : this.formation.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("In Formation", "Checks if the user's group currently is in any or a defined formation, " +
		"or checks if a combatant is part of a formation.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class InFormationNode : BaseAICheckNode
	{
		[EditorHelp("Check Combatant", "Checks if a combatant is part of a formation.", "")]
		public bool checkCombatant = false;


		// combatant
		[EditorCondition("checkCombatant", true)]
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// formation
		[EditorHelp("Any Formation", "Checks if the user's group is in any formation.", "")]
		[EditorElseCondition]
		public bool anyFormation = true;

		[EditorHelp("Formation", "Select the formation that will be used.", "")]
		[EditorCondition("anyFormation", false)]
		[EditorEndCondition(2)]
		public AssetSelection<FormationAsset> formation = new AssetSelection<FormationAsset>();

		public InFormationNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;

			if(this.checkCombatant)
			{
				any = this.targetSettings.Use(call, this.Check);
			}
			else if(call.user.Group.InFormation &&
				(this.anyFormation ||
					(this.formation.StoredAsset != null &&
						call.user.Group.IsFormation(this.formation.StoredAsset.Settings))))
			{
				any = true;
			}

			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Group.InFormation &&
					list[i].Group.IsInFormation(list[i]))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.checkCombatant ?
				(this.targetSettings.ToString()) :
				(this.anyFormation ? "Any" : this.formation.ToString());
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Faction", "Checks the faction of a combatant.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckFactionNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// faction
		[EditorHelp("Faction", "Select the faction that will be checked for.", "")]
		[EditorSeparator]
		public AssetSelection<FactionAsset> faction = new AssetSelection<FactionAsset>();

		public CheckFactionNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				call.checkTarget = list[i];
				if(list[i] != null &&
					this.faction.Is(list[i].Group.Faction))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() + ": " + this.faction.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Faction Sympathy", "Checks the sympathy a faction has for the user's faction (or the user for the checked combatant's faction).\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckFactionSympathyNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// check by
		[EditorHelp("Check Sympathy For User", "Check the sympathy for the user's faction.\n" +
			"If disabled, checks the user's sympathy for the checked combatant's faction.")]
		[EditorSeparator]
		public bool checkForUser = false;

		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public CheckFactionSympathyNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(call.user.Group.Faction != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					call.checkTarget = list[i];
					if(list[i] != null &&
						list[i].Group.Faction != null &&
						this.checkForUser ?
							this.check.Check(ORK.Game.Faction.GetSympathy(list[i].Group.Faction, call.user.Group.Faction), call) :
							this.check.Check(ORK.Game.Faction.GetSympathy(call.user.Group.Faction, list[i].Group.Faction), call))
					{
						any = true;
						if(!this.targetSettings.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() + ": " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Faction Benefit", "Checks the benefit a faction gives to another faction.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CheckFactionBenefitNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// benefit
		[EditorHelp("Check Benefit For User", "Check the benefit for the user's faction.\n" +
			"If disabled, checks the user's benefit for the checked combatant's faction.")]
		[EditorSeparator]
		public bool checkForUser = false;

		[EditorHelp("Faction Benefit", "Select the faction benefit that will be checked for.", "")]
		public AssetSelection<FactionBenefitAsset> factionBenefit = new AssetSelection<FactionBenefitAsset>();

		public CheckFactionBenefitNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(call.user.Group.Faction != null &&
				this.factionBenefit.StoredAsset != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					call.checkTarget = list[i];
					if(list[i] != null &&
						list[i].Group.Faction != null &&
						this.factionBenefit.StoredAsset.Settings.InSympathyRange(this.checkForUser ?
							ORK.Game.Faction.GetSympathy(list[i].Group.Faction, call.user.Group.Faction) :
							ORK.Game.Faction.GetSympathy(call.user.Group.Faction, list[i].Group.Faction)))
					{
						any = true;
						if(!this.targetSettings.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() + ": " + this.factionBenefit.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Is Linked Combatant", "Checks if the user is linked to another combatant.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the conditions will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant", "Check")]
	public class IsLinkedCombatantNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// link
		[EditorSeparator]
		[EditorHelp("Linked Key", "Define the key that will be used.")]
		public StringValue<BattleAIObjectSelection> linkedKey = new StringValue<BattleAIObjectSelection>();

		[EditorHelp("Check Target", "Checks if the user is stored as a link on the target.\n" +
			"If disabled, checks if the target is stored as a link on the user.")]
		public bool checkTarget = false;

		public IsLinkedCombatantNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			string key = this.linkedKey.GetValue(call);

			// check for status contisions
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					(this.checkTarget ?
						list[i].Battle.CombatantLinks.Contains(key, call.user) :
						call.user.Battle.CombatantLinks.Contains(key, list[i])))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() + ": " + this.linkedKey.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Status Effect Added By", "Checks if the user's status effect was added by a target.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the conditions will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Combatant", "Check")]
	public class StatusEffectAddedByNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// status effect
		[EditorHelp("Status Effect", "Select the status effect that will be checked for.", "")]
		[EditorSeparator]
		public AssetSelection<StatusEffectAsset> effect = new AssetSelection<StatusEffectAsset>();

		[EditorHelp("Check Target", "Checks if the user added the status effect to the target.\n" +
			"If disabled, checks if the target added the status effect to the user.")]
		public bool checkTarget = false;

		public StatusEffectAddedByNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.effect.StoredAsset != null &&
				this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status contisions
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					(this.checkTarget ?
						list[i].Status.Effects.IsAppliedBy(this.effect.StoredAsset.Settings, call.user) :
						call.user.Status.Effects.IsAppliedBy(this.effect.StoredAsset.Settings, list[i])))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() + ": " + this.effect.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Add Combatant Body Part", "Adds body parts to a combatant.\n" +
		"Please note that you can't add body parts to body parts.", "")]
	[NodeInfo("Combatant")]
	public class AddCombatantBodyPartNode : BaseAINode
	{
		// target
		[EditorHelp("Use Found Targets", "Add the temporary ability to the targets found by previous nodes.\n" +
			"If disabled, you need to define the used target.", "")]
		public bool onFound = false;

		[EditorCondition("onFound", false)]
		[EditorEndCondition]
		public BattleAITargetSettings targetSettings = new BattleAITargetSettings();


		// body parts
		[EditorArray("Add Body Part", "Adds a body part to the combatant.\n" +
			"Body parts are separate targets on a combatant and use a combatant setup for their status definition.\n" +
			"Individual combatants can add to or replace the default body parts.", "",
			"Remove", "Removes the body part.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Body Part", "Select the base combatant and other settings for the body part.", ""
			})]
		public CombatantBodyPartSetting[] bodyPart = new CombatantBodyPartSetting[0];

		public AddCombatantBodyPartNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.bodyPart.Length > 0)
			{
				this.Change(call, call.user,
					this.onFound ?
						call.foundTargets :
						this.targetSettings.GetTargetList(call));
			}
			currentNode = this.next;
			return null;
		}

		private void Change(BattleAICall call, Combatant user, List<Combatant> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].AddBodyParts(this.bodyPart);
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			StringBuilder builder = new StringBuilder(this.targetSettings.ToString());
			if(this.bodyPart.Length > 0)
			{
				builder.Append(": ").Append(this.bodyPart[0].ToString());
				for(int i = 1; i < this.bodyPart.Length; i++)
				{
					builder.Append(", ").Append(this.bodyPart[i].ToString());
				}
			}
			return builder.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Remove Combatant Body Part", "Removes a body part from a combatant.\n" +
		"The body part will also be removed from battle.", "")]
	[NodeInfo("Combatant")]
	public class RemoveCombatantBodyPartNode : BaseAINode
	{
		// target
		[EditorHelp("Use Found Targets", "Add the temporary ability to the targets found by previous nodes.\n" +
			"If disabled, you need to define the used target.", "")]
		public bool onFound = false;

		[EditorCondition("onFound", false)]
		[EditorEndCondition]
		public BattleAITargetSettings targetSettings = new BattleAITargetSettings();


		// body parts
		[EditorHelp("Is Body Part", "The selected combatant (setting above) is a body part and will be removed from it's parent combatant.\n" +
			"If disabled, a defined body part will be removed from the selected combatant (setting above).")]
		[EditorSeparator]
		public bool isBodyPart = true;

		[EditorHelp("Body Part Combatant", "Select the body part combatant that'll be removed.", "")]
		[EditorCondition("isBodyPart", false)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<CombatantAsset> bodyPart;

		public RemoveCombatantBodyPartNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			this.Change(call, call.user,
				this.onFound ?
					call.foundTargets :
					this.targetSettings.GetTargetList(call));
			currentNode = this.next;
			return null;
		}

		private void Change(BattleAICall call, Combatant user, List<Combatant> list)
		{
			if(this.isBodyPart)
			{
				for(int i = 0; i < list.Count; i++)
				{
					CombatantBodyPart part = list[i] as CombatantBodyPart;
					if(part != null)
					{
						part.Parent.RemoveBodyPart(part);
					}
				}
			}
			else if(this.bodyPart.StoredAsset != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].HasBodyParts)
					{
						CombatantBodyPart part = list[i].GetBodyPart(this.bodyPart.StoredAsset.Settings);
						if(part != null)
						{
							list[i].RemoveBodyPart(part);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() +
				(this.isBodyPart ? " (body part)" : ": " + this.bodyPart.ToString());
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}
}

