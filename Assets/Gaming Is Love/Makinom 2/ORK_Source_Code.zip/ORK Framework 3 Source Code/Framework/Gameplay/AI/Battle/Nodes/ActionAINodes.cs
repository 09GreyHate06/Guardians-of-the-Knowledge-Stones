
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.ORKFramework.Components;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	public enum BattleAIActionUseMode { Default, CanUseCheckOnly, Use, Queue, InsertQueue }

	public abstract class BaseAIActionNode : BaseAICheckNode
	{
		[EditorHelp("Action Use Mode", "Select how this action will be used:\n" +
			"- Default: Uses the battle AI call's use mode (i.e. either 'First Useable' or 'Queue').\n" +
			"- Can Use Check Only: Only checks if the action can be used. " +
			"If the action can be used, 'Useable' will be executed, otherwise 'Not Useable'.\n" +
			"- Use: Uses the action, exiting the battle AI and not executing any further battle AI.\n" +
			"- Queue: Adds the action to the end of the AI action queue.\n" +
			"- Insert Queue: Adds the action to the front of the AI action queue (i.e. it being the next action).")]
		[EditorSeparator]
		public BattleAIActionUseMode useMode = BattleAIActionUseMode.Default;

		protected virtual BaseAction UseAction(BattleAICall call, BaseAction action, ref int currentNode)
		{
			currentNode = this.next;
			if(BattleAIActionUseMode.Default == this.useMode)
			{
				if(BattleAIUseMode.FirstUseable == call.useMode)
				{
					return action;
				}
				else if(BattleAIUseMode.Queue == call.useMode)
				{
					if(action != null)
					{
						call.user.AI.ActionQueue.Add(action);
						call.user.Events.FireNextActionChanged();
					}
				}
			}
			else if(BattleAIActionUseMode.CanUseCheckOnly == this.useMode)
			{
				currentNode = action != null ? this.next : this.nextFail;
			}
			else if(BattleAIActionUseMode.Use == this.useMode)
			{
				return action;
			}
			else if(BattleAIActionUseMode.Queue == this.useMode)
			{
				if(action != null)
				{
					call.user.AI.ActionQueue.Add(action);
					call.user.Events.FireNextActionChanged();
				}
			}
			else if(BattleAIActionUseMode.InsertQueue == this.useMode)
			{
				if(action != null)
				{
					call.user.AI.ActionQueue.Insert(0, action);
					call.user.Events.FireNextActionChanged();
				}
			}
			return null;
		}

		protected virtual bool IsCanUseCheckOnly
		{
			get { return BattleAIActionUseMode.CanUseCheckOnly == this.useMode; }
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(this.IsCanUseCheckOnly)
			{
				if(index == 0)
				{
					return "Useable";
				}
				else if(index == 1)
				{
					return "Not Useable";
				}
			}
			return "Next";
		}

		public override int GetNextCount()
		{
			return this.IsCanUseCheckOnly ? 2 : 1;
		}

		public override int GetNext(int index)
		{
			if(this.IsCanUseCheckOnly)
			{
				if(index == 0)
				{
					return this.next;
				}
				else if(index == 1)
				{
					return this.nextFail;
				}
				return -1;
			}
			return this.next;
		}

		public override void SetNext(int index, int next)
		{
			if(this.IsCanUseCheckOnly)
			{
				if(index == 0)
				{
					this.next = next;
				}
				else if(index == 1)
				{
					this.nextFail = next;
				}
			}
			else
			{
				this.next = next;
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.machineNodeColor; }
		}
	}

	[EditorHelp("Attack", "Performs the combatant's base attack or counter attack.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[NodeInfo("Action")]
	public class AttackNode : BaseAIActionNode
	{
		[EditorHelp("Use Counter", "The combatant's counter attack is used.\n" +
			"If disabled, the combatant's base attack is used.", "")]
		public bool useCounter = false;


		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[EditorSeparator]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[EditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[EditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the attack won't be used.", "")]
		public bool needTargets = false;

		public AttackNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			AbilityAction action = null;
			AbilityShortcut ability = this.useCounter ?
				call.user.Abilities.GetCounterAttack() :
				call.user.Abilities.GetCurrentBaseAttack();

			// get action
			if(!call.user.Status.Effects.BlockAttack)
			{
				action = BaseAction.CreateAbility(call.user, ability, -2,
					call.checkTime, call.checkUseCosts);
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null)
			{
				action.forceFoundTargets = this.forceFoundTargets;
				bool targetsFound = call.user.AI.SetActionTargets(action,
					BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

				if((this.needTargets && !targetsFound) ||
					!ORK.Battle.CheckActionCost(call.user, action))
				{
					action = null;
				}
			}
			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			return this.UseAction(call, action, ref currentNode);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useCounter ? "Counter Attack" : "Base Attack") +
				(this.endPhase ? ", Ends Phase" : "");
		}
	}

	[EditorHelp("Ability", "Performs an ability of the combatant.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[NodeInfo("Action")]
	public class AbilityNode : BaseAIActionNode
	{
		// random ability
		[EditorHelp("Use Random Ability", "Use a random ability known by the combatant.", "")]
		public bool useRandom = false;

		[EditorHelp("Add Hidden Abilities", "Hidden abilities (either via the ability or ability type being hidden) will be used.\n" +
			"If disabled, hidden abilities will be excluded and not used.")]
		[EditorCondition("useRandom", true)]
		public bool addHidden = true;

		[EditorHelp("Limit Ability Type", "Limit the random abilities to a defined ability type.", "")]
		public bool limitType = false;

		[EditorHelp("Ability Type", "Select the ability type that will be used to limit the random abilities.\n" +
			"Only abilities of the selected type will be used.", "")]
		[EditorCondition("limitType", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<AbilityTypeAsset> type;

		// defined ability
		[EditorHelp("Ability", "Select the ability that will be performed.\n" +
			"The combatant must know the ability (e.g. learned the ability, equipment ability), or the action can't be performed.", "")]
		[EditorElseCondition]
		public AssetSelection<AbilityAsset> ability = new AssetSelection<AbilityAsset>();

		[EditorHelp("Know Ability", "The ability must be known to the combatant, or the action can't be performed.\n" +
			"If disabled, the combatant doesn't need to know the ability - if not known, the highest use level is 1, otherwise the defined level.", "")]
		[EditorEndCondition]
		public bool knowAbility = true;

		// ability setup
		[EditorHelp("Use Highest Level", "The highest available ability level will be used " +
			"(i.e. the highest level that can be used, e.g. due to use costs).\n" +
			"If disabled, a defined ability level will be used - " +
			 "if the defined level can't be used (e.g. due to use costs), the action can't be performed.", "")]
		public bool useHighest = false;

		[EditorHelp("Level", "Set the level of the ability that will be used.", "")]
		[EditorLimit(1, false)]
		[EditorCondition("useHighest", false)]
		[EditorEndCondition]
		public int level = 1;


		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[EditorSeparator]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[EditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[EditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the ability won't be used.", "")]
		public bool needTargets = false;

		public AbilityNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			AbilityAction action = null;

			// get action
			AbilityShortcut ability = null;
			if(this.useRandom)
			{
				List<AbilityShortcut> list = this.limitType && this.type.StoredAsset != null ?
					call.user.Abilities.GetByType(this.type.StoredAsset.Settings, UseableIn.Battle, IncludeCheckType.Yes, false, false, true) :
					call.user.Abilities.GetAbilities(UseableIn.Battle, IncludeCheckType.Yes, false, false);
				if(list.Count > 0)
				{
					if(!this.addHidden)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i].IsHidden)
							{
								list.RemoveAt(i--);
							}
						}
					}
					ability = list[UnityWrapper.Range(0, list.Count)];
				}
			}
			else if(this.ability.StoredAsset != null)
			{
				ability = call.user.Abilities.Get(this.ability.StoredAsset.Settings, false);
				if(ability == null &&
					!this.knowAbility)
				{
					ability = new AbilityShortcut(this.ability.StoredAsset.Settings,
						this.useHighest ? 1 : this.level, AbilityState.None);
				}
			}

			if(ability != null)
			{
				action = BaseAction.CreateAbility(call.user, ability,
					this.useHighest ? -1 : this.level,
					call.checkTime, call.checkUseCosts);
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null)
			{
				action.forceFoundTargets = this.forceFoundTargets;
				bool targetsFound = call.user.AI.SetActionTargets(action,
					BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

				if((this.needTargets && !targetsFound) ||
					!ORK.Battle.CheckActionCost(call.user, action))
				{
					action = null;
				}
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			return this.UseAction(call, action, ref currentNode);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useRandom ?
					(this.limitType ? "Random " + this.type : "Random") :
					this.ability.ToString()) +
				(this.useHighest ? ", Highest Level" : ", Level " + this.level) +
				(this.endPhase ? ", Ends Phase" : "");
		}
	}

	[EditorHelp("Class Ability", "Performs the combatant's class ability.\n" +
		"If multiple class abilities are available (e.g. due to using class slots with multiple equipped classes), " +
		"the first useable class ability is used.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[NodeInfo("Action")]
	public class ClassAbilityNode : BaseAIActionNode
	{
		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[EditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[EditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the ability won't be used.", "")]
		public bool needTargets = false;

		public ClassAbilityNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			AbilityAction action = null;

			List<AbilityShortcut> ability = call.user.Class.GetClassAbilities();
			for(int i = 0; i < ability.Count; i++)
			{
				if(ability[i] != null)
				{
					if(ability[i] != null)
					{
						action = BaseAction.CreateAbility(call.user, ability[i], -1,
							call.checkTime, call.checkUseCosts);
					}

					// check AI blocks
					if(!call.user.AI.CanUseAction(action))
					{
						action = null;
					}

					// check active time
					if(action != null)
					{
						action.forceFoundTargets = this.forceFoundTargets;
						bool targetsFound = call.user.AI.SetActionTargets(action,
							BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

						if((this.needTargets && !targetsFound) ||
							!ORK.Battle.CheckActionCost(call.user, action))
						{
							action = null;
						}
					}

					if(action != null)
					{
						action.endPhaseFlag = this.endPhase;
						action.blockBattleCamera = this.blockBattleCamera;
					}

					if(action != null)
					{
						return this.UseAction(call, action, ref currentNode);
					}
				}
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.endPhase ? "Ends Phase" : "";
		}
	}

	[EditorHelp("Item", "The combatant uses an item.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[NodeInfo("Action")]
	public class ItemNode : BaseAIActionNode
	{
		[EditorHelp("Use Random Item", "Use a random item in the combatant's inventory.", "")]
		public bool useRandom = false;

		[EditorHelp("Add Hidden Items", "Hidden items (either via the item or item type being hidden) will be used.\n" +
			"If disabled, hidden items will be excluded and not used.")]
		[EditorCondition("useRandom", true)]
		public bool addHidden = true;

		[EditorHelp("Limit Item Type", "Limit the random items to a defined item type.", "")]
		public bool limitType = false;

		[EditorHelp("Item Type", "Select the item type that will be used to limit the random items.\n" +
			"Only items of the selected type will be used.", "")]
		[EditorCondition("limitType", true)]
		[EditorEndCondition]
		public AssetSelection<ItemTypeAsset> type = new AssetSelection<ItemTypeAsset>();

		[EditorHelp("Item", "Select the item that will be used.\n" +
			"The item must be useable in battle, or the action can't be performed.", "")]
		[EditorElseCondition]
		public AssetSelection<ItemAsset> item = new AssetSelection<ItemAsset>();

		[EditorHelp("In Inventory", "The item must be in the combatant's inventory, or the action can't be performed.\n" +
			"If disabled, the combatant doesn't need to have the item in the inventory, but it will be consumed if it's in the inventory.", "")]
		[EditorEndCondition]
		public bool inInventory = false;


		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[EditorSeparator]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[EditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[EditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the item won't be used.", "")]
		public bool needTargets = false;

		public ItemNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			ItemAction action = null;

			// get action
			ItemShortcut item = null;
			if(this.useRandom)
			{
				List<ItemShortcut> list = this.limitType && this.type.StoredAsset != null ?
					call.user.Inventory.Items.GetUseableItemsByType(this.type.StoredAsset.Settings, UseableIn.Battle, true) :
					call.user.Inventory.Items.GetUseableItems(UseableIn.Battle);
				if(list.Count > 0)
				{
					if(!this.addHidden)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i].IsHidden)
							{
								list.RemoveAt(i--);
							}
						}
					}
					item = list[UnityWrapper.Range(0, list.Count)];
				}
			}
			else if(this.item.StoredAsset != null)
			{
				item = this.inInventory ?
					call.user.Inventory.Items.Get(this.item.StoredAsset.Settings) :
					new ItemShortcut(this.item.StoredAsset.Settings, 1);
			}

			if(item != null && item.CanUse(call.user, call.checkTime, call.checkUseCosts))
			{
				action = new ItemAction(call.user, item);
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null)
			{
				action.forceFoundTargets = this.forceFoundTargets;
				bool targetsFound = call.user.AI.SetActionTargets(action,
					BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

				if((this.needTargets && !targetsFound) ||
					!ORK.Battle.CheckActionCost(call.user, action))
				{
					action = null;
				}
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			return this.UseAction(call, action, ref currentNode);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useRandom ?
					(this.limitType ? "Random " + this.type : "Random") :
					this.item.ToString()) +
				(this.inInventory ? ", Inventory" : "") +
				(this.endPhase ? ", Ends Phase" : "");
		}
	}

	[EditorHelp("Defend", "The combatant uses the defend command.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[NodeInfo("Action")]
	public class DefendNode : BaseAIActionNode
	{
		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		public DefendNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			BaseAction action = null;

			// get action
			if(!call.user.Status.Effects.BlockDefend)
			{
				action = new DefendAction(call.user);
			}

			// check active time
			if(action != null &&
				!ORK.Battle.CheckActionCost(call.user, action))
			{
				action = null;
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			return this.UseAction(call, action, ref currentNode);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.endPhase ? "Ends Phase" : "";
		}
	}

	[EditorHelp("Escape", "The combatant uses the escape command.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[NodeInfo("Action")]
	public class EscapeNode : BaseAIActionNode
	{
		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		public EscapeNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			BaseAction action = null;

			// get action
			if(!call.user.Status.Effects.BlockEscape)
			{
				action = new EscapeAction(call.user);
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null &&
				!ORK.Battle.CheckActionCost(call.user, action))
			{
				action = null;
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			return this.UseAction(call, action, ref currentNode);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.endPhase ? "Ends Phase" : "";
		}
	}

	[EditorHelp("Death", "The combatant dies.", "")]
	[NodeInfo("Action")]
	public class DeathNode : BaseAIActionNode
	{
		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		public DeathNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			currentNode = -1;
			BaseAction action = new DeathAction(call.user, false);
			action.endPhaseFlag = this.endPhase;
			action.blockBattleCamera = this.blockBattleCamera;

			return this.UseAction(call, action, ref currentNode);
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 0;
		}

		public override int GetNext(int index)
		{
			return -1;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the AI" + (this.endPhase ? ", Ends Phase" : "");
		}
	}

	[EditorHelp("None", "The combatant does nothing.", "")]
	[NodeInfo("Action")]
	public class NoneNode : BaseAIActionNode
	{
		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[EditorHelp("Is Silent", "The 'None' action will be silent, " +
			"i.e. no battle info will be displayed and no battle animation (schematics) will be used.", "")]
		public bool isSilent = false;

		public NoneNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			currentNode = -1;
			BaseAction action = new NoneAction(call.user, this.isSilent);
			action.endPhaseFlag = this.endPhase;
			action.blockBattleCamera = this.blockBattleCamera;
			return this.UseAction(call, action, ref currentNode);
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 0;
		}

		public override int GetNext(int index)
		{
			return -1;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the AI" +
				(this.isSilent ? " (silent)" : "") +
				(this.endPhase ? ", Ends Phase" : "");
		}
	}

	[EditorHelp("Change Member", "The combatant is exchanged with a member of the combatant's non-battle group (battle reserve).", "")]
	[NodeInfo("Action")]
	public class ChangeMemberNode : BaseAIActionNode
	{
		[EditorHelp("Member Index", "The index of the non-battle member (battle reserve) that will be used.", "")]
		[EditorLimit(0, false)]
		public int memberIndex = 0;

		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		public ChangeMemberNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			BaseAction action = null;

			Combatant target = call.user.Group.BattleReserveMemberAt(this.memberIndex);
			if(target != null)
			{
				action = new ChangeMemberAction(call.user, target);
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			return this.UseAction(call, action, ref currentNode);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Member " + this.memberIndex + (this.endPhase ? ", Ends Phase" : "");
		}
	}

	[EditorHelp("Grid Move", "The combatant moves on the grid, either toward a target, flees from a target or to a random cell within move range.\n" +
		"If the target is reachable, but no grid move action can be performed in this turn " +
		"(e.g. not enough move range left), 'Reachable' will be executed next, otherwise 'Next'.", "")]
	[NodeInfo("Action")]
	public class GridMoveNode : BaseAIActionNode
	{
		public GridMoveSettings gridMove = new GridMoveSettings();

		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[EditorSeparator]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[EditorHide]
		public int nextReachable = -1;

		public GridMoveNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			currentNode = this.next;
			GridMoveAction action = null;

			if(this.gridMove.GetMoveAction(call, call.user,
				BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies,
				out action, null))
			{
				currentNode = this.nextReachable;
			}

			// check active time
			if(action != null &&
				!ORK.Battle.CheckActionCost(call.user, action))
			{
				action = null;
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			if(BattleAIActionUseMode.Default == this.useMode)
			{
				if(BattleAIUseMode.FirstUseable == call.useMode)
				{
					return action;
				}
				else if(BattleAIUseMode.Queue == call.useMode)
				{
					if(action != null)
					{
						call.user.AI.ActionQueue.Add(action);
						call.user.Events.FireNextActionChanged();
					}
				}
			}
			else if(BattleAIActionUseMode.CanUseCheckOnly == this.useMode)
			{
				currentNode = action != null ? this.next : this.nextFail;
			}
			else if(BattleAIActionUseMode.Use == this.useMode)
			{
				return action;
			}
			else if(BattleAIActionUseMode.Queue == this.useMode)
			{
				if(action != null)
				{
					call.user.AI.ActionQueue.Add(action);
					call.user.Events.FireNextActionChanged();
				}
			}
			else if(BattleAIActionUseMode.InsertQueue == this.useMode)
			{
				if(action != null)
				{
					call.user.AI.ActionQueue.Insert(0, action);
					call.user.Events.FireNextActionChanged();
				}
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.gridMove.ToString() + (this.endPhase ? ", Ends Phase" : "");
		}

		public override string GetNextName(int index)
		{
			if(this.IsCanUseCheckOnly)
			{
				if(index == 0)
				{
					return "Useable";
				}
				else if(index == 1)
				{
					return "Not Useable";
				}
			}
			else if(index == 1)
			{
				return "Reachable";
			}
			return "Next";
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 2;
		}

		public override int GetNext(int index)
		{
			if(this.IsCanUseCheckOnly)
			{
				if(index == 0)
				{
					return this.next;
				}
				else if(index == 1)
				{
					return this.nextFail;
				}
				return -1;
			}
			else
			{
				if(index == 1)
				{
					return this.nextReachable;
				}
				return this.next;
			}
		}

		public override void SetNext(int index, int next)
		{
			if(this.IsCanUseCheckOnly)
			{
				if(index == 0)
				{
					this.next = next;
				}
				else if(index == 1)
				{
					this.nextFail = next;
				}
			}
			else
			{
				if(index == 1)
				{
					this.nextReachable = next;
				}
				else
				{
					this.next = next;
				}
			}
		}
	}

	[EditorHelp("Shortcut Slot", "Performs an action stored in a shortcut slot.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[NodeInfo("Action")]
	public class ShortcutSlotNode : BaseAIActionNode
	{
		public ShortcutSlot slot = new ShortcutSlot();

		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[EditorSeparator]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[EditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[EditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the ability won't be used.", "")]
		public bool needTargets = false;

		public ShortcutSlotNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			BaseAction action = null;
			Combatant owner = null;
			IShortcut shortcut = this.slot.GetShortcut(call.user, out owner);
			bool setTargets = false;

			// get action
			if(call.user == owner &&
				shortcut != null)
			{
				// ability
				if(shortcut is AbilityShortcut)
				{
					AbilityShortcut ability = (AbilityShortcut)shortcut;
					if(ability.IsBaseAttack ||
						ability.IsCounterAttack)
					{
						if(!call.user.Status.Effects.BlockAttack)
						{
							action = BaseAction.CreateAbility(call.user, ability, -2,
								call.checkTime, call.checkUseCosts);
						}
					}
					else
					{
						if(!call.user.Status.Effects.BlockAbilities)
						{
							action = BaseAction.CreateAbility(call.user, ability, ability.GetLevel(),
								call.checkTime, call.checkUseCosts);
						}
					}
					setTargets = true;
				}
				// item
				else if(shortcut is ItemShortcut)
				{
					if(!call.user.Status.Effects.BlockItems &&
						shortcut.CanUse(call.user, call.checkTime, call.checkUseCosts))
					{
						action = new ItemAction(call.user, (ItemShortcut)shortcut);
					}
					setTargets = true;
				}
				// defend
				else if(shortcut is DefendShortcut)
				{
					if(!call.user.Status.Effects.BlockDefend)
					{
						action = new DefendAction(call.user);
					}
				}
				// escape
				else if(shortcut is EscapeShortcut)
				{
					if(!call.user.Status.Effects.BlockEscape)
					{
						action = new EscapeAction(call.user);
					}
				}
				// none
				else if(shortcut is NoneShortcut)
				{
					action = new NoneAction(call.user, false);
				}
				// grid move
				else if(shortcut is GridMoveShortcut)
				{
					GridMoveAction tmpAction = null;
					GridMoveShortcut gridMove = (GridMoveShortcut)shortcut;
					if(gridMove.gridMove.GetMoveAction(call, call.user,
						BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies,
						out tmpAction, null))
					{
						action = tmpAction;
					}
				}
				// grid orientation
				else if(shortcut is GridOrientationShortcut)
				{
					((GridOrientationShortcut)shortcut).Use(call.user,
						BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), false);
				}
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null)
			{
				if(setTargets)
				{
					action.forceFoundTargets = this.forceFoundTargets;
					bool targetsFound = call.user.AI.SetActionTargets(action,
						BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

					if((this.needTargets && !targetsFound) ||
						!ORK.Battle.CheckActionCost(call.user, action))
					{
						action = null;
					}
				}
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			return this.UseAction(call, action, ref currentNode);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.slot.ToString() + (this.endPhase ? ", Ends Phase" : "");
		}
	}

	[EditorHelp("Selected Data Action", "Performs an action stored in selected data.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[NodeInfo("Action")]
	public class SelectedDataActionNode : BaseAIActionNode
	{
		public SelectedData<BattleAIObjectSelection> selectedData = new SelectedData<BattleAIObjectSelection>();

		[EditorHelp("Use Random", "Uses a random action (until finding an action).\n" +
			"If disabled, uses the first available action.", "")]
		[EditorSeparator]
		public bool useRandom = false;


		// other settings
		[EditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[EditorSeparator]
		public bool endPhase = false;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[EditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[EditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the ability won't be used.", "")]
		public bool needTargets = false;

		public SelectedDataActionNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			BaseAction action = null;
			bool setTargets = false;
			List<IShortcut> shortcuts = this.selectedData.GetSelectedData<IShortcut>(call, ORKSelectedDataHelper.GetShortcuts);

			// get action
			if(shortcuts != null)
			{
				if(this.useRandom)
				{
					while(action == null &&
						shortcuts.Count > 0)
					{
						int index = Random.Range(0, shortcuts.Count);
						action = this.GetAction(call, shortcuts[index], ref setTargets);
						if(action != null)
						{
							break;
						}
						else
						{
							shortcuts.RemoveAt(index);
						}
					}
				}
				else
				{
					for(int i = 0; i < shortcuts.Count; i++)
					{
						if(shortcuts[i] != null)
						{
							action = this.GetAction(call, shortcuts[i], ref setTargets);
							if(action != null)
							{
								break;
							}
						}
					}
				}
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null)
			{
				if(setTargets)
				{
					action.forceFoundTargets = this.forceFoundTargets;
					bool targetsFound = call.user.AI.SetActionTargets(action,
						BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

					if((this.needTargets && !targetsFound) ||
						!ORK.Battle.CheckActionCost(call.user, action))
					{
						action = null;
					}
				}
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			return this.UseAction(call, action, ref currentNode);
		}

		private BaseAction GetAction(BattleAICall call, IShortcut shortcut, ref bool setTargets)
		{
			BaseAction action = null;

			// ability
			if(shortcut is AbilityShortcut)
			{
				AbilityShortcut ability = (AbilityShortcut)shortcut;
				if(ability.IsBaseAttack ||
					ability.IsCounterAttack)
				{
					if(!call.user.Status.Effects.BlockAttack)
					{
						action = BaseAction.CreateAbility(call.user, ability, -2,
							call.checkTime, call.checkUseCosts);
					}
				}
				else
				{
					if(!call.user.Status.Effects.BlockAbilities)
					{
						action = BaseAction.CreateAbility(call.user, ability, ability.GetLevel(),
							call.checkTime, call.checkUseCosts);
					}
				}
				setTargets = true;
			}
			// item
			else if(shortcut is ItemShortcut)
			{
				if(!call.user.Status.Effects.BlockItems &&
					shortcut.CanUse(call.user, call.checkTime, call.checkUseCosts))
				{
					action = new ItemAction(call.user, (ItemShortcut)shortcut);
				}
				setTargets = true;
			}
			// defend
			else if(shortcut is DefendShortcut)
			{
				if(!call.user.Status.Effects.BlockDefend)
				{
					action = new DefendAction(call.user);
				}
			}
			// escape
			else if(shortcut is EscapeShortcut)
			{
				if(!call.user.Status.Effects.BlockEscape)
				{
					action = new EscapeAction(call.user);
				}
			}
			// none
			else if(shortcut is NoneShortcut)
			{
				action = new NoneAction(call.user, false);
			}
			// grid move
			else if(shortcut is GridMoveShortcut)
			{
				GridMoveAction tmpAction = null;
				GridMoveShortcut gridMove = (GridMoveShortcut)shortcut;
				if(gridMove.gridMove.GetMoveAction(call, call.user,
					BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies,
					out tmpAction, null))
				{
					action = tmpAction;
				}
			}
			// grid orientation
			else if(shortcut is GridOrientationShortcut)
			{
				((GridOrientationShortcut)shortcut).Use(call.user,
					BattleAISettings.GetPreferredTargets(call.user, call.foundTargets), false);
			}
			return action;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedData.ToString() + (this.endPhase ? ", Ends Phase" : "");
		}
	}
}
