
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.ORKFramework.Components;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Check Object Variables", "Checks a combatant's object variables " +
		"(requires an 'Object Variables' component attached to the combatant's game object).\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Variable", "Check")]
	public class CheckObjectVariablesNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// variables
		[EditorSeparator]
		public VariableCondition<BattleAIObjectSelection> condition = new VariableCondition<BattleAIObjectSelection>();

		public CheckObjectVariablesNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check object variables of all possible targets, add to found targets
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					call.checkTarget = list[i];
					if(this.condition.CheckVariables(call))
					{
						any = true;
						if(!this.targetSettings.dontAddTargets &&
							!call.foundTargets.Contains(list[i]))
						{
							call.foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Change Variables", "Changes variables.", "")]
	[NodeInfo("Variable")]
	public class ChangeVariablesNode : BaseAINode
	{
		// variables
		public VariableSetter<BattleAIObjectSelection> change = new VariableSetter<BattleAIObjectSelection>();

		public ChangeVariablesNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			this.change.SetVariables(call);

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.change.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Variables", "Checks if variables have certain values.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Doesn't influence the target list.", "")]
	[NodeInfo("Variable", "Check")]
	public class CheckVariablesNode : BaseAICheckNode
	{
		// variables
		public VariableCondition<BattleAIObjectSelection> condition = new VariableCondition<BattleAIObjectSelection>();

		public CheckVariablesNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.condition.CheckVariables(call))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.condition.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Variable Fork", "Checks if a single variable for certain values.\n" +
		"If a variable condition is valid, it's next node will be executed.\n" +
		"If no variable condition is valid, 'Failed' will be executed.", "")]
	[NodeInfo("Check", "Variable")]
	public class VariableForkNode : BaseAINode
	{
		[EditorTitleLabel("Variable Settings")]
		public VariableGet<BattleAIObjectSelection> variable = new VariableGet<BattleAIObjectSelection>();

		[EditorArray("Add Condition", "Adds a new variable condition.", "",
			"Remove", "Removes the variable condition.", "", isMove=true, isCopy=true,
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Variable Condition", "Define the variable condition that must be valid.", ""
		})]
		public CheckVariableNextNode<BattleAIObjectSelection>[] condition = new CheckVariableNextNode<BattleAIObjectSelection>[] {
			new CheckVariableNextNode<BattleAIObjectSelection>()
		};

		public VariableForkNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			currentNode = this.next;
			string tmpKey = this.variable.key.GetValue(call);
			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				if(this.Check(ref currentNode, tmpKey, handlers[i], call))
				{
					break;
				}
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);
			return null;
		}

		private bool Check(ref int check, string varKey, VariableHandler handler, BattleAICall call)
		{
			for(int i = 0; i < this.condition.Length; i++)
			{
				if(this.condition[i].Check(varKey, this.variable, handler, call))
				{
					check = this.condition[i].next;
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString();
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1) + ": " + this.condition[index - 1].ToString();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Get Object Variable", "The combatant with the highest or lowest " +
		"float object variable will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Variable")]
	public class GetObjectVariableNode : BaseAINode
	{
		public BattleAISingleTargetSettings targetSettings = new BattleAISingleTargetSettings();


		// status
		[EditorSeparator]
		[EditorHelp("Variable Key", "The variable key that will be used.")]
		public StringValue<BattleAIObjectSelection> key = new StringValue<BattleAIObjectSelection>();

		[EditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"defined float object variable will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the " +
			"defined float object variable will be added to the target list.", "")]
		public bool getHighest = false;

		[EditorHelp("Variable Must Exist", "The float object variable must exist on the combatant. " +
			"If the variable doesn't exist, the combatant won't be added to the list.\n" +
			"If disabled, the default value (0) will be used.", "")]
		public bool variableMustExist = false;

		public GetObjectVariableNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			this.targetSettings.Use(call, this.Check);

			currentNode = this.next;
			call.checkTarget = null;
			return null;
		}

		private void Check(BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			float tmpVal = this.getHighest ? float.MinValue : float.MaxValue;

			// check for highest/lowest status value
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					call.checkTarget = list[i];
					string tmpKey = this.key.GetValue(call);
					if(!this.variableMustExist ||
						list[i].Variables.GetFloatKeys().Contains(tmpKey))
					{
						float objValue = list[i].Variables.GetFloat(tmpKey);
						if((this.getHighest && tmpVal < objValue) ||
							(!this.getHighest && tmpVal > objValue))
						{
							tmpVal = objValue;
							found = i;
						}
					}
				}
			}

			if(found >= 0 && !foundTargets.Contains(list[found]))
			{
				foundTargets.Add(list[found]);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") + this.key.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}
}
