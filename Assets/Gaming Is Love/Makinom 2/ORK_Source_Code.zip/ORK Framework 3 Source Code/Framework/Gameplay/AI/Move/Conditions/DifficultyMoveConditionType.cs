﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	[EditorSettingInfo("Difficulty", "Check the game's difficulty.")]
	public class DifficultyMoveConditionType : BaseMoveConditionType
	{
		public DifficultyCheck check = new DifficultyCheck();

		public DifficultyMoveConditionType()
		{

		}

		public override string ToString()
		{
			return "Difficulty";
		}

		public override bool IsValid(Combatant combatant, Combatant target)
		{
			return this.check.Check();
		}
	}
}
