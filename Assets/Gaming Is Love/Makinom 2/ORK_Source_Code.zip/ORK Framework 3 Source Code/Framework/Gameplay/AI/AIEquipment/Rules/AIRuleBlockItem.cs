﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIRuleBlockItem : BaseData
	{
		// items
		[EditorHelp("Block All Items", "All items are blocked, except for the defined items.\n" +
			"If disabled, all items are allowed, except for the defined items.", "")]
		[EditorFoldout("Block Items", "Define items that will be blocked from use for the battle AI.\n" +
			"The combatant can still use the items (e.g. if the player manually uses them), only the AI can't use them.", "")]
		public bool blockAllItems = false;

		[EditorHelp("Block Item Use", "Select the item that will be blocked from using.\n" +
			"If 'Block All Items' is enabled, the defined items will be allowed.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Item", "Adds an item that will be blocked from using (or allowed, when using 'Block All Items').", "",
			"Remove", "Removes the item.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Item", "Select the item that will be used.", ""
			})]
		public AssetSelection<ItemAsset>[] item = new AssetSelection<ItemAsset>[0];


		// item types
		[EditorHelp("Block All Types", "All item types are blocked, except for the defined types.\n" +
			"If disabled, all item types are allowed, except for the defined types.", "")]
		[EditorFoldout("Block Item Types", "Define item types that will be blocked from use for the battle AI, " +
			"items of the blocked types will be blocked from use.\n" +
			"The combatant can still use the items (e.g. if the player manually uses them), only the AI can't use them.", "")]
		public bool blockAllItemTypes = false;

		[EditorHelp("Use Sub-Types", "The sub-types of the defined item types will also be checked.", "")]
		public bool useSubTypes = false;

		[EditorHelp("Block Item Type Use", "Select the item type that will be blocked.\n" +
			"A combatant can't use any item of the selected type.\n" +
			"If 'Block All Types' is enabled, the defined ability types will be allowed.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Item Type", "Adds an item type that will be blocked from using (or allowed, when using 'Block All Types').", "",
			"Remove", "Removes the item type.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Item Type", "Select the item type that will be used.", ""
			})]
		public AssetSelection<ItemTypeAsset>[] itemType = new AssetSelection<ItemTypeAsset>[0];

		public AIRuleBlockItem()
		{

		}

		public bool CanUse(ItemShortcut item)
		{
			// blocked items
			if(this.blockAllItems)
			{
				for(int i = 0; i < this.item.Length; i++)
				{
					if(this.item[i].Is(item.Setting))
					{
						return true;
					}
				}
				return false;
			}
			else
			{
				for(int i = 0; i < this.item.Length; i++)
				{
					if(this.item[i].Is(item.Setting))
					{
						return false;
					}
				}
			}

			// blocked item types
			if(this.blockAllItemTypes)
			{
				for(int i = 0; i < this.itemType.Length; i++)
				{
					if(this.itemType[i].StoredAsset != null &&
						item.IsItemType(this.itemType[i].StoredAsset.Settings, this.useSubTypes))
					{
						return true;
					}
				}
				return false;
			}
			else
			{
				for(int i = 0; i < this.itemType.Length; i++)
				{
					if(this.itemType[i].StoredAsset != null &&
						item.IsItemType(this.itemType[i].StoredAsset.Settings, this.useSubTypes))
					{
						return false;
					}
				}
			}
			return true;
		}
	}
}
