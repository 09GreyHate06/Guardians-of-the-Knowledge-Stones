﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	public class BattleAISelectedDataTargetSettings : BaseData
	{
		[EditorHelp("User", "Select which combatant or combatant group will be used:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- Found Targets: The currently found targets.", "")]
		public BattleAISelectedDataUser targetType = BattleAISelectedDataUser.Ally;

		[EditorHelp("Use Body Parts", "Select if body parts of combatants will be included:\n" +
			"- Yes: Body parts will be included.\n" +
			"- No: Body parts will not be included.\n" +
			"- Only: Only body parts will be used.", "")]
		[EditorIndent]
		[EditorCondition("targetType", BattleAITargetType.Self)]
		[EditorCondition("targetType", BattleAISelectedDataUser.Ally)]
		[EditorCondition("targetType", BattleAISelectedDataUser.Enemy)]
		[EditorCondition("targetType", BattleAISelectedDataUser.All)]
		[EditorCondition("targetType", BattleAISelectedDataUser.FoundTargets)]
		[EditorEndCondition]
		public IncludeCheckType includeBodyParts = IncludeCheckType.Yes;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the user.", "")]
		[EditorCondition("targetType", BattleAISelectedDataUser.Ally)]
		[EditorCondition("targetType", BattleAISelectedDataUser.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the user.", "")]
		[EditorCondition("targetType", BattleAISelectedDataUser.Ally)]
		[EditorCondition("targetType", BattleAISelectedDataUser.Enemy)]
		[EditorCondition("targetType", BattleAISelectedDataUser.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;

		public BattleAISelectedDataTargetSettings()
		{

		}

		public override string ToString()
		{
			return this.targetType.ToString();
		}

		public virtual List<Combatant> GetTargetList(BattleAICall call)
		{
			return BattleAISettings.GetTargetList(this.targetType, this.includeBodyParts,
				this.targetExcludeSelf, this.targetExcludeFoundTargets,
				call);
		}
	}
}
