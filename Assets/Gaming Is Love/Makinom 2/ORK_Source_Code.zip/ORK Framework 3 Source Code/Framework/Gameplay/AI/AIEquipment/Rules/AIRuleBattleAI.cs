﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIRuleBattleAI : BaseData
	{
		// battle AI
		[EditorArray("Add Battle AI", "Adds a battle AI to this AI ruleset.\n" +
			"The battle AIs will be used in the order they're added (i.e. starting with 'Battle AI 0').", "",
			"Remove", "Removes this battle AI.", "", isMove=true, isCopy=true,
			removeCheckField="battleAI",
			foldout=true, foldoutText=new string[] {
				"Battle AI", "Define the battle AI that will be used and requirements that must be met.", ""
			})]
		public BattleAISelection[] battleAI = new BattleAISelection[0];

		public AIRuleBattleAI()
		{

		}
	}
}
