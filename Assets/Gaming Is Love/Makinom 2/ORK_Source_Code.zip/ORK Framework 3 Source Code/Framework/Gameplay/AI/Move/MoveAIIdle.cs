
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveAIIdle : BaseData, IFoldoutInfo
	{
		[EditorHelp("Schematic Asset", "Select the schematic asset that will be used.", "")]
		public AssetSource<MakinomSchematicAsset> schematicAsset = new AssetSource<MakinomSchematicAsset>();

		[EditorHelp("Chance", "The chance this schematic will be performed.\n" +
			"If the chance fails, no schematic will be performed " +
			"(i.e. no other schematic will be selected out of the list)", "")]
		public FloatValue<GameObjectSelection> chance = new FloatValue<GameObjectSelection>(100);

		public MoveAIIdle()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			return this.schematicAsset.ToString();
		}

		public virtual MakinomSchematicAsset GetSchematic(Combatant combatant)
		{
			if(Maki.GameSettings.CheckRandom(this.chance.GetValue(combatant.Call)))
			{
				return this.schematicAsset;
			}
			return null;
		}
	}
}
