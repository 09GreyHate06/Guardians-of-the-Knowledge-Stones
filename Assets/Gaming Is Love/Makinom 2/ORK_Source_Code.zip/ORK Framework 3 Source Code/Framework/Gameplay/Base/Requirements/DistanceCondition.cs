﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class DistanceCondition<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Ignore Height Distance", "Height differences are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		public bool ignoreHeightDistance = false;

		[EditorHelp("Ignore Radius", "The radius of objects will be ignored when calculating the distance (radius is defined by 'Radius' components).", "")]
		public bool ignoreRadius = false;

		[EditorHelp("Check Grid Distance", "Check the grid distance instead of the world space distance.")]
		[EditorSeparator]
		public bool checkGridDistance = false;

		[EditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[EditorCondition("checkGridDistance", true)]
		public bool blockDiagonalDistance1 = false;

		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		[EditorEndCondition]
		public bool ignoreSizeCells = false;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();


		// check
		[EditorSeparator]
		public ValueCheck<T> check = new ValueCheck<T>();

		public DistanceCondition()
		{

		}

		public virtual bool Check(IDataCall call, Combatant user, Combatant target)
		{
			if(this.checkGridDistance)
			{
				if(user.GridInitialized &&
					user.Grid.Cell != null &&
					target.GridInitialized &&
					target.Grid.Cell != null)
				{
					if(this.ignoreSizeCells)
					{
						return this.check.Check(
							user.Grid.Cell.CubeCoord.Distance(
								target.Grid.Cell.CubeCoord, this.blockDiagonalDistance1),
							call);
					}
					else
					{
						return user.Grid.CheckDistance(
							target, this.blockDiagonalDistance1,
							(int)this.check.value.GetValue(call),
							(int)(this.check.value2 != null ? this.check.value2.GetValue(call) : 0),
							this.check.type, null);
					}
				}
			}
			else
			{
				return this.check.Check(
					user.Object.DistanceTo(target, this.ignoreHeightDistance, this.ignoreRadius, this.horizontalPlane),
					call);
			}
			return false;
		}

		public virtual bool Check(IDataCall call, Combatant user, BattleGridCellComponent target)
		{
			if(this.checkGridDistance)
			{
				if(user.GridInitialized &&
					user.Grid.Cell != null)
				{
					if(this.ignoreSizeCells)
					{
						return this.check.Check(
							user.Grid.Cell.CubeCoord.Distance(
								target.CubeCoord, this.blockDiagonalDistance1),
							call);
					}
					else
					{
						return user.Grid.CheckDistance(
							target, this.blockDiagonalDistance1,
							(int)this.check.value.GetValue(call),
							(int)(this.check.value2 != null ? this.check.value2.GetValue(call) : 0),
							this.check.type, null);
					}
				}
			}
			else
			{
				return this.check.Check(
					user.Object.DistanceTo(target.gameObject, this.ignoreHeightDistance, this.ignoreRadius, this.horizontalPlane),
					call);
			}
			return false;
		}
	}
}
