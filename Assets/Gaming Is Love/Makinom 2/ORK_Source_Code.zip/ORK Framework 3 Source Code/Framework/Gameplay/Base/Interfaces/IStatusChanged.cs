using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface IStatusChanged
	{
		/// <summary>
		/// Warning: for status effects needs to manually register to auto effect checks of a combatant
		/// </summary>
		void NotifyStatusChanged();

		void NotifyStatusChanged(Combatant combatant, int id, int id2, float change);

		void NotifyStatusChanged(Combatant combatant, int id, int id2);

		void NotifyStatusChanged(Combatant combatant);

		void NotifyStatusChanged(Combatant combatant, StatusValue statusValue, int change);
		
		void NotifyStatusChanged(Combatant combatant, StatusEffect effect);

		void NotifyStatusChanged(Combatant combatant, ClassShortcut instance);
	}
}

