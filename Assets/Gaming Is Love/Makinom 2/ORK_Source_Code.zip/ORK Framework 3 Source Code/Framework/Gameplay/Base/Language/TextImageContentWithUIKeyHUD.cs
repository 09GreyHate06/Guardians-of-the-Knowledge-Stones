﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.UI
{
	public class TextImageContentWithUIKeyHUD : BaseData
	{
		public AddUIKeyHUD addHUD = new AddUIKeyHUD();

		[EditorSeparator]
		public LanguageData<TextImageContent> content = new LanguageData<TextImageContent>();

		public TextImageContentWithUIKeyHUD()
		{

		}

		public TextImageContentWithUIKeyHUD(string text)
		{
			this.content = new LanguageData<TextImageContent>(new TextImageContent(text));
		}

		public UIText GetContent(object hudUser, object uiKeyContent)
		{
			UIText text = this.content.Current;
			this.addHUD.Add(text, hudUser, uiKeyContent);
			return text;
		}

		public UIText GetContent(object hudUser, object uiKeyContent, Schematic schematic, int actorID, VariableHandler handler)
		{
			UIText text = new UIText(this.content.Current, schematic, actorID,
				handler != null ? handler : Maki.Game.Variables);
			this.addHUD.Add(text, hudUser, uiKeyContent);
			return text;
		}
	}
}
