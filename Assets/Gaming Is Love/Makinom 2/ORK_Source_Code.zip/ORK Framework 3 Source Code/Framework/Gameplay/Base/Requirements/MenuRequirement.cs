
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class MenuRequirementAsset : MakinomGenericAsset<MenuRequirement>
	{
		public MenuRequirementAsset()
		{

		}

		public override string DataName
		{
			get { return "Menu Requirement"; }
		}
	}

	public class MenuRequirement : BaseIndexData
	{
		[EditorHelp("Name", "The name of the menu requirement.", "")]
		[EditorFoldout("Base Settings", "Set the name, game state and variable conditions of this menu requirement.", "")]
		[EditorWidth(true)]
		public string name = "";

		// game state
		[EditorFoldout("Game State Conditions", "Define game state conditions that must be valid for this menu requirement to be valid.")]
		[EditorEndFoldout]
		public GameStateCondition gameState = new GameStateCondition();

		// variable conditions
		[EditorFoldout("Variable Conditions", "Define variable conditions that must be valid for this menu requirement to be valid.\n" +
			"Uses the player combatant as 'User'.")]
		[EditorEndFoldout(2)]
		public VariableCondition<GameObjectSelection> variables = new VariableCondition<GameObjectSelection>();


		// group requirements
		[EditorHelp("Check Group Size", "There has to be at least the given number of active group members " +
			"(not battle group members), otherwise the requirement is not valid.", "")]
		[EditorFoldout("Group Requirements", "Specific combatant or group conditions must be valid.", "")]
		public bool useGroupSize = false;

		[EditorHelp("Minimum Size", "The minimum size of the active group.", "")]
		[EditorIndent]
		[EditorCondition("useGroupSize", true)]
		[EditorEndCondition]
		public int minGroupSize = 1;

		[EditorHelp("Check Battle Size", "There has to be at least the given number of battle group members, " +
			"else the requirement is not valid.", "")]
		[EditorSeparator]
		public bool useBattleSize = false;

		[EditorHelp("Minimum Size", "The minimum size of the battle group.", "")]
		[EditorIndent]
		[EditorCondition("useBattleSize", true)]
		[EditorEndCondition]
		public int minBattleSize = 1;


		// status conditions
		[EditorHelp("Only Battle Group", "Only the battle group will be checked for the status conditions.\n" +
			"If disabled, the whole active group will be checked.\n" +
			"All combatants that are checked must met the status conditions, otherwise the condition is not valid.", "")]
		[EditorFoldout("Group Member Status Conditions", "All group members must match defined status conditions.")]
		public bool onlyBattle = true;

		[EditorEndFoldout]
		public StatusConditionSettings statusConditions = new StatusConditionSettings();


		// combatants
		[EditorFoldout("Combatant Requirement", "Define specific combatants that must be in the " +
			"active player group and match optional status conditions.")]
		[EditorEndFoldout(2)]
		[EditorArray("Add Combatant Requirement", "Adds a required combatant.", "",
			"Remove", "Removes the required combatant.", "", isCopy=true, isMove=true,
			removeCheckField="combatant",
			foldout=true, foldoutText=new string[] {
				"Combatant Requirement", "Define the combatant that is required.", ""
		})]
		public CombatantRequirement[] combatant = new CombatantRequirement[0];


		// general
		[EditorHelp("Has Items", "The inventory must contain at least one item.", "")]
		[EditorFoldout("General Requirements", "Specific inventory, log or quest conditions must be valid.", "")]
		public bool hasItems = false;

		[EditorHelp("Has Equipment", "The inventory must contain at least one equipment.", "")]
		public bool hasEquipment = false;

		[EditorHelp("Check Equipped", "Additionally checks if one of the player group members has an equipped equipment.", "")]
		[EditorIndent]
		[EditorCondition("hasEquipment", true)]
		[EditorEndCondition]
		public bool checkEquipped = false;

		[EditorHelp("Knows Recipes", "The group must know at least one crafting recipe.", "")]
		public bool knowsRecipes = false;

		[EditorHelp("Knows Logs", "The group must know at least one log.", "")]
		public bool knowsLogs = false;

		// bestiary
		[EditorHelp("Has Bestiary Entries", "The bestiary must contain at least one entry.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Other Requirements")]
		public bool hasBestiaryEntries = false;

		// items
		[EditorArray("Add Required Item", "Adds a required item.", "",
			"Remove", "Removes this item.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Item Requirement", "Define the item that must be in the player's inventory.", ""
		})]
		public ItemGain<GameObjectSelection>[] item = new ItemGain<GameObjectSelection>[0];


		// quests
		[EditorFoldout("Quest Conditions", "Check for defined quest conditions.", "")]
		[EditorEndFoldout(2)]
		public QuestStateTypeCondition questCondition = new QuestStateTypeCondition(false);

		public MenuRequirement()
		{

		}

		public MenuRequirement(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}

		// group
		public bool CheckGroup()
		{
			// check group sizes
			if(this.useGroupSize && ORK.Game.ActiveGroup.Size < this.minGroupSize)
			{
				return false;
			}
			if(this.useBattleSize && ORK.Game.ActiveGroup.BattleSize < this.minBattleSize)
			{
				return false;
			}

			// check group status
			List<Combatant> list = this.onlyBattle ?
				ORK.Game.ActiveGroup.GetBattle() : ORK.Game.ActiveGroup.GetGroup();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					!this.statusConditions.Check(list[i]))
				{
					return false;
				}
			}
			return true;
		}

		public bool CheckCombatants()
		{
			bool check = true;
			for(int i = 0; i < this.combatant.Length; i++)
			{
				check = this.combatant[i].Check();
				if(check == false)
				{
					break;
				}
			}
			return check;
		}

		public bool CheckGeneral()
		{
			if(this.hasItems &&
				ORK.Game.ActiveGroup.Inventory.Items.IsEmpty)
			{
				return false;
			}
			if(this.hasEquipment &&
				!ORK.Game.ActiveGroup.Inventory.Equipment.IsEmpty &&
				(!this.checkEquipped ||
					!ORK.Game.ActiveGroup.Inventory.HasEquippedEquipment()))
			{
				return false;
			}
			if(this.knowsRecipes && ORK.Game.ActiveGroup.Inventory.Crafting.IsEmpty)
			{
				return false;
			}
			if(this.knowsLogs && !ORK.Game.Logs.HasLogs())
			{
				return false;
			}
			// quests
			if(!this.questCondition.Check())
			{
				return false;
			}
			// bestiary
			if(this.hasBestiaryEntries && ORK.Game.Bestiary.Count == 0)
			{
				return false;
			}
			// items
			if(this.item.Length > 0 &&
				!ORK.Game.ActiveGroup.Inventory.Has(ORK.Game.ActiveGroup.Leader.Call, this.item))
			{
				return false;
			}
			return true;
		}

		// overall check
		public bool Check()
		{
			return this.gameState.Check() &&
				this.variables.CheckVariables(ORK.Game.ActiveGroup.Leader.Call) &&
				this.CheckGroup() &&
				this.CheckCombatants() &&
				this.CheckGeneral();
		}
	}
}

