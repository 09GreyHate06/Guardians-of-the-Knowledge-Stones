﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class MarkNewContent : BaseData
	{
		[EditorHelp("Mark New Data", "Select if and when new data will be marked:\n" +
			"- None: Doesn't mark new data.\n" +
			"- First Add: Only the first time adding the data.\n" +
			"- Each Add: Each time when adding the data.\n" +
			"- Each Change: Each time the data is changed.", "")]
		public MarkNewContentType markType = MarkNewContentType.None;

		[EditorHelp("Unmark New Data", "Select if and when new data will be marked as seen (i.e. removing new data mark):\n" +
			"- None: Doesn't unmark new data.\n" +
			"- View: When viewing the data (e.g. in a menu list).\n" +
			"- Selection: When selecting the data (e.g. selecting/highlighting the choice in a menu).", "")]
		public UnmarkNewContentType unmarkType = UnmarkNewContentType.None;

		public MarkNewContent()
		{

		}

		/*
		============================================================================
		Mark functions
		============================================================================
		*/
		public bool IsMarkFirstAdd
		{
			get { return MarkNewContentType.None != this.markType; }
		}

		public bool IsMarkEachAdd
		{
			get
			{
				return MarkNewContentType.EachAdd == this.markType ||
					MarkNewContentType.EachChange == this.markType;
			}
		}

		public bool IsMarkEachChange
		{
			get { return MarkNewContentType.EachChange == this.markType; }
		}

		public bool MarkFirstAdd(IMarkNewContent content)
		{
			if(this.IsMarkFirstAdd)
			{
				content.IsNewContent = true;
				return true;
			}
			return false;
		}

		public bool MarkEachAdd(IMarkNewContent content)
		{
			if(this.IsMarkEachAdd)
			{
				content.IsNewContent = true;
				return true;
			}
			return false;
		}

		public bool MarkEachChange(IMarkNewContent content)
		{
			if(this.IsMarkEachChange)
			{
				content.IsNewContent = true;
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Unmark functions
		============================================================================
		*/
		public bool IsUnmarkView
		{
			get { return UnmarkNewContentType.View == this.unmarkType; }
		}

		public bool IsUnmarkSelection
		{
			get { return UnmarkNewContentType.Selection == this.unmarkType; }
		}

		public bool UnmarkView(IMarkNewContent content, object value)
		{
			if(content.IsNewContent &&
				this.IsUnmarkView)
			{
				content.UnmarkNewContent(value);
				content.IsNewContent = false;
				return true;
			}
			return false;
		}

		public bool UnmarkSelection(IMarkNewContent content, object value)
		{
			if(content.IsNewContent &&
				this.IsUnmarkSelection)
			{
				content.UnmarkNewContent(value);
				content.IsNewContent = false;
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Setting getters
		============================================================================
		*/
		public static MarkNewContent GetForShortcut(IShortcut shortcut)
		{
			if(shortcut is AbilityShortcut)
			{
				return MarkNewContent.Ability;
			}
			else if(shortcut is ClassShortcut)
			{
				return MarkNewContent.Class;
			}
			else if(shortcut is AIBehaviourShortcut)
			{
				return MarkNewContent.AIBehaviour;
			}
			else if(shortcut is AIRulesetShortcut)
			{
				return MarkNewContent.AIRuleset;
			}
			else if(shortcut is ItemShortcut)
			{
				return MarkNewContent.Item;
			}
			else if(shortcut is EquipShortcut)
			{
				return MarkNewContent.Equipment;
			}
			else if(shortcut is CraftingRecipeShortcut)
			{
				return MarkNewContent.CraftingRecipe;
			}
			return null;
		}

		public static MarkNewContent Ability
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownAbility)
				{
					return ORK.InventorySettings.markNewContent.ability;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Class
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownClass)
				{
					return ORK.InventorySettings.markNewContent.classContent;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent AIBehaviour
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownAIBehaviour)
				{
					return ORK.InventorySettings.markNewContent.aiBehaviour;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent AIRuleset
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownAIRuleset)
				{
					return ORK.InventorySettings.markNewContent.aiRuleset;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Bestiary
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownBestiary)
				{
					return ORK.InventorySettings.markNewContent.bestiary;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent CraftingRecipe
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownCraftingRecipe)
				{
					return ORK.InventorySettings.markNewContent.craftingRecipe;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Equipment
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownEquipment)
				{
					return ORK.InventorySettings.markNewContent.equipment;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Item
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownItem)
				{
					return ORK.InventorySettings.markNewContent.item;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Logs
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownLog)
				{
					return ORK.InventorySettings.markNewContent.log;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Quests
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownQuest)
				{
					return ORK.InventorySettings.markNewContent.quest;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent ResearchTree
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownResearchTree)
				{
					return ORK.InventorySettings.markNewContent.researchTree;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}

		public static MarkNewContent Shop
		{
			get
			{
				if(ORK.InventorySettings.markNewContent.ownShop)
				{
					return ORK.InventorySettings.markNewContent.shop;
				}
				return ORK.InventorySettings.markNewContent.markNewContent;
			}
		}
	}
}
