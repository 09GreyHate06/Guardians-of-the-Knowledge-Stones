﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class CombatantGeneralConditionSettings : BaseData
	{
		[EditorHelp("Use Conditions", "Use conditions, e.g. check for valid combatant status or variable conditions.\n" +
			"The combatant's variables and selected data are available as 'Local' origin, the combatant itself is the 'User'.", "")]
		public bool useConditions = false;

		[EditorCondition("useConditions", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public GeneralConditionSetting<GameObjectSelection> conditions;

		public CombatantGeneralConditionSettings()
		{

		}

		public virtual bool Has
		{
			get { return this.useConditions && this.conditions.Has; }
		}

		public virtual bool Check(Combatant combatant)
		{
			return !this.useConditions ||
				(combatant != null && this.conditions.Check(combatant.Call));
		}

		public virtual bool Check(DataCall call)
		{
			return !this.useConditions || this.conditions.Check(call);
		}

		public virtual void FilterList(List<Combatant> list)
		{
			if(list != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(!this.Check(list[i]))
					{
						list.RemoveAt(i--);
					}
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual bool IsCheck(ResearchItem item, ResearchItemState state)
		{
			return false;
		}
	}
}
