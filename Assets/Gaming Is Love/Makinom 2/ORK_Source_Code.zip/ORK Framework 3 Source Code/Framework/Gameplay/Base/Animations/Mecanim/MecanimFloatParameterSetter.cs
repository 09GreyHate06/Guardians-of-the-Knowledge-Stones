﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Animations
{
	public class MecanimFloatParameterSetter
	{
		public int hash = -1;

		public float dampTime = -1;

		public MecanimFloatParameterSetter(string name, MecanimFloatParameterDamping damping)
		{
			this.hash = Animator.StringToHash(name);
			this.dampTime = damping.useDamping ? damping.dampTime : -1;
		}

		public void Set(Animator animator, float value)
		{
			if(this.dampTime > 0)
			{
				animator.SetFloat(this.hash, value, this.dampTime, Maki.Game.DeltaTime * ORK.Game.AnimationFactor);
				if(float.IsNaN(animator.GetFloat(this.hash)))
				{
					animator.SetFloat(this.hash, value);
				}
			}
			else
			{
				animator.SetFloat(this.hash, value);
			}
		}
	}
}
