﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Class Slot Available", "A defined class slot must or mustn't be available.")]
	public class ClassSlotAvailableStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Class Slot", "Select the class slot that will be check.", "")]
		public AssetSelection<ClassSlotAsset> classSlot = new AssetSelection<ClassSlotAsset>();

		[EditorHelp("Is Available", "The class slot must be available on the combatant.\n" +
			"If disabled, the class slot mustn't be available.", "")]
		public bool isAvailable = true;


		public ClassSlotAvailableStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.classSlot.ToString() + (this.isAvailable ? " is available" : " not available");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.classSlot.StoredAsset != null)
			{
				ClassSlot slot = combatant.Class.GetSlot(this.classSlot.StoredAsset.Settings);
				return slot != null && (slot.Available == this.isAvailable);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ClassSlotsChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ClassSlotsChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.ClassSlotsChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.ClassSlotsChangedSimple -= notify;
		}
	}
}
