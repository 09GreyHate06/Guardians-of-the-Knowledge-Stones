﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Difficulty", "Check the game's difficulty.")]
	public class DifficultyGeneralCondition<T> : BaseGeneralCondition<T> where T : IObjectSelection, new()
	{
		public DifficultyCheck check = new DifficultyCheck();

		public DifficultyGeneralCondition()
		{

		}

		public override string ToString()
		{
			return "Difficulty";
		}

		public override bool Check(IDataCall call)
		{
			return this.check.Check();
		}

		public override void Register(IDataCall call, Notify notify, ref List<VariableHandler> unregisterHandlers)
		{
			ORK.Game.DifficultyChanged += notify;
		}

		public override void Unregister(IDataCall call, Notify notify)
		{
			ORK.Game.DifficultyChanged -= notify;
		}
	}
}
