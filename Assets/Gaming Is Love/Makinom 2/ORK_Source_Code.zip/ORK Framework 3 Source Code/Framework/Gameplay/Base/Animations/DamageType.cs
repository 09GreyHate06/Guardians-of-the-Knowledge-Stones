
using UnityEngine;
using GamingIsLove.ORKFramework.Animations;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class DamageTypeAsset : MakinomGenericAsset<DamageType>
	{
		public DamageTypeAsset()
		{

		}

		public override string DataName
		{
			get { return "Damage Type"; }
		}
	}

	public class DamageType : BaseIndexData
	{
		[EditorHelp("Name", "The name of this damage type.", "")]
		[EditorFoldout("Base Settings", "Set the name and animation types of this damage type.", "")]
		[EditorWidth(true)]
		public string name = "";


		// animation types
		// damage animation
		[EditorHelp("Use Damage Animation", "Play a damage animation when a combatant takes damage.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Damage Animation")]
		public bool useDamage = true;

		[EditorHelp("Damage", "Select the animation type used for the damage animation " +
			"(i.e. when the combatant takes damage).", "")]
		[EditorCondition("useDamage", true)]
		[EditorEndCondition]
		public AssetSelection<AnimationTypeAsset> damageAnimationType = new AssetSelection<AnimationTypeAsset>();

		// critical damage animation
		[EditorHelp("Use Critical Animation", "Play a critical damage animation when a combatant takes critical damage.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Critical Damage Animation")]
		public bool useCriticalDamage = true;

		[EditorHelp("Critical Damage", "Select the animation type used for the critical damage animation " +
			"(i.e. when the combatant takes critical damage).", "")]
		[EditorCondition("useCriticalDamage", true)]
		[EditorEndCondition]
		public AssetSelection<AnimationTypeAsset> criticalDamageAnimationType = new AssetSelection<AnimationTypeAsset>();


		// evade animation
		[EditorHelp("Use Evade Animation", "Play an evade animation when a combatant evades an attack.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Evade Animation")]
		public bool useEvade = true;

		[EditorHelp("Evade", "Select the animation type used for the evade animation " +
			"(i.e. when the combatant evades an attack).", "")]
		[EditorCondition("useEvade", true)]
		[EditorEndCondition]
		public AssetSelection<AnimationTypeAsset> evadeAnimationType = new AssetSelection<AnimationTypeAsset>();


		// block animation
		[EditorHelp("Use Block Animation", "Play a block animation when a combatant blocks an attack.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Block Animation")]
		public bool useBlock = false;

		[EditorHelp("Block", "Select the animation type used for the block animation " +
			"(i.e. when the combatant blocks an attack).", "")]
		[EditorEndFoldout]
		[EditorCondition("useBlock", true)]
		[EditorEndCondition]
		public AssetSelection<AnimationTypeAsset> blockAnimationType = new AssetSelection<AnimationTypeAsset>();

		public DamageType()
		{

		}

		public DamageType(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}
	}
}
