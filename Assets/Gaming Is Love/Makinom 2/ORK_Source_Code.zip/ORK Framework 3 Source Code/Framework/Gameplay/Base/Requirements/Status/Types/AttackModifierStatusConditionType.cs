﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Attack Modifier", "The defined attack modifier attribute's value will be compared to a defined value.")]
	public class AttackModifierStatusConditionType : BaseStatusConditionType
	{
		public AttackModifierAttributeSelection selection = new AttackModifierAttributeSelection();

		[EditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the modifier attribute.\n" +
			"- Base Value: The base value of the modifier attribute (without bonuses).\n" +
			"- Min Value: The minimum value of the modifier attribute.\n" +
			"- Max Value: The maximum value of the modifier attribute.\n" +
			"- Start Value: The start value of the modifier attribute (i.e. the modifier attribute's initial value).\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.", "")]
		public ModifierGetValue getValue = ModifierGetValue.CurrentValue;

		[EditorSeparator]
		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		public AttackModifierStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.selection.ToString() + " " + this.getValue + " " + this.check.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(
				this.selection.GetValue(combatant, this.getValue),
				combatant.Call);
		}

		public override bool CheckPreview(Combatant combatant)
		{
			return this.check.Check(
				this.selection.GetValue(combatant, ModifierGetValue.PreviewValue),
				combatant.Call);
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete ||
					this.selection.CheckBestiary(combatant)))
			{
				return this.check.Check(
					this.selection.GetValue(combatant, this.getValue),
					combatant.Call);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			AttackModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.Changed += notify.NotifyStatusChanged;
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			AttackModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.Changed -= notify.NotifyStatusChanged;
			}
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			AttackModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.SimpleChanged += notify;
			}
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			AttackModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.SimpleChanged -= notify;
			}
		}
	}
}
