﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CursorInput : BaseData
	{
		[EditorHelp("Vertical Axis", "The input key used to move the cursor vertically.", "")]
		public AssetSelection<InputKeyAsset> verticalAxis = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Horizontal Axis", "The input key used to move the cursor horizontally.", "")]
		public AssetSelection<InputKeyAsset> horizontalAxis = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Axis Minimum", "Define the minimum value an axis must have to trigger a cursor change.", "")]
		[EditorLimit(0.0f, 1.0f)]
		public float axisMinimum = 0.3f;

		[EditorHelp("Use Camera Direction", "The axis keys will change the cursor based on the camera view (main camera).", "")]
		public bool useCameraDirection = false;

		[EditorHelp("Camera Direction Offset", "Define the angle in degrees that will be added to the camera direction.\n" +
			"E.g. use 45 to shift the cursor change 45 degrees to the camera view.", "")]
		[EditorCondition("useCameraDirection", true)]
		[EditorEndCondition]
		public float cameraDirectionOffset = 0;

		public CursorInput()
		{

		}

		public Vector3 GetInput(Combatant user, HorizontalPlaneType horizontalPlane)
		{
			float h = InputKey.GetAxis(this.horizontalAxis, user.InputID);
			float v = InputKey.GetAxis(this.verticalAxis, user.InputID);

			if(h <= -this.axisMinimum || h >= this.axisMinimum ||
				v <= -this.axisMinimum || v >= this.axisMinimum)
			{
				if(this.useCameraDirection &&
					Maki.Game.Camera != null)
				{
					return InputHelper.GetDirectionJoystick(h, v, Maki.Game.Camera.transform,
						horizontalPlane, this.cameraDirectionOffset);
				}
				else
				{
					if(HorizontalPlaneType.XZ == horizontalPlane)
					{
						return new Vector3(h, 0, v);
					}
					else if(HorizontalPlaneType.XY == horizontalPlane)
					{
						return new Vector3(h, v, 0);
					}
				}
			}

			return Vector3.zero;
		}
	}
}
