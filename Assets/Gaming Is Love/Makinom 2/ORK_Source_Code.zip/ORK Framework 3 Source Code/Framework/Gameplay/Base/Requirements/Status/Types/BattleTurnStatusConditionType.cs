﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Battle Turn", "The current battle turn will be compared with a defined value (combatant independent turn).")]
	public class BattleTurnStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Every n Turns", "The check is true every set number of turns " +
			"(e.g. every 2nd turn when 'turn' is set to 2).\n" +
			"If disabled, the check is true at the specific turn number " +
			"(e.g. the 5th turn of a combatant).", "")]
		[EditorSeparator]
		[EditorTitleLabel("Turn")]
		public bool everyTurn = false;

		[EditorHelp("Turn", "Set the turn that will be checked for.", "")]
		[EditorCondition("everyTurn", true)]
		[EditorAutoInit]
		public FloatValue<GameObjectSelection> turn;

		[EditorElseCondition]
		[EditorEndCondition]
		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		[EditorHelp("Is Valid", "The turn check must be valid.\n" +
			"If disabled, the turn check mustn't be valid.", "")]
		public bool isValid = true;

		public BattleTurnStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.everyTurn ?
				((this.isValid ? "Every " : "Not every ") + this.turn.ToString() + " battle turns") :
				((this.isValid ? "Battle turn " : "Battle turn not ") + this.check.ToString());
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return (this.everyTurn ?
				((ORK.Battle.Turn % this.turn.GetValue(combatant.Call)) == 0) :
				this.check.Check(ORK.Battle.Turn, combatant.Call)) == this.isValid;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.TurnStateChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.TurnStateChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.TurnStateChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.TurnStateChangedSimple -= notify;
		}
	}
}
