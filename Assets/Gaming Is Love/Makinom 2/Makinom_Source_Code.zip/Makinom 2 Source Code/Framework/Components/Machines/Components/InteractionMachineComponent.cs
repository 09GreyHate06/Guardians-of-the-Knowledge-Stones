
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Interaction Machine")]
	public class InteractionMachineComponent : BaseMachineComponent, ISerializationCallbackReceiver, IInteractionBehaviour, IDropInteraction
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected bool registered = false;

		protected int isInTrigger = 0;

		protected int isColliding = 0;

		protected object droppedContent;

		public override bool CanRestart(GameObject startingObject)
		{
			return this.settings.startSetting.CanStart(this, startingObject);
		}

		public virtual float MoveDestinationOffset
		{
			get
			{
				return (this.settings.moveToInteraction.overrideInteractionRadius ?
						(this.settings.moveToInteraction.setInteractionRadius ?
							this.settings.moveToInteraction.interactionRadius :
							RadiusComponent.GetRadius(this.gameObject)) :
						(Maki.GameControls.interaction.moveToInteraction.setInteractionRadius ?
							Maki.GameControls.interaction.moveToInteraction.defaultInteractionRadius :
							RadiusComponent.GetRadius(this.gameObject))) +
					(this.settings.moveToInteraction.overrideStopDistance ?
						this.settings.moveToInteraction.stopDistance :
						Maki.GameControls.interaction.moveToInteraction.defaultStopDistance);
			}
		}

		public virtual MoveToInteractionComponentSettings MoveToInteractionSettings
		{
			get { return this.settings.moveToInteraction; }
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public override void Register()
		{
			if(!this.registered && Maki.Instantiated)
			{
				Maki.Game.Interactions.Add(this);
				this.registered = true;
			}
		}

		public override void Unregister()
		{
			if(this.registered && Maki.Instantiated)
			{
				Maki.Game.Interactions.Remove(this);
				this.registered = false;
			}
		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		public virtual bool IsInteract
		{
			get { return this.settings.startSetting.isInteract; }
		}

		public virtual bool CanInteract(GameObject startingObject)
		{
			return !this.machineStarted &&
				this.settings.startSetting.isInteract &&
				this.settings.startSetting.CanStart(this, startingObject);
		}

		public virtual bool Interact(GameObject startingObject)
		{
			if(this.settings.startSetting.isInteract &&
				this.settings.startSetting.CanStart(this, startingObject) &&
				this.settings.startSetting.CheckInteractionDistance(
					this.gameObject, startingObject))
			{
				this.StartMoveToInteraction(startingObject);
				return true;
			}
			return false;
		}

		public virtual bool DropInteract(DragInfo drag)
		{
			if(!this.machineStarted && !Maki.Game.Paused &&
				this.settings.startSetting.CheckDrop(this, this.gameObject, drag))
			{
				this.droppedContent = drag.Content;
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
				return true;
			}
			return false;
		}

		protected virtual void StartMoveToInteraction(GameObject startingObject)
		{
			if(startingObject != null &&
				Maki.GameControls.interaction.moveToInteraction.useMoveToInteraction &&
				this.settings.moveToInteraction.useMoveToInteraction)
			{
				MoveToInteractionComponent comp = startingObject.GetComponent<MoveToInteractionComponent>();
				if(comp == null)
				{
					comp = startingObject.AddComponent<MoveToInteractionComponent>();
					comp.Init();
				}
				comp.MoveToInteraction(this);
			}
			else
			{
				this.StartMachine(startingObject);
			}
		}

		public virtual void StartInteraction(GameObject startingObject)
		{
			this.StartMachine(startingObject);
		}

		public virtual void StartMachine(GameObject startingObject)
		{
			this.StartMachine(startingObject,
				this.startVariableSetting.HasStartVariables ?
					this.startVariableSetting.GetStartVariables(
						this.startVariableSetting.NeedsCall ?
							new DataCall(this.gameObject, startingObject,
								this.assetSetting.inputID.GetInputID(this.gameObject, startingObject)) : null) :
					null);
		}

		public override void StartMachine(GameObject startingObject, VariableHandler startVariables)
		{
			if(!this.machineStarted)
			{
				if(this.SchematicFound &&
					(Maki.Control.CanInteract ||
						MachineExecutionType.Blocking != this.assetSetting.executionType))
				{
					this.CancelAutoDestroy();

					// do turns
					TransformHelper.InteractionTurns(this.assetSetting.turnStartingObject, startingObject,
						this.assetSetting.turnMachineObject, this.gameObject, ref this.storedRotation);

					if(MachineExecutionType.Multi == this.assetSetting.executionType)
					{
						Schematic tmpSchematic = null;
						if(this.schematic.Executing)
						{
							tmpSchematic = new Schematic(this.assetSetting.schematicAsset);
						}
						else
						{
							this.schematic.Clear();
							tmpSchematic = this.schematic;
						}

						if(tmpSchematic != null)
						{
							if(startVariables != null)
							{
								tmpSchematic.Variables = startVariables;
							}
							if(this.droppedContent != null)
							{
								tmpSchematic.SelectedData = SelectedDataHelper.CreateSelectedData(
									SelectedDataHelper.Action, this.droppedContent);
								this.droppedContent = null;
							}
							this.StartMachine(tmpSchematic, startingObject);
						}
					}
					else
					{
						this.machineStarted = true;
						if(startVariables != null)
						{
							this.schematic.Variables = startVariables;
						}
						if(this.droppedContent != null)
						{
							this.schematic.SelectedData = SelectedDataHelper.CreateSelectedData(
								SelectedDataHelper.Action, this.droppedContent);
							this.droppedContent = null;
						}
						this.StartMachine(this.schematic, startingObject);
					}
				}
			}
		}

		public virtual void AutoStopInteraction()
		{
			this.StopMachine();
		}


		/*
		============================================================================
		Mouse functions
		============================================================================
		*/
		protected virtual void OnMouseDown()
		{
			if(this.settings.startSetting.CheckMouseDown(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		protected virtual void OnMouseDrag()
		{
			if(this.settings.startSetting.CheckMouseDrag(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		protected virtual void OnMouseUp()
		{
			if(this.settings.startSetting.CheckMouseUp(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		protected virtual void OnMouseUpAsButton()
		{
			if(this.settings.startSetting.CheckMouseUpAsButton(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		protected virtual void OnMouseEnter()
		{
			if(this.settings.startSetting.CheckMouseEnter(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		protected virtual void OnMouseOver()
		{
			if(this.settings.startSetting.CheckMouseOver(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}

		protected virtual void OnMouseExit()
		{
			if(this.settings.startSetting.CheckMouseExit(this, this.gameObject))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
		}


		/*
		============================================================================
		Key functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(!this.machineStarted && !Maki.Game.Paused &&
				this.settings.startSetting.CheckKeyPress(this, this.gameObject,
					this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject),
					this.isInTrigger > 0, this.isColliding > 0))
			{
				this.StartMoveToInteraction(Maki.Game.Player.GameObject);
			}
			else if(this.machineStarted &&
				this.settings.useAutoStopDistance &&
				Maki.GameControls.interaction.autoStopInteraction.Check(this.gameObject))
			{
				this.AutoStopInteraction();
			}
		}

		protected virtual void OnTriggerEnter(Collider other)
		{
			if(Maki.Game.Player.IsPlayer(other.gameObject) &&
				(!this.settings.startSetting.startByRoot ||
					other.transform == other.transform.root))
			{
				this.isInTrigger++;
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			if(Maki.Game.Player.IsPlayer(other.gameObject) &&
				(!this.settings.startSetting.startByRoot ||
					other.transform == other.transform.root))
			{
				this.isInTrigger--;
			}
		}

		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(Maki.Game.Player.IsPlayer(other.gameObject) &&
				(!this.settings.startSetting.startByRoot ||
					other.transform == other.transform.root))
			{
				this.isInTrigger++;
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			if(Maki.Game.Player.IsPlayer(other.gameObject) &&
				(!this.settings.startSetting.startByRoot ||
					other.transform == other.transform.root))
			{
				this.isInTrigger--;
			}
		}

		protected virtual void OnCollisionEnter(Collision collision)
		{
			if(Maki.Game.Player.IsPlayer(collision.gameObject) &&
				(!this.settings.startSetting.startByRoot ||
					collision.transform == collision.transform.root))
			{
				this.isColliding++;
			}
		}

		protected virtual void OnCollisionExit(Collision collision)
		{
			if(Maki.Game.Player.IsPlayer(collision.gameObject) &&
				(!this.settings.startSetting.startByRoot ||
					collision.transform == collision.transform.root))
			{
				this.isColliding--;
			}
		}

		protected virtual void OnCollisionEnter2D(Collision2D collision)
		{
			if(Maki.Game.Player.IsPlayer(collision.gameObject) &&
				(!this.settings.startSetting.startByRoot ||
					collision.transform == collision.transform.root))
			{
				this.isColliding++;
			}
		}

		protected virtual void OnCollisionExit2D(Collision2D collision)
		{
			if(Maki.Game.Player.IsPlayer(collision.gameObject) &&
				(!this.settings.startSetting.startByRoot ||
					collision.transform == collision.transform.root))
			{
				this.isColliding--;
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/InteractionMachineComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Use Auto Stop Distance", "Automatically stop the interaction if the player is a defined distance away from the game object.\n" +
				"The auto stop distance settings can be set up in 'Base/Control > Game Controls' in the 'Interaction Settings > Auto Stop Interaction'.\n" +
				"Please note that this isn't used for 'Multi' execution types.")]
			[EditorFoldout("Start Settings", "Define the start settings of this machine.", "")]
			public bool useAutoStopDistance = false;

			[EditorSeparator]
			public InteractionMachineStartSetting startSetting = new InteractionMachineStartSetting();

			[EditorFoldout("Move To Interaction", "This interaction can optionally move the player to the interaction before starting.", "",
				initialState = false)]
			[EditorEndFoldout(2)]
			public MoveToInteractionComponentSettings moveToInteraction = new MoveToInteractionComponentSettings();

			public Settings()
			{

			}
		}
	}
}
