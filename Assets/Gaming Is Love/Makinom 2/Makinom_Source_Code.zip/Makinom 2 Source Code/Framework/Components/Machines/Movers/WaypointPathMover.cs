
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class WaypointPathMover : MonoBehaviour
	{
		// objects
		protected WaypointPathComponent path;

		protected MoveComponentSettings.Instance moveSettings;

		protected PathStartSettings startSettings;

		protected Notify callback;

		protected GetFloat deltaTime;

		protected bool inPause = false;


		// follow
		protected float value = 0;

		protected float maxValue = 0;

		protected float timeout = 0;

		protected float pointTimeout = 0;


		// path info
		protected int startPointIndex = 0;

		protected float startPathValue = 0;

		protected int pointIndex = 0;

		// 0-1, 0 is start point, 1 is end point
		protected float pointStart = 0;

		protected float pointEnd = 0;


		// rotation
		protected PathRotationSettings rotationSettings;

		protected Transform lookAtObject;

		protected Vector3 rotation;

		protected float smoothRotation = 0;


		// options
		protected bool pause = false;

		protected bool useUpdate = false;

		protected bool useFixedUpdate = false;

		protected bool reverse = false;

		protected GravityType gravityType = GravityType.None;


		/*
		============================================================================
		Get/set functions
		============================================================================
		*/
		public virtual bool Pause
		{
			get { return this.pause; }
			set { this.pause = value; }
		}

		public virtual bool Reverse
		{
			get { return this.reverse; }
			set { this.reverse = value; }
		}


		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public virtual void Clear()
		{
			this.inPause = false;
			this.pause = false;
			this.useUpdate = false;
			this.useFixedUpdate = false;
			this.reverse = false;
			this.gravityType = GravityType.None;

			this.startSettings = null;
			this.rotationSettings = null;
			this.lookAtObject = null;
			this.rotation = Vector3.zero;
			this.smoothRotation = 0;

			this.callback = null;
			this.deltaTime = null;

			this.path = null;
			this.pointIndex = 0;
			this.pointStart = 0;
			this.pointEnd = 0;

			this.value = 0;
			this.maxValue = 0;
			this.timeout = 0;
			this.pointTimeout = 0;
		}

		public virtual void FollowTime(WaypointPathComponent path, MoveComponentSettings.Instance moveSettings,
			PathStartSettings startSettings, float time, float pointTimeout, GravityType gravityType,
			PathRotationSettings rotationSettings, Transform lookAtObject, Vector3 rotation, float smoothRotation,
			GetFloat deltaTime, bool inPause, Notify callback)
		{
			Notify tmpCallback = this.callback;
			this.Clear();

			this.path = path;
			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.moveSettings = moveSettings;
			this.gravityType = gravityType;
			this.maxValue = time;
			this.pointTimeout = pointTimeout;

			this.rotationSettings = rotationSettings;
			this.lookAtObject = lookAtObject;
			this.rotation = rotation;
			this.smoothRotation = smoothRotation;

			this.callback = callback;

			this.startSettings = startSettings;
			this.startSettings.GetStartPoint(this.path, this.transform.position,
				ref this.startPointIndex, ref this.startPathValue);
			this.pointIndex = this.startPointIndex;
			this.reverse = this.startSettings.reverseDirection;

			this.StartFollow();

			if(tmpCallback != null)
			{
				tmpCallback();
			}
		}

		public virtual void FollowSpeed(WaypointPathComponent path, MoveComponentSettings.Instance moveSettings,
			PathStartSettings startSettings, float speed, float pointTimeout, GravityType gravityType,
			PathRotationSettings rotationSettings, Transform lookAtObject, Vector3 rotation, float smoothRotation,
			GetFloat deltaTime, bool inPause, Notify callback)
		{
			Notify tmpCallback = this.callback;
			this.Clear();

			this.path = path;
			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.moveSettings = moveSettings;
			this.gravityType = gravityType;
			this.startSettings = startSettings;
			this.maxValue = this.path.Length / speed;
			this.pointTimeout = pointTimeout;

			this.rotationSettings = rotationSettings;
			this.lookAtObject = lookAtObject;
			this.rotation = rotation;
			this.smoothRotation = smoothRotation;

			this.callback = callback;

			this.startSettings = startSettings;
			this.startSettings.GetStartPoint(this.path, this.transform.position,
				ref this.startPointIndex, ref this.startPathValue);
			this.pointIndex = this.startPointIndex;

			this.reverse = this.startSettings.reverseDirection;

			this.StartFollow();

			if(tmpCallback != null)
			{
				tmpCallback();
			}
		}

		protected virtual void StartFollow()
		{
			if(this.path.GetPointTimes(this.pointIndex, this.maxValue,
				ref this.pointStart, ref this.pointEnd))
			{
				this.value = this.pointStart + (this.pointEnd - this.pointStart) * this.startPathValue;

				if(this.moveSettings.IsRigidbody())
				{
					this.useFixedUpdate = true;
				}
				else
				{
					this.useUpdate = true;
				}
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(this.useUpdate && !this.pause &&
				(this.inPause || !Maki.Game.Paused))
			{
				this.DoFollowPath(ref this.useUpdate);
			}
		}

		protected virtual void FixedUpdate()
		{
			if(this.useFixedUpdate && !this.pause &&
				(this.inPause || !Maki.Game.Paused))
			{
				this.DoFollowPath(ref this.useFixedUpdate);
			}
		}

		protected virtual void DoFollowPath(ref bool follow)
		{
			float delta = this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();

			if(this.timeout > 0)
			{
				this.timeout -= delta;
				if(this.timeout > 0)
				{
					return;
				}
			}

			if(this.reverse)
			{
				this.value -= delta;

				while(this.value < this.pointStart)
				{
					this.pointIndex--;
					this.timeout = this.pointTimeout;
					if(!this.path.GetPointTimes(this.pointIndex, this.maxValue,
						ref this.pointStart, ref this.pointEnd))
					{
						this.PathEnd(ref follow);
						break;
					}
				}
			}
			else
			{
				this.value += delta;

				while(this.value > this.pointEnd)
				{
					this.pointIndex++;
					this.timeout = this.pointTimeout;
					if(!this.path.GetPointTimes(this.pointIndex, this.maxValue,
						ref this.pointStart, ref this.pointEnd))
					{
						this.PathEnd(ref follow);
						break;
					}
				}
			}

			Vector3 position = this.path.GetPosition(ref this.pointIndex,
				(this.value - this.pointStart) / (this.pointEnd - this.pointStart),
				this.reverse);

			this.moveSettings.settings.DoLock(ref position, this.transform);

			// rotation
			if(this.rotationSettings != null)
			{
				this.DoRotation(this.rotationSettings, position,
					this.lookAtObject, this.rotation,
					this.smoothRotation, delta);
			}
			else if(this.path.pathPoint[this.pointIndex].ownRotation &&
				this.path.pathPoint[this.pointIndex].rotationSettings != null)
			{
				this.DoRotation(this.path.pathPoint[this.pointIndex].rotationSettings,
					position, this.path.pathPoint[this.pointIndex].lookAtObject,
					this.path.pathPoint[this.pointIndex].rotation,
					this.path.pathPoint[this.pointIndex].smoothRotation,
					delta);
			}
			else
			{
				this.DoRotation(this.path.rotationSettings, position,
					this.path.lookAtObject, this.path.rotation,
					this.path.smoothRotation, delta);
			}

			// move
			if(GravityType.Physics == this.gravityType)
			{
				position += Physics.gravity * delta;
			}
			else if(GravityType.Physics2D == this.gravityType)
			{
				position += (Vector3)(Physics2D.gravity * delta);
			}

			this.moveSettings.SetPosition(position);

			if((this.reverse && this.value <= 0) ||
				(!this.reverse && this.value >= this.maxValue))
			{
				this.PathEnd(ref follow);
			}
		}

		protected virtual void DoRotation(PathRotationSettings rotationSettings, Vector3 position,
			Transform lookAt, Vector3 rotation, float smooth, float delta)
		{
			if(PathRotationType.Value == rotationSettings.type)
			{
				if(smooth > 0)
				{
					this.transform.rotation = Quaternion.Slerp(this.transform.rotation,
						Quaternion.LookRotation(rotation), smooth * delta);
				}
				else
				{
					this.transform.rotation = Quaternion.LookRotation(rotation);
				}
			}
			else if(PathRotationType.MoveDirection == rotationSettings.type)
			{
				rotationSettings.LookAt(this.transform, position, smooth * delta);
			}
			else if(PathRotationType.LookAtObject == rotationSettings.type &&
				lookAt != null)
			{
				rotationSettings.LookAt(this.transform, lookAt.position, smooth * delta);
			}
		}

		protected virtual void PathEnd(ref bool follow)
		{
			if(PathEndType.Stop == this.startSettings.endType)
			{
				follow = false;
				this.value = this.pointEnd;
				this.pointIndex += this.reverse ? 1 : -1;
			}
			else if(PathEndType.Loop == this.startSettings.endType)
			{
				if(this.path.loopPath)
				{
					this.value = this.reverse ? this.maxValue : 0;

					if(this.pointIndex >= this.path.pathPoint.Length)
					{
						this.pointIndex = 0;
					}
					else if(this.pointIndex <= 0)
					{
						this.pointIndex = this.path.pathPoint.Length - 1;
					}

					this.path.GetPointTimes(this.pointIndex, this.maxValue,
						ref this.pointStart, ref this.pointEnd);
				}
				else
				{
					this.reverse = !this.reverse;
					this.value = this.reverse ? this.maxValue : 0;

					if(!this.path.loopPath)
					{
						this.pointIndex = this.reverse ? this.path.pathPoint.Length - 2 : 0;
					}

					this.path.GetPointTimes(this.pointIndex, this.maxValue,
						ref this.pointStart, ref this.pointEnd);
				}
			}
			else if(PathEndType.Reverse == this.startSettings.endType)
			{
				this.reverse = !this.reverse;
				this.value = this.reverse ? this.maxValue : 0;

				if(!this.path.loopPath)
				{
					this.pointIndex = this.reverse ? this.path.pathPoint.Length - 2 : 0;
				}

				this.path.GetPointTimes(this.pointIndex, this.maxValue,
					ref this.pointStart, ref this.pointEnd);
			}

			if(this.callback != null)
			{
				Notify tmpCallback = this.callback;
				this.callback = null;
				tmpCallback();
			}
		}
	}
}
