
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class RigidbodyMoverComponent : MonoBehaviour
	{
		protected Rigidbody actor;

		protected Rigidbody2D actor2D;

		protected GetFloat deltaTime;

		protected bool inPause = false;

		protected float time;

		protected float time2;

		protected Vector3 force;

		protected Vector3 forcePosition;

		protected Vector2 force2D;

		protected Vector2 forcePosition2D;

		protected float torque2D;

		protected ForceMode forceMode;

		protected ForceMode2D forceMode2D;


		// modes
		protected bool is2D = false;

		protected bool limitTime = false;

		protected bool addForce = false;

		protected bool addRelativeForce = false;

		protected bool addForceAtPosition = false;

		protected bool addTorque = false;

		public virtual void Stop()
		{
			this.actor = null;

			this.is2D = false;
			this.limitTime = false;
			this.addForce = false;
			this.addRelativeForce = false;
			this.addForceAtPosition = false;
			this.addTorque = false;
			this.deltaTime = null;
			this.inPause = false;

			this.time = 0;
			this.time2 = 0;
		}


		/*
		============================================================================
		3D functions
		============================================================================
		*/
		public virtual void AddForce(Rigidbody actor, Vector3 force, ForceMode forceMode,
			bool relative, float time, GetFloat deltaTime, bool inPause)
		{
			this.Stop();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.actor = actor;
			this.force = force;
			this.forceMode = forceMode;

			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}

			if(relative)
			{
				this.addRelativeForce = true;
			}
			else
			{
				this.addForce = true;
			}
			this.enabled = true;
		}

		public virtual void AddForceAtPosition(Rigidbody actor, Vector3 force, Vector3 forcePosition,
			ForceMode forceMode, float time, GetFloat deltaTime, bool inPause)
		{
			this.Stop();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.actor = actor;
			this.force = force;
			this.forcePosition = forcePosition;
			this.forceMode = forceMode;

			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}

			this.addForceAtPosition = true;
			this.enabled = true;
		}

		public virtual void AddTorque(Rigidbody actor, Vector3 force, ForceMode forceMode,
			float time, GetFloat deltaTime, bool inPause)
		{
			this.Stop();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.actor = actor;
			this.force = force;
			this.forceMode = forceMode;

			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}

			this.addTorque = true;
			this.enabled = true;
		}


		/*
		============================================================================
		2D functions
		============================================================================
		*/
		public virtual void AddForce2D(Rigidbody2D actor2D, Vector2 force2D, ForceMode2D forceMode2D,
			bool relative, float time, GetFloat deltaTime, bool inPause)
		{
			this.Stop();
			this.is2D = true;

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.actor2D = actor2D;
			this.force2D = force2D;
			this.forceMode2D = forceMode2D;

			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}

			if(relative)
			{
				this.addRelativeForce = true;
			}
			else
			{
				this.addForce = true;
			}
			this.enabled = true;
		}

		public virtual void AddForceAtPosition2D(Rigidbody2D actor2D, Vector3 force2D, ForceMode2D forceMode2D,
			Vector3 forcePosition2D, float time, GetFloat deltaTime, bool inPause)
		{
			this.Stop();
			this.is2D = true;

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.actor2D = actor2D;
			this.force2D = force2D;
			this.forcePosition2D = forcePosition2D;
			this.forceMode2D = forceMode2D;

			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}

			this.addForceAtPosition = true;
			this.enabled = true;
		}

		public virtual void AddTorque2D(Rigidbody2D actor2D, float torque, ForceMode2D forceMode2D,
			float time, GetFloat deltaTime, bool inPause)
		{
			this.Stop();
			this.is2D = true;

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.actor2D = actor2D;
			this.torque2D = torque;
			this.forceMode2D = forceMode2D;

			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}

			this.addTorque = true;
			this.enabled = true;
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void FixedUpdate()
		{
			if(this.inPause || !Maki.Game.Paused)
			{
				if(this.is2D && this.actor2D != null)
				{
					if(this.addForce)
					{
						this.actor2D.AddForce(this.force2D, this.forceMode2D);

						if(this.limitTime)
						{
							this.time += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
							if(this.time >= this.time2)
							{
								this.addForce = false;
								this.enabled = false;
							}
						}
					}
					else if(this.addRelativeForce)
					{
						this.actor2D.AddRelativeForce(this.force2D, this.forceMode2D);

						if(this.limitTime)
						{
							this.time += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
							if(this.time >= this.time2)
							{
								this.addRelativeForce = false;
								this.enabled = false;
							}
						}
					}
					else if(this.addForceAtPosition)
					{
						this.actor2D.AddForceAtPosition(this.force2D, this.forcePosition2D, this.forceMode2D);

						if(this.limitTime)
						{
							this.time += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
							if(this.time >= this.time2)
							{
								this.addForceAtPosition = false;
								this.enabled = false;
							}
						}
					}
					else if(this.addTorque)
					{
						this.actor2D.AddTorque(this.torque2D, this.forceMode2D);

						if(this.limitTime)
						{
							this.time += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
							if(this.time >= this.time2)
							{
								this.addTorque = false;
								this.enabled = false;
							}
						}
					}
				}
				else if(this.actor != null)
				{
					if(this.addForce)
					{
						this.actor.AddForce(this.force, this.forceMode);

						if(this.limitTime)
						{
							this.time += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
							if(this.time >= this.time2)
							{
								this.addForce = false;
								this.enabled = false;
							}
						}
					}
					else if(this.addRelativeForce)
					{
						this.actor.AddRelativeForce(this.force, this.forceMode);

						if(this.limitTime)
						{
							this.time += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
							if(this.time >= this.time2)
							{
								this.addRelativeForce = false;
								this.enabled = false;
							}
						}
					}
					else if(this.addForceAtPosition)
					{
						this.actor.AddForceAtPosition(this.force, this.forcePosition, this.forceMode);

						if(this.limitTime)
						{
							this.time += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
							if(this.time >= this.time2)
							{
								this.addForceAtPosition = false;
								this.enabled = false;
							}
						}
					}
					else if(this.addTorque)
					{
						this.actor.AddTorque(this.force, this.forceMode);

						if(this.limitTime)
						{
							this.time += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
							if(this.time >= this.time2)
							{
								this.addTorque = false;
								this.enabled = false;
							}
						}
					}
				}
			}
		}
	}
}
