
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.UI;
using UnityEngine;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class FlyingTextComponent : MonoBehaviour, IColorFadeable
	{
		protected FlyingText flyingText;

		public virtual Color Color
		{
			get
			{
				if(this.flyingText != null)
				{
					return this.flyingText.Color;
				}
				else
				{
					return Color.white;
				}
			}
			set
			{
				if(this.flyingText != null)
				{
					this.flyingText.Color = value;
				}
			}
		}

		public virtual Color TintColor
		{
			get
			{
				if(this.flyingText != null)
				{
					return this.flyingText.TintColor;
				}
				else
				{
					return Color.white;
				}
			}
			set
			{
				if(this.flyingText != null)
				{
					this.flyingText.TintColor = value;
				}
			}
		}

		public virtual FlyingText FlyingText
		{
			get { return this.flyingText; }
			set { this.flyingText = value; }
		}

		protected virtual void OnDestroy()
		{
			if(this.flyingText != null)
			{
				this.flyingText.Remove();
			}
		}
	}
}
