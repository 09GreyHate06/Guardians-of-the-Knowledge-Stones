
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Object Variables")]
	public class ObjectVariablesComponent : SerializedBehaviour<ObjectVariableSetting>
	{
		// ingame
		protected VariableHandler handler;

		protected SelectedDataHandler selectedData;

		protected virtual void Reset()
		{
			this.settings.objectID = System.Guid.NewGuid().ToString();
		}

		protected virtual void OnEnable()
		{
			if(this.settings.alwaysInitialize || !this.HandlerExists())
			{
				this.settings.initialVariables.SetVariables(
					this.Handler, new DataCall(this.gameObject));
			}
		}

		protected virtual void OnDestroy()
		{
			// stop local timers
			if((this.settings.objectID == "" || this.settings.isLocal) &&
				this.handler != null)
			{
				this.handler.StopAllTimers();
			}
		}

		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/ObjectVariablesComponent Icon.png");
		}

		public virtual bool HandlerExists()
		{
			if(this.settings.objectID == "" || this.settings.isLocal)
			{
				return this.handler != null;
			}
			else
			{
				return Maki.Game.ObjectVariablesExist(this.settings.objectID);
			}
		}

		public virtual VariableHandler Handler
		{
			get
			{
				if(this.settings.objectID == "" || this.settings.isLocal)
				{
					if(this.handler == null)
					{
						this.handler = new VariableHandler();
					}
					return this.handler;
				}
				else
				{
					return Maki.Game.GetObjectVariables(this.settings.objectID);
				}
			}
			set
			{
				this.handler = value;
			}
		}

		public static VariableHandler Get(GameObject gameObject)
		{
			if(gameObject != null)
			{
				ObjectVariablesComponent comp = gameObject.GetComponent<ObjectVariablesComponent>();
				if(comp != null)
				{
					return comp.Handler;
				}
			}
			return null;
		}

		public static VariableHandler GetInChildren(GameObject gameObject)
		{
			if(gameObject != null)
			{
				ObjectVariablesComponent comp = gameObject.GetComponentInChildren<ObjectVariablesComponent>();
				if(comp != null)
				{
					return comp.Handler;
				}
			}
			return null;
		}


		/*
		============================================================================
		Selected data functions
		============================================================================
		*/
		public virtual SelectedDataHandler SelectedData
		{
			get
			{
				if(this.settings.objectID == "" || this.settings.isLocal)
				{
					if(this.selectedData == null)
					{
						this.selectedData = new SelectedDataHandler();
					}
					return this.selectedData;
				}
				else
				{
					return Maki.Game.GetObjectSelectedData(this.settings.objectID);
				}
			}
			set
			{
				this.selectedData = value;
			}
		}

		public static SelectedDataHandler GetSelectedData(GameObject gameObject)
		{
			if(gameObject != null)
			{
				ObjectVariablesComponent comp = gameObject.GetComponent<ObjectVariablesComponent>();
				if(comp != null)
				{
					return comp.SelectedData;
				}
			}
			return null;
		}

		public static SelectedDataHandler GetSelectedDataInChildren(GameObject gameObject)
		{
			if(gameObject != null)
			{
				ObjectVariablesComponent comp = gameObject.GetComponentInChildren<ObjectVariablesComponent>();
				if(comp != null)
				{
					return comp.SelectedData;
				}
			}
			return null;
		}
	}
}
