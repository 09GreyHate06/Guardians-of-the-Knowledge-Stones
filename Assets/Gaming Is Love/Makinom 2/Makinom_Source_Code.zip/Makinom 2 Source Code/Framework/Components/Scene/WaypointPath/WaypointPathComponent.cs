
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Waypoint Path")]
	public class WaypointPathComponent : MonoBehaviour
	{
		// editor
		public Color pathColor = Color.red;

		public float pathWidth = 3;


		// loop
		public bool loopPath = false;


		// rotation
		public PathRotationSettings rotationSettings = new PathRotationSettings();

		public Transform lookAtObject;

		public Vector3 rotation = Vector3.zero;

		public float smoothRotation = 0;


		// path points
		public PathPoint[] pathPoint = new PathPoint[0];


		// in-game
		private float length = 0;

		protected virtual void Awake()
		{
			this.UpdatePath();
		}


		/*
		============================================================================
		Position functions
		============================================================================
		*/
		public Vector3 GetPosition(ref int pointIndex, float pathValue, bool reverse)
		{
			Vector3 position = Vector3.zero;

			if(this.pathPoint.Length > 0)
			{
				if(reverse)
				{
					if(pointIndex < 0 ||
						pointIndex >= this.pathPoint.Length)
					{
						pointIndex = this.pathPoint.Length - 1;
					}
				}
				else
				{
					if(pointIndex < 0 ||
						pointIndex >= this.pathPoint.Length)
					{
						pointIndex = 0;
					}
				}

				if(pointIndex < this.pathPoint.Length - 1)
				{
					position = this.pathPoint[pointIndex].GetPosition(
						pathValue, this.pathPoint[pointIndex + 1]);
				}
				else if(this.loopPath)
				{
					position = this.pathPoint[pointIndex].GetPosition(
						pathValue, this.pathPoint[0]);
				}
				else
				{
					position = this.pathPoint[pointIndex].position;
				}
			}

			return this.transform.TransformPoint(position);
		}

		public void FindNearestPosition(Vector3 userPosition, ref int pointIndex,
			ref float pathValue, ref Vector3 nearestPosition)
		{
			userPosition = this.transform.InverseTransformPoint(userPosition);

			float shortestDistance = Mathf.Infinity;

			for(int i = 0; i < this.pathPoint.Length; i++)
			{
				if(this.pathPoint[i].FindNearestPosition(userPosition,
					ref pathValue, ref nearestPosition, ref shortestDistance))
				{
					pointIndex = i;
				}
			}

			nearestPosition = this.transform.TransformPoint(nearestPosition);
		}

		public Vector3 FindNearestPosition(Vector3 userPosition)
		{
			userPosition = this.transform.InverseTransformPoint(userPosition);

			Vector3 nearestPosition = Vector3.zero;
			int pointIndex = 0;
			float pathValue = 0;
			float shortestDistance = Mathf.Infinity;

			for(int i = 0; i < this.pathPoint.Length; i++)
			{
				if(this.pathPoint[i].FindNearestPosition(userPosition,
					ref pathValue, ref nearestPosition, ref shortestDistance))
				{
					pointIndex = i;
				}
			}

			return this.transform.TransformPoint(nearestPosition);
		}


		/*
		============================================================================
		Length functions
		============================================================================
		*/
		public float Length
		{
			get { return this.length; }
		}

		public void UpdatePath()
		{
			this.length = 0;
			for(int i = 0; i < this.pathPoint.Length; i++)
			{
				if(i < this.pathPoint.Length - 1)
				{
					this.pathPoint[i].UpdateLength(this.pathPoint[i + 1]);
				}
				else if(this.loopPath && this.pathPoint.Length > 1)
				{
					this.pathPoint[i].UpdateLength(this.pathPoint[0]);
				}
				this.length += this.pathPoint[i].Length;
			}
		}


		/*
		============================================================================
		Path value functions
		============================================================================
		*/
		public bool GetPointTimes(int pointIndex, float time, ref float start, ref float end)
		{
			if(this.length > 0)
			{
				time /= this.length;
				float value = 0;

				for(int i = 0; i < this.pathPoint.Length; i++)
				{
					if(pointIndex == i)
					{
						start = value;
						end = value + this.pathPoint[i].Length * time;
						return true;
					}
					else
					{
						value += this.pathPoint[i].Length * time;
					}
				}
			}

			return false;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "/GamingIsLove/Makinom/Components/WaypointPathComponent Icon.png");
		}
	}
}
