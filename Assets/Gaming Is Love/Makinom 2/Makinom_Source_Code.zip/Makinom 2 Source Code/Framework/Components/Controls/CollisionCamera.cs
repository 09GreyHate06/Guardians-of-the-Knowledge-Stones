
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	// TODO: fade between original and collision position (and back)
	[AddComponentMenu("Makinom/Controls/Collision Camera")]
	public class CollisionCamera : SerializedBehaviour<CollisionCamera.Settings>
	{
		// ingame
		protected Vector3 originalPosition = Vector3.zero;

		protected Camera cameraComponent;

		protected bool setOriginalPosition = false;


		/*
		============================================================================
		Position functions
		============================================================================
		*/
		protected virtual void Start()
		{
			this.cameraComponent = this.GetComponent<Camera>();
			if(this.cameraComponent == null)
			{
				GameObject.Destroy(this);
			}
			else
			{
				this.originalPosition = this.transform.position;
			}
		}

		protected virtual void Update()
		{
			if(this.setOriginalPosition)
			{
				this.transform.position = this.originalPosition;
				this.setOriginalPosition = false;
			}
		}

		protected virtual void LateUpdate()
		{
			if(!this.settings.blockWithCameraControl ||
				!Maki.Control.CameraBlocked)
			{
				GameObject player = Maki.Game.Player.GameObject;
				if(player != null)
				{
					this.originalPosition = this.transform.position;
					this.setOriginalPosition = true;

					Vector3 tmpPos = this.transform.position;
					if(this.CheckView(this.settings.childObject.GetChild(player.transform), ref tmpPos))
					{
						this.transform.position = Vector3.MoveTowards(tmpPos, player.transform.position, this.settings.moveTowards);
					}
				}
			}
			else if(this.setOriginalPosition)
			{
				this.setOriginalPosition = false;
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		protected virtual bool CheckView(Transform player, ref Vector3 position)
		{
			float distance = Mathf.Infinity;

			if(player != null)
			{
				RaycastHit hit;
				Vector3 direction = (player.position - this.transform.position).normalized;
				Vector3 up = Vector3.Cross(direction, this.transform.right).normalized;

				float height = this.cameraComponent.nearClipPlane *
					Mathf.Tan(this.cameraComponent.fieldOfView * this.settings.viewSize * Mathf.Deg2Rad);
				float width = height * this.cameraComponent.aspect;

				// center
				if(Physics.Linecast(player.position, this.transform.position, out hit, this.settings.layerMask))
				{
					if(hit.transform.root != player.root)
					{
						distance = hit.distance;
						position = hit.point;
					}
				}

				if(CollisionCameraType.Horizontal == this.settings.type ||
					CollisionCameraType.Cross == this.settings.type)
				{
					Vector3 leftPos = (-this.transform.right * width) + (direction * this.cameraComponent.nearClipPlane);
					Vector3 rightPos = (this.transform.right * width) + (direction * this.cameraComponent.nearClipPlane);

					// left
					if(Physics.Linecast(player.position, this.transform.position + leftPos, out hit, this.settings.layerMask))
					{
						if(hit.transform.root != player.root &&
							(hit.distance < distance || distance == Mathf.Infinity))
						{
							distance = Vector3.Distance(player.position, hit.point - leftPos);
							position = hit.point;
						}
					}
					// right
					if(Physics.Linecast(player.position, this.transform.position + rightPos, out hit, this.settings.layerMask))
					{
						if(hit.transform.root != player.root &&
							(hit.distance < distance || distance == Mathf.Infinity))
						{
							distance = Vector3.Distance(player.position, hit.point - rightPos);
							position = hit.point;
						}
					}
				}

				if(CollisionCameraType.Vertical == this.settings.type ||
					CollisionCameraType.Cross == this.settings.type)
				{
					Vector3 downPos = (-up * height) + (direction * this.cameraComponent.nearClipPlane);
					Vector3 upPos = (up * height) + (direction * this.cameraComponent.nearClipPlane);

					// left
					if(Physics.Linecast(player.position, this.transform.position + downPos, out hit, this.settings.layerMask))
					{
						if(hit.transform.root != player.root &&
							(hit.distance < distance || distance == Mathf.Infinity))
						{
							distance = Vector3.Distance(player.position, hit.point - downPos);
							position = hit.point;
						}
					}
					// right
					if(Physics.Linecast(player.position, this.transform.position + upPos, out hit, this.settings.layerMask))
					{
						if(hit.transform.root != player.root &&
							(hit.distance < distance || distance == Mathf.Infinity))
						{
							distance = Vector3.Distance(player.position, hit.point - upPos);
							position = hit.point;
						}
					}
				}
			}

			return distance < Mathf.Infinity;
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Block With Camera", "The collision camera will be blocked when the camera control is blocked.")]
			public bool blockWithCameraControl = true;

			// camera settings
			[EditorHelp("Check Type", "Select the collision camera check type:\n" +
				"- Center: Only the center of the screen will be checked.\n" +
				"- Horizontal: Checks center, left and right.\n" +
				"- Vertical: Checks center, up and down.\n" +
				"- Cross: Checks center, left, right, up and down.", "")]
			public CollisionCameraType type = CollisionCameraType.Center;

			[EditorHelp("Layer Mask", "Select the layers that will be checked.", "")]
			public LayerMask layerMask = -1;

			[EditorHelp("Move Towards", "Define the distance the camera will move towards the player from the collision point.\n" +
				"You can use negative values to move away from the player.\n" +
				"Use this setting to avoid clipping near walls.", "")]
			public float moveTowards = 0;

			// how much of the FoV will be used: 0-1
			[EditorHelp("View Size", "Define how much of the camera's view will be used " +
				"when checking left/right and up/down positions", "")]
			[EditorCondition("type", CollisionCameraType.Center)]
			[EditorElseCondition]
			[EditorEndCondition]
			[EditorLimit(0.0f, 1.0f, isSlider=true)]
			public float viewSize = 0.5f;


			// player settings
			[EditorHelp("Player Child Name", "You can use a child object of the player when checking for collisions.", "")]
			public ChildObjectSettings childObject = new ChildObjectSettings();

			public Settings()
			{

			}

			public override void SetData(DataObject data)
			{
				base.SetData(data);
				this.childObject.Upgrade(data, "childName");
			}
		}
	}
}
