﻿
using UnityEngine;
using UnityEngine.Audio;
using System.Collections;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MusicChannel : AudioChannel
	{
		// objects
		protected GameObject gameObject;

		protected MusicAudioSource sourceA;

		protected MusicAudioSource sourceB;


		// target volume
		protected Interpolation.FloatInstance fadeTargetVolume;


		// 0 = none, 1 = sourceA, 2 = sourceB, 3 = A to B, 4 = B to A
		protected int currentPlaying = 0;

		protected bool ticking = false;


		// clips
		protected MusicClip currentMusic;

		protected MusicClip lastMusic;

		protected Coroutine delayedPlay;


		// stored clips
		protected Dictionary<int, MusicClipStored> stored = new Dictionary<int, MusicClipStored>();

		public MusicChannel(GameObject parent, int channel)
		{
			this.gameObject = new GameObject("Music Channel " + channel);
			this.gameObject.transform.SetParent(parent.transform);

			this.sourceA = new MusicAudioSource(this.AddAudioSource(this.gameObject), this.AddAudioSource(this.gameObject));
			this.sourceB = new MusicAudioSource(this.AddAudioSource(this.gameObject), this.AddAudioSource(this.gameObject));
		}

		public virtual MusicAudioSource SourceA
		{
			get { return this.sourceA; }
		}

		public virtual MusicAudioSource SourceB
		{
			get { return this.sourceB; }
		}

		public override void SetOutput(AudioMixerGroup audioMixerGroup)
		{
			if(this.sourceA != null)
			{
				this.sourceA.outputAudioMixerGroup = audioMixerGroup;
			}
			if(this.sourceB != null)
			{
				this.sourceB.outputAudioMixerGroup = audioMixerGroup;
			}
		}


		/*
		============================================================================
		Volume functions
		============================================================================
		*/
		public override void UpdateVolume()
		{
			float baseVol = this.currentMusic != null ? this.currentMusic.Volume : 1;
			if(this.sourceA.IsInitialized)
			{
				this.sourceA.volume = baseVol * this.Volume * Maki.Audio.MusicVolume;
			}
			if(this.sourceB.IsInitialized)
			{
				this.sourceB.volume = baseVol * this.Volume * Maki.Audio.MusicVolume;
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual bool IsPlaying()
		{
			return this.currentPlaying > 0;
		}

		public virtual bool IsPlaying(MusicClipSetting musicClip)
		{
			return this.currentPlaying > 0 &&
				this.currentMusic != null &&
				this.currentMusic.Settings == musicClip;
		}

		public virtual string GetCurrentGUID()
		{
			string guid = "";
			if(this.currentMusic != null)
			{
				guid = this.currentMusic.Settings.GUID;
			}
			return guid;
		}

		public virtual float GetCurrentTime()
		{
			float time = -1;
			if(this.sourceA.IsInitialized &&
				(this.currentPlaying == 1 ||
					this.currentPlaying == 4))
			{
				time = this.sourceA.time;
			}
			else if(this.sourceB.IsInitialized &&
				(this.currentPlaying == 2 ||
					this.currentPlaying == 3))
			{
				time = this.sourceB.time;
			}
			return time;
		}

		public virtual float GetCurrentTargetVolume()
		{
			float targetVolume = 1;
			if(this.currentMusic != null)
			{
				targetVolume = this.currentMusic.TargetVolume;
			}
			return targetVolume;
		}

		public virtual int GetCurrentLoop()
		{
			if(this.currentMusic != null)
			{
				return this.currentMusic.CurrentLoop;
			}
			return 0;
		}


		/*
		============================================================================
		Store functions
		============================================================================
		*/
		public virtual void AutoStoreTimePosition()
		{
			if(this.currentMusic != null &&
				this.currentMusic.Settings != null &&
				this.currentMusic.Settings.storeTimePosition)
			{
				float time = 0;
				if(this.currentPlaying == 1 || this.currentPlaying == 4)
				{
					time = this.sourceA.time;
				}
				else if(this.currentPlaying == 2 || this.currentPlaying == 3)
				{
					time = this.sourceB.time;
				}

				Maki.Audio.StoreMusicTrackPosition(this.currentMusic.Settings.GUID, time, this.currentMusic.CurrentLoop);
			}
		}

		public virtual void StoreTimePosition()
		{
			if(this.currentMusic != null &&
				this.currentMusic.Settings != null)
			{
				float time = 0;
				if(this.currentPlaying == 1 || this.currentPlaying == 4)
				{
					time = this.sourceA.time;
				}
				else if(this.currentPlaying == 2 || this.currentPlaying == 3)
				{
					time = this.sourceB.time;
				}

				Maki.Audio.StoreMusicTrackPosition(this.currentMusic.Settings.GUID, time, this.currentMusic.CurrentLoop);
			}
		}

		public virtual void StoreCurrent(int id)
		{
			MusicClipStored clip = null;
			if(this.currentMusic != null)
			{
				float time = 0;
				if(this.currentPlaying == 1 || this.currentPlaying == 4)
				{
					clip = new MusicClipStored(this.currentMusic, this.sourceA.time);
					time = this.sourceA.time;
				}
				else if(this.currentPlaying == 2 || this.currentPlaying == 3)
				{
					clip = new MusicClipStored(this.currentMusic, this.sourceB.time);
					time = this.sourceB.time;
				}
				else
				{
					clip = new MusicClipStored(null, 0);
				}

				if(this.currentMusic.Settings != null)
				{
					Maki.Audio.StoreMusicTrackPosition(this.currentMusic.Settings.GUID, time, this.currentMusic.CurrentLoop);
				}
			}

			this.stored[id] = clip;
		}

		public virtual void PlayStored(int id)
		{
			MusicClipStored clip;
			if(this.stored.TryGetValue(id, out clip) &&
				clip != null)
			{
				clip.Play(this);
			}
			else
			{
				this.Stop();
			}
		}

		public virtual void FadeInStored(int id, float time, Interpolation interpolation)
		{
			MusicClipStored clip;
			if(this.stored.TryGetValue(id, out clip) &&
				clip != null)
			{
				clip.FadeIn(this, time, interpolation);
			}
			else
			{
				this.Stop();
			}
		}

		public virtual void FadeToStored(int id, float time, Interpolation interpolation)
		{
			MusicClipStored clip;
			if(this.stored.TryGetValue(id, out clip) &&
				clip != null)
			{
				clip.FadeTo(this, time, interpolation);
			}
			else
			{
				this.FadeOut(time, interpolation);
			}
		}

		public virtual void FadeOutPlayStored(int id, float time, Interpolation interpolation)
		{
			MusicClipStored clip;
			if(this.stored.TryGetValue(id, out clip) &&
				clip != null)
			{
				clip.FadeOutPlay(this, time, interpolation);
			}
			else
			{
				this.FadeOut(time, interpolation);
			}
		}


		/*
		============================================================================
		Play functions
		============================================================================
		*/
		public virtual bool CheckPlay(MusicClip clip)
		{
			if(clip == null ||
				(this.currentMusic != null &&
					clip.Settings == this.currentMusic.Settings &&
					this.currentPlaying > 0 && !this.currentMusic.FadeOut))
			{
				return false;
			}
			return true;
		}

		public override void SetPCM(int pcm)
		{
			if(pcm < 0)
			{
				pcm = 0;
			}
			if(this.currentPlaying == 1 || this.currentPlaying == 4)
			{
				this.sourceA.timeSamples = pcm;
			}
			else if(this.currentPlaying == 2 || this.currentPlaying == 3)
			{
				this.sourceB.timeSamples = pcm;
			}
		}

		public override void SetTime(float time)
		{
			if(time < 0)
			{
				time = 0;
			}
			if(this.currentPlaying == 1 || this.currentPlaying == 4)
			{
				this.sourceA.time = time;
				this.sourceA.ScheduleLoop(this.currentMusic);
			}
			else if(this.currentPlaying == 2 || this.currentPlaying == 3)
			{
				this.sourceB.time = time;
				this.sourceB.ScheduleLoop(this.currentMusic);
			}
		}

		public virtual void Play(MusicClipSetting musicClip, float targetVolume, MusicPlayFromType playFromType)
		{
			MusicClip clip = new MusicClip(musicClip, targetVolume);
			float currentTime = -1;
			if(MusicPlayFromType.CurrentChannelTime == playFromType)
			{
				currentTime = this.GetCurrentTime();
			}
			else if(MusicPlayFromType.StoredTimePosition == playFromType &&
				musicClip != null)
			{
				MusicTimePosition trackPosition = Maki.Audio.GetMusicTrackPosition(musicClip.GUID);
				if(trackPosition != null)
				{
					clip.CurrentLoop = trackPosition.currentLoop;
					currentTime = trackPosition.time;
				}
			}

			this.Play(clip);
			if(currentTime >= 0)
			{
				this.SetTime(currentTime);
			}
		}

		public virtual void PlayFromTime(string guid, float targetVolume, float time)
		{
			this.Play(new MusicClip(guid, targetVolume));
			this.SetTime(time);
		}

		public virtual void PlayFromTime(MusicClip clip, float time)
		{
			this.Play(clip);
			this.SetTime(time);
		}

		public virtual void Play(MusicClip clip)
		{
			if(this.CheckPlay(clip))
			{
				this.AutoStoreTimePosition();
				this.sourceA.Stop();
				this.sourceB.Stop();
				this.lastMusic = this.currentMusic;
				this.currentMusic = clip;
				this.sourceA.volume = this.currentMusic.Volume * this.Volume * Maki.Audio.MusicVolume;
				this.sourceA.Play(this.currentMusic);
				this.currentPlaying = 1;
				if(this.currentMusic.HasLoops())
				{
					this.ticking = true;
					this.DoTick();
				}
			}
			else if(clip != null &&
				this.IsPlaying(clip.Settings))
			{
				this.currentMusic.TargetVolume = clip.TargetVolume;
				this.UpdateVolume();
			}
		}

		public override void Stop()
		{
			this.sourceA.Stop();
			this.sourceB.Stop();
			this.currentPlaying = 0;
			this.ticking = false;
		}


		/*
		============================================================================
		Fade functions
		============================================================================
		*/
		public virtual void FadeIn(MusicClipSetting musicClip, float targetVolume, MusicPlayFromType playFromType, float fadeTime, Interpolation interpolation)
		{
			MusicClip clip = new MusicClip(musicClip, targetVolume);
			float currentTime = -1;

			if(MusicPlayFromType.CurrentChannelTime == playFromType)
			{
				currentTime = this.GetCurrentTime();
			}
			else if(MusicPlayFromType.StoredTimePosition == playFromType &&
				musicClip != null)
			{
				MusicTimePosition trackPosition = Maki.Audio.GetMusicTrackPosition(musicClip.GUID);
				if(trackPosition != null)
				{
					clip.CurrentLoop = trackPosition.currentLoop;
					currentTime = trackPosition.time;
				}
			}

			this.FadeIn(clip, fadeTime, interpolation);
			if(currentTime >= 0)
			{
				this.SetTime(currentTime);
			}
		}

		public virtual void FadeIn(MusicClip clip, float fadeTime, Interpolation interpolation)
		{
			this.StopDelayedPlay();

			if(this.CheckPlay(clip))
			{
				this.AutoStoreTimePosition();
				this.sourceA.Stop();
				this.sourceB.Stop();
				this.lastMusic = this.currentMusic;
				this.currentMusic = clip;
				this.sourceA.volume = 0;
				this.currentMusic.DoFadeIn(fadeTime, interpolation);
				this.sourceA.Play(this.currentMusic);
				this.currentPlaying = 1;
				if(this.currentMusic.HasLoops())
				{
					this.ticking = true;
					this.DoTick();
				}
			}
			else if(clip != null &&
				this.IsPlaying(clip.Settings))
			{
				this.fadeTargetVolume = interpolation.CreateFloat(
					this.currentMusic.TargetVolume, clip.TargetVolume, fadeTime);
			}
		}

		public virtual void FadeOut(float fadeTime, Interpolation interpolation)
		{
			this.StopDelayedPlay();

			if(this.currentMusic != null)
			{
				this.currentMusic.DoFadeOut(fadeTime, interpolation);
			}
		}

		public virtual void FadeTo(MusicClipSetting musicClip, float targetVolume, MusicPlayFromType playFromType, float fadeTime, Interpolation interpolation)
		{
			MusicClip clip = new MusicClip(musicClip, targetVolume);
			float currentTime = -1;

			if(MusicPlayFromType.CurrentChannelTime == playFromType)
			{
				currentTime = this.GetCurrentTime();
			}
			else if(MusicPlayFromType.StoredTimePosition == playFromType &&
				musicClip != null)
			{
				MusicTimePosition trackPosition = Maki.Audio.GetMusicTrackPosition(musicClip.GUID);
				if(trackPosition != null)
				{
					clip.CurrentLoop = trackPosition.currentLoop;
					currentTime = trackPosition.time;
				}
			}

			this.FadeTo(clip, fadeTime, interpolation);
			if(currentTime >= 0)
			{
				this.SetTime(currentTime);
			}
		}

		public virtual void FadeTo(MusicClip clip, float fadeTime, Interpolation interpolation)
		{
			this.StopDelayedPlay();

			if(this.currentPlaying == 0)
			{
				this.FadeIn(clip, fadeTime, interpolation);
			}
			else if(this.CheckPlay(clip))
			{
				this.AutoStoreTimePosition();
				if(this.currentPlaying == 3)
				{
					this.sourceA.Stop();
					this.currentPlaying = 2;
				}
				else if(this.currentPlaying == 4)
				{
					this.sourceB.Stop();
					this.currentPlaying = 1;
				}

				this.lastMusic = this.currentMusic;
				this.currentMusic = clip;

				this.lastMusic.DoFadeOut(fadeTime, interpolation);
				this.currentMusic.DoFadeIn(fadeTime, interpolation);

				if(this.currentPlaying == 1)
				{
					this.sourceB.volume = 0;
					this.sourceB.Play(this.currentMusic);
					this.currentPlaying = 3;
				}
				else if(this.currentPlaying == 2)
				{
					this.sourceA.volume = 0;
					this.sourceA.Play(this.currentMusic);
					this.currentPlaying = 4;
				}
				if(this.currentMusic.HasLoops())
				{
					this.ticking = true;
					this.DoTick();
				}
			}
			else if(clip != null &&
				this.IsPlaying(clip.Settings))
			{
				this.fadeTargetVolume = interpolation.CreateFloat(
					this.currentMusic.TargetVolume, clip.TargetVolume, fadeTime);
			}
		}

		public virtual void FadeOutPlay(MusicClipSetting musicClip, float targetVolume, MusicPlayFromType playFromType, float fadeTime, Interpolation interpolation)
		{
			MusicClip clip = new MusicClip(musicClip, targetVolume);
			float currentTime = 0;

			if(MusicPlayFromType.CurrentChannelTime == playFromType)
			{
				currentTime = this.GetCurrentTime();
			}
			else if(MusicPlayFromType.StoredTimePosition == playFromType &&
				musicClip != null)
			{
				MusicTimePosition trackPosition = Maki.Audio.GetMusicTrackPosition(musicClip.GUID);
				if(trackPosition != null)
				{
					clip.CurrentLoop = trackPosition.currentLoop;
					currentTime = trackPosition.time;
				}
			}

			this.FadeOutPlay(clip, fadeTime, interpolation, currentTime);
		}

		public virtual void FadeOutPlay(MusicClip clip, float fadeTime, Interpolation interpolation, float playFromTime)
		{
			this.StopDelayedPlay();

			if(this.currentPlaying == 0)
			{
				this.Play(clip);
			}
			else if(this.CheckPlay(clip))
			{
				this.AutoStoreTimePosition();
				if(this.currentPlaying == 1)
				{
					this.currentPlaying = 3;
				}
				else if(this.currentPlaying == 2)
				{
					this.currentPlaying = 4;
				}

				this.lastMusic = this.currentMusic;
				this.currentMusic = clip;

				this.lastMusic.DoFadeOut(fadeTime, interpolation);
				this.delayedPlay = Maki.StartCoroutine(this.PlayDelayed(fadeTime, playFromTime));
			}
			else if(clip != null &&
				this.IsPlaying(clip.Settings))
			{
				this.fadeTargetVolume = interpolation.CreateFloat(
					this.currentMusic.TargetVolume, clip.TargetVolume, fadeTime);
			}
		}

		protected virtual IEnumerator PlayDelayed(float delayTime, float playFromTime)
		{
			yield return new WaitForSeconds(delayTime);

			this.sourceA.volume = this.currentMusic.Volume * this.Volume * Maki.Audio.MusicVolume;
			this.sourceA.Play(this.currentMusic);
			this.currentPlaying = 1;
			if(this.currentMusic.HasLoops())
			{
				this.ticking = true;
				this.DoTick();
			}
			if(playFromTime >= 0)
			{
				this.SetTime(playFromTime);
			}
			this.delayedPlay = null;
		}

		protected virtual void StopDelayedPlay()
		{
			if(this.delayedPlay != null)
			{
				Maki.StopCoroutine(this.delayedPlay);
				this.delayedPlay = null;
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public virtual void DoTick()
		{
			Maki.StartCoroutine(this.DoTick2());
		}

		protected virtual IEnumerator DoTick2()
		{
			while(this.ticking && this.currentPlaying > 0)
			{
				yield return new WaitForSeconds(0.05f);
				if(this.currentMusic.HasLoops())
				{
					if(this.currentPlaying == 1)
					{
						this.sourceA.CheckNextLoop(this.currentMusic);
					}
					else if(this.currentPlaying == 2)
					{
						this.sourceB.CheckNextLoop(this.currentMusic);
					}
					else if(this.currentPlaying == 3)
					{
						this.sourceA.CheckNextLoop(this.lastMusic);
						this.sourceB.CheckNextLoop(this.currentMusic);
					}
					else if(this.currentPlaying == 4)
					{
						this.sourceB.CheckNextLoop(this.lastMusic);
						this.sourceA.CheckNextLoop(this.currentMusic);
					}
				}
			}
		}

		public override void Tick()
		{
			base.Tick();

			// target volume fading
			if(this.fadeTargetVolume != null)
			{
				if(this.currentMusic != null)
				{
					float tmpVolume = this.currentMusic.TargetVolume;
					tmpVolume = this.fadeTargetVolume.Tick(Time.unscaledDeltaTime);
					this.currentMusic.TargetVolume = tmpVolume;
					this.UpdateVolume();

					if(this.fadeTargetVolume.Finished)
					{
						this.fadeTargetVolume = null;
					}
				}
				else
				{
					this.fadeTargetVolume = null;
				}
			}

			if(this.currentPlaying == 1)
			{
				if(this.currentMusic != null)
				{
					this.currentMusic.DoFade(Time.unscaledDeltaTime, this.sourceA, this.Volume);
				}
			}
			else if(this.currentPlaying == 2)
			{
				if(this.currentMusic != null)
				{
					this.currentMusic.DoFade(Time.unscaledDeltaTime, this.sourceB, this.Volume);
				}
			}
			else if(this.currentPlaying == 3)
			{
				if(this.lastMusic != null)
				{
					this.lastMusic.DoFade(Time.unscaledDeltaTime, this.sourceA, this.Volume);
				}
				if(this.currentMusic != null)
				{
					this.currentMusic.DoFade(Time.unscaledDeltaTime, this.sourceB, this.Volume);
				}
			}
			else if(this.currentPlaying == 4)
			{
				if(this.lastMusic != null)
				{
					this.lastMusic.DoFade(Time.unscaledDeltaTime, this.sourceB, this.Volume);
				}
				if(this.currentMusic != null)
				{
					this.currentMusic.DoFade(Time.unscaledDeltaTime, this.sourceA, this.Volume);
				}
			}

			if(this.delayedPlay == null)
			{
				if(this.sourceA.isPlaying && !this.sourceB.isPlaying)
				{
					this.currentPlaying = 1;
				}
				else if(this.sourceB.isPlaying && !this.sourceA.isPlaying)
				{
					this.currentPlaying = 2;
				}
				else if(!this.sourceA.isPlaying && !this.sourceB.isPlaying)
				{
					this.currentPlaying = 0;
				}
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public override DataObject SaveGame()
		{
			DataObject data = base.SaveGame();

			if(this.IsPlaying() &&
				Maki.SaveGameSettings.savePlayerPosition &&
				Maki.SaveGameSettings.saveMusic)
			{
				data.Set("id", this.GetCurrentGUID());
				data.Set("time", this.GetCurrentTime());
				data.Set("currentLoop", this.GetCurrentLoop());
				data.Set("targetVolume", this.GetCurrentTargetVolume());
			}

			return data;
		}

		public override void LoadGame(DataObject data)
		{
			if(data != null)
			{
				base.LoadGame(data);

				string guid = "";
				data.Get("id", ref guid);
				if(guid != "")
				{
					float time = 0;
					data.Get("time", ref time);
					float targetVolume = 1;
					data.Get("targetVolume", ref targetVolume);
					int currentLoop = 0;
					data.Get("currentLoop", ref currentLoop);

					this.Stop();
					MusicClip clip = new MusicClip(guid, targetVolume);
					clip.CurrentLoop = currentLoop;
					this.PlayFromTime(clip, time);
				}
			}
		}
	}
}
