
using UnityEngine;

namespace GamingIsLove.Makinom
{
	public class MusicClipLoop : BaseData, IFoldoutInfo
	{
		[EditorHelp("End Loop", "Loops back to the start when reaching the end of the clip.\n" +
			"Use this to loop the clip when also using loops within it - " +
			"otherwise the loop will restart with the first loop setup when finishing the last one.\n" +
			"Disable 'Loop Clip' when using this option.", "")]
		public bool endLoop = false;

		[EditorHelp("Keep Looping", "This loop will keep looping, " +
			"i.e. it'll not move on to the next loop (or back to the first loop if this is the last loop.", "")]
		public bool keepLooping = false;

		[EditorHelp("Use PCM", "Use PCM instead of time to check and set the loop position.", "")]
		[EditorCondition("endLoop", false)]
		public bool usePCM = false;


		// pcm
		[EditorHelp("Check PCM", "The playback position in PCM samples to check for.", "")]
		[EditorLimit(0, false)]
		[EditorCondition("usePCM", true)]
		public int checkPCM = 0;

		[EditorHelp("Set PCM", "The playback position in PCM samples to set upon reaching the check value.", "")]
		[EditorLimit(0, false)]
		[EditorCallback("button:testloop", EditorCallbackType.InstanceAfter)]
		public int setPCM = 0;


		// time
		[EditorHelp("Check Time (s)", "The time position in seconds to check for.", "")]
		[EditorLimit(0.0f, false)]
		[EditorElseCondition]
		public float checkTime = 0;

		[EditorHelp("Set Time (s)", "The time position in seconds to set upon reaching the check time.", "")]
		[EditorLimit(0.0f, false)]
		[EditorEndCondition(2)]
		[EditorCallback("button:testloop", EditorCallbackType.InstanceAfter)]
		public float setTime = 0;

		public MusicClipLoop()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			if(this.usePCM)
			{
				return "PCM " + this.checkPCM + " > " + this.setPCM;
			}
			else
			{
				return "Time " + this.checkTime + " > " + this.setTime;
			}
		}
	}
}

