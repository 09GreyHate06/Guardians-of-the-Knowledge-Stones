
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ComboInputKey : BaseData
	{
		[EditorHelp("Input Key", "Select the input key used for this combo key.", "")]
		public AssetSelection<InputKeyAsset> inputKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Timeout (s)", "Select the time in seconds the player has to press the next combo key.", "")]
		[EditorLimit(0.0f, false)]
		public float timeout = 1;


		// ignore keys
		[EditorHelp("Ignore Input Key", "Select the input key that will be ignored " +
			"while waiting for this combo key to be pressed.", "")]
		[EditorSeparator]
		[EditorArray("Add Ignore Input Key", "Adds an input key that will be ignored.", "",
			"Remove", "Removes this input key.", "", isHorizontal=true)]
		public AssetSelection<InputKeyAsset>[] ignoreKey = new AssetSelection<InputKeyAsset>[0];


		// ingame
		protected HashSet<int> ignore;

		public ComboInputKey()
		{

		}

		public bool GetButton(int inputID)
		{
			return InputKey.GetButton(this.inputKey.StoredAsset, inputID);
		}

		public bool OtherButton(int inputID, int parentKeyID)
		{
			if(this.ignore == null)
			{
				this.ignore = new HashSet<int>();
				this.ignore.Add(parentKeyID);
				if(this.inputKey.StoredAsset != null)
				{
					this.ignore.Add(this.inputKey.StoredAsset.Index);
				}
				if(this.ignoreKey.Length > 0)
				{
					for(int i = 0; i < this.ignoreKey.Length; i++)
					{
						if(this.ignoreKey[i].StoredAsset != null &&
							!this.ignore.Contains(this.ignoreKey[i].StoredAsset.Index))
						{
							this.ignore.Add(this.ignoreKey[i].StoredAsset.Index);
						}
					}
				}
			}

			for(int i = 0; i < Maki.InputKeys.Count; i++)
			{
				if(!this.ignore.Contains(i) &&
					Maki.InputKeys.Get(i).GetButton(inputID))
				{
					return true;
				}
			}
			return false;
		}
	}
}
