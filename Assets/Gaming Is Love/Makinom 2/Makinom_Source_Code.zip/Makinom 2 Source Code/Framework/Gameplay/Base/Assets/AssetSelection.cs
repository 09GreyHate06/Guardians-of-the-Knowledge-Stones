﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface IAssetSelection
	{

	}

	public class AssetSelection<T> : AssetSource<T>, IAssetSelection where T : UnityEngine.Object, IMakinomGenericAsset
	{
		public AssetSelection() : base()
		{

		}

		public virtual bool Is(BaseIndexData other)
		{
			return this.StoredAsset != null && this.StoredAsset.EditorSettings == other;
		}

		public override string ToString()
		{
			T asset = this.Source.EditorAsset as T;
			if(asset != null)
			{
				return asset.EditorSettings.EditorName;
			}
			return "";
		}
	}
}
