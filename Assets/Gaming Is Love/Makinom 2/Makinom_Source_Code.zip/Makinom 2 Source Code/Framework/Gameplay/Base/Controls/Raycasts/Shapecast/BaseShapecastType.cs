﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseShapecastType : BaseTypeData
	{
		public abstract bool CastSingle(out RaycastOutput hit, IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords);

		public abstract RaycastOutput[] CastAll(IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords);
	}

	public abstract class BaseShapecastType<T> : BaseShapecastType where T : IObjectSelection, new()
	{

	}
}
