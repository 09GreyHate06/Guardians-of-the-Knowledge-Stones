﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class PropertyFadeColorSettings : FadeColorSettings
	{
		// property
		[EditorHelp("Set Property", "Define the name of the property that will be faded.\n" +
			"If disabled, the '_Color' property for fading the color is used.", "")]
		public bool setProp = false;

		[EditorHelp("Property Name", "The name of the property that will be faded.\n" +
			"The combatant that's highlighted is used as 'User' for variable origins (e.g. to use a property stored in a combatant's object variables).", "")]
		[EditorWidth(true)]
		[EditorCondition("setProp", true)]
		[EditorAutoInit]
		public StringValue<GameObjectSelection> prop;

		[EditorHelp("Is Float", "The property that will be faded is a float value instead of a color.\n" +
			"Only the alpha value of the fade settings is used.", "")]
		[EditorEndCondition]
		public bool isFloat = false;

		public PropertyFadeColorSettings()
		{

		}

		public override void StartFade(FadeType fadeType, GameObject gameObject, bool inChildren, GetColorFade linkedTime)
		{
			if(this.setProp)
			{
				string property = this.prop.NeedsCall ? this.prop.GetValue(new DataCall(gameObject)) : this.prop.GetValue(null);
				if(inChildren)
				{
					Renderer[] renderer = gameObject.GetComponentsInChildren<Renderer>();
					for(int i = 0; i < renderer.Length; i++)
					{
						this.StartFade(fadeType, renderer[i], false, property, this.isFloat, linkedTime);
					}
				}
				else
				{
					Renderer renderer = gameObject.GetComponent<Renderer>();
					if(renderer != null)
					{
						this.StartFade(fadeType, renderer, false, property, this.isFloat, linkedTime);
					}
				}
			}
			else
			{
				base.StartFade(fadeType, gameObject, inChildren, linkedTime);
			}
		}

		public override void StartFade(FadeType fadeType, GameObject gameObject, bool inChildren, GetFloat deltaTime)
		{
			if(this.setProp)
			{
				string property = this.prop.NeedsCall ? this.prop.GetValue(new DataCall(gameObject)) : this.prop.GetValue(null);
				if(inChildren)
				{
					Renderer[] renderer = gameObject.GetComponentsInChildren<Renderer>();
					for(int i = 0; i < renderer.Length; i++)
					{
						this.StartFade(fadeType, renderer[i], false, property, this.isFloat, deltaTime);
					}
				}
				else
				{
					Renderer renderer = gameObject.GetComponent<Renderer>();
					if(renderer != null)
					{
						this.StartFade(fadeType, renderer, false, property, this.isFloat, deltaTime);
					}
				}
			}
			else
			{
				base.StartFade(fadeType, gameObject, inChildren, deltaTime);
			}
		}

		public virtual void StopFadeInstance(GameObject gameObject, bool inChildren, bool resetColor)
		{
			if(this.setProp)
			{
				if(this.prop.NeedsCall)
				{
					FadeColorSettings.StopFade(gameObject, inChildren, this.prop.GetValue(new DataCall(gameObject)), this.isFloat, resetColor);
				}
				else
				{
					FadeColorSettings.StopFade(gameObject, inChildren, this.prop.GetValue(null), this.isFloat, resetColor);
				}
			}
			else
			{
				FadeColorSettings.StopFade(gameObject, inChildren, resetColor);
			}
		}
	}
}
