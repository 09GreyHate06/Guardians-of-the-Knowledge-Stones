
using UnityEngine;
using GamingIsLove.Makinom.UI;
using GamingIsLove.Makinom.Reflection;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class FadeColorSettings : BaseData
	{
		[EditorHelp("Time (s)", "The time in seconds used for fading.", "")]
		[EditorLimit(0.0f, false)]
		public float time = 0.25f;

		[EditorHelp("Interpolation", "The interpolation used for fading.", "")]
		public Interpolation interpolation = new Interpolation();


		// fade selection
		[EditorHelp("Fade Alpha", "The alpha value of the color will fade.", "")]
		[EditorSeparator]
		public bool alpha = true;

		[EditorHelp("Fade Red", "The red value of the color will fade.", "")]
		public bool red = false;

		[EditorHelp("Fade Green", "The green value of the color will fade.", "")]
		public bool green = false;

		[EditorHelp("Fade Blue", "The blue value of the color will fade.", "")]
		public bool blue = false;


		// start color
		[EditorHelp("From Current", "The current color values will be used as start value.\n" +
			"If disabled, a selected color is used.", "")]
		[EditorSeparator]
		public bool fromCurrent = false;

		[EditorHelp("Start Color", "Select the color that will be faded from.", "")]
		[EditorCallback("button:fadeswap", EditorCallbackType.InstanceBefore)]
		[EditorCondition("fromCurrent", false)]
		[EditorEndCondition]
		public Color startColor = new Color(0, 0, 0, 0);


		// end color
		[EditorHelp("End Color", "Select the color that will be faded to.", "")]
		public Color endColor = new Color(0, 0, 0, 1);

		public FadeColorSettings()
		{

		}

		public FadeColorSettings(float time, float startAlpha, float endAlpha)
		{
			this.time = time;
			this.startColor = new Color(0, 0, 0, startAlpha);
			this.endColor = new Color(0, 0, 0, endAlpha);
		}

		public FadeColorSettings(float time, float startAlpha, float endAlpha, bool all)
		{
			this.time = time;
			this.startColor = new Color(0, 0, 0, startAlpha);
			this.endColor = new Color(0, 0, 0, endAlpha);
			if(all)
			{
				this.alpha = true;
				this.red = true;
				this.green = true;
				this.blue = true;
			}
		}


		/*
		============================================================================
		Start fade functions
		============================================================================
		*/
		public virtual FadeColor Create(FadeType fadeType, Color currentColor,
			SetColor setValue, GetFloat deltaTime)
		{
			return new FadeColor(fadeType, this.time,
				currentColor, this.fromCurrent ? currentColor : this.startColor,
				this.endColor, this.alpha, this.red, this.green, this.blue,
				this.interpolation, setValue, deltaTime, Maki.Game.Paused);
		}

		public virtual FadeColor Create(FadeType fadeType, Color currentColor,
			SetColor setValue, GetColorFade linkedTime)
		{
			return new FadeColor(fadeType, this.time,
				currentColor, this.fromCurrent ? currentColor : this.startColor,
				this.endColor, this.alpha, this.red, this.green, this.blue,
				this.interpolation, setValue, linkedTime, Maki.Game.Paused);
		}

		public virtual void StartFade(FadeType fadeType, GameObject gameObject, bool inChildren, GetColorFade linkedTime)
		{
			if(inChildren)
			{
				Renderer[] renderer = gameObject.GetComponentsInChildren<Renderer>();
				for(int i = 0; i < renderer.Length; i++)
				{
					this.StartFade(fadeType, renderer[i], false, "_Color", false, linkedTime);
				}
			}
			else
			{
				Renderer renderer = gameObject.GetComponent<Renderer>();
				if(renderer != null)
				{
					this.StartFade(fadeType, renderer, false, "_Color", false, linkedTime);
				}
			}
		}

		public virtual void StartFade(FadeType fadeType, GameObject gameObject, bool inChildren, string property, bool isFloat, GetColorFade linkedTime)
		{
			if(inChildren)
			{
				Renderer[] renderer = gameObject.GetComponentsInChildren<Renderer>();
				for(int i = 0; i < renderer.Length; i++)
				{
					this.StartFade(fadeType, renderer[i], false, property, isFloat, linkedTime);
				}
			}
			else
			{
				Renderer renderer = gameObject.GetComponent<Renderer>();
				if(renderer != null)
				{
					this.StartFade(fadeType, renderer, false, property, isFloat, linkedTime);
				}
			}
		}

		public virtual void StartFade(FadeType fadeType, Renderer renderer, bool sharedMaterial, string property, bool isFloat, GetColorFade linkedTime)
		{
			if(renderer is SpriteRenderer &&
				!isFloat &&
				property == "_Color")
			{
				SpriteRenderer sprite = (SpriteRenderer)renderer;
				FieldSource source = new FieldSource(sprite, "color");
				Maki.Fade.RemoveColor(source, true);
				Maki.Fade.AddColor(source,
					this.Create(fadeType, sprite.color,
						delegate (Color color) { sprite.color = color; },
						linkedTime));
			}
			else
			{
				Material[] materials;
				if(sharedMaterial)
				{
					materials = renderer.sharedMaterials;
				}
				else
				{
					materials = renderer.materials;
				}

				for(int i = 0; i < materials.Length; i++)
				{
					if(materials[i].HasProperty(property))
					{
						Material mat = materials[i];
						FieldSource source = new FieldSource(mat, property);
						if(isFloat)
						{
							Maki.Fade.RemoveColor(source, true);
							Maki.Fade.AddColor(source,
								this.Create(fadeType,
									new Color(0, 0, 0, mat.GetFloat(property)),
									delegate (Color color) { mat.SetFloat(property, color.a); },
									linkedTime));
						}
						else
						{
							Maki.Fade.RemoveColor(source, true);
							Maki.Fade.AddColor(source,
								this.Create(fadeType, mat.GetColor(property),
									delegate (Color color) { mat.SetColor(property, color); },
									linkedTime));
						}
					}
				}
			}
		}

		public virtual void StartFade(FadeType fadeType, GameObject gameObject, bool inChildren, GetFloat deltaTime)
		{
			if(inChildren)
			{
				Renderer[] renderer = gameObject.GetComponentsInChildren<Renderer>();
				for(int i = 0; i < renderer.Length; i++)
				{
					this.StartFade(fadeType, renderer[i], false, "_Color", false, deltaTime);
				}
			}
			else
			{
				Renderer renderer = gameObject.GetComponent<Renderer>();
				if(renderer != null)
				{
					this.StartFade(fadeType, renderer, false, "_Color", false, deltaTime);
				}
			}
		}

		public virtual void StartFade(FadeType fadeType, GameObject gameObject, bool inChildren, string property, bool isFloat, GetFloat deltaTime)
		{
			if(inChildren)
			{
				Renderer[] renderer = gameObject.GetComponentsInChildren<Renderer>();
				for(int i = 0; i < renderer.Length; i++)
				{
					this.StartFade(fadeType, renderer[i], false, property, isFloat, deltaTime);
				}
			}
			else
			{
				Renderer renderer = gameObject.GetComponent<Renderer>();
				if(renderer != null)
				{
					this.StartFade(fadeType, renderer, false, property, isFloat, deltaTime);
				}
			}
		}

		public virtual void StartFade(FadeType fadeType, Renderer renderer, bool sharedMaterial, string property, bool isFloat, GetFloat deltaTime)
		{
			if(renderer is SpriteRenderer &&
				!isFloat &&
				property == "_Color")
			{
				SpriteRenderer sprite = (SpriteRenderer)renderer;
				FieldSource source = new FieldSource(sprite, "color");
				Maki.Fade.RemoveColor(source, true);
				Maki.Fade.AddColor(source,
					this.Create(fadeType, sprite.color,
						delegate (Color color) { sprite.color = color; },
						deltaTime));
			}
			else
			{
				Material[] materials;
				if(sharedMaterial)
				{
					materials = renderer.sharedMaterials;
				}
				else
				{
					materials = renderer.materials;
				}

				for(int i = 0; i < materials.Length; i++)
				{
					if(materials[i].HasProperty(property))
					{
						Material mat = materials[i];
						FieldSource source = new FieldSource(mat, property);
						if(isFloat)
						{
							Maki.Fade.RemoveColor(source, true);
							Maki.Fade.AddColor(source,
								this.Create(fadeType,
									new Color(0, 0, 0, mat.GetFloat(property)),
									delegate (Color color) { mat.SetFloat(property, color.a); },
									deltaTime));
						}
						else
						{
							Maki.Fade.RemoveColor(source, true);
							Maki.Fade.AddColor(source,
								this.Create(fadeType, mat.GetColor(property),
									delegate (Color color) { mat.SetColor(property, color); },
									deltaTime));
						}
					}
				}
			}
		}

		public virtual void StartFade(FadeType fadeType, IColorFadeable instance, GetFloat deltaTime)
		{
			FieldSource source = new FieldSource(instance, "Color");
			Maki.Fade.RemoveColor(source, true);
			Maki.Fade.AddColor(source,
				this.Create(fadeType, instance.Color,
					delegate (Color color) { instance.Color = color; },
					deltaTime));
		}

		public virtual void StartFade(FadeType fadeType, Light light, GetFloat deltaTime)
		{
			FieldSource source = new FieldSource(light, "color");
			Maki.Fade.RemoveColor(source, true);
			Maki.Fade.AddColor(source,
				this.Create(fadeType, light.color,
					delegate (Color color) { light.color = color; },
					deltaTime));
		}

		public virtual void StartFade(FadeType fadeType, Component component, ColorField colorField, GetFloat deltaTime)
		{
			Color tmpColor = Color.white;
			if(colorField.GetColor(component, ref tmpColor))
			{
				FieldSource source = new FieldSource(component, colorField.fieldName);
				Maki.Fade.RemoveColor(source, true);
				Maki.Fade.AddColor(source,
					this.Create(fadeType, tmpColor,
						delegate (Color color) { colorField.SetColor(component, color); },
						deltaTime));
			}
		}


		/*
		============================================================================
		Stop fade functions
		============================================================================
		*/
		public static void StopFade(GameObject gameObject, bool inChildren, bool resetColor)
		{
			if(inChildren)
			{
				Renderer[] renderer = gameObject.GetComponentsInChildren<Renderer>();
				for(int i = 0; i < renderer.Length; i++)
				{
					FadeColorSettings.StopFade(renderer[i], false, "_Color", false, resetColor);
				}
			}
			else
			{
				Renderer renderer = gameObject.GetComponent<Renderer>();
				if(renderer != null)
				{
					FadeColorSettings.StopFade(renderer, false, "_Color", false, resetColor);
				}
			}
		}

		public static void StopFade(GameObject gameObject, bool inChildren, string property, bool isFloat, bool resetColor)
		{
			if(inChildren)
			{
				Renderer[] renderer = gameObject.GetComponentsInChildren<Renderer>();
				for(int i = 0; i < renderer.Length; i++)
				{
					FadeColorSettings.StopFade(renderer[i], false, property, isFloat, resetColor);
				}
			}
			else
			{
				Renderer renderer = gameObject.GetComponent<Renderer>();
				if(renderer != null)
				{
					FadeColorSettings.StopFade(renderer, false, property, isFloat, resetColor);
				}
			}
		}

		public static void StopFade(Renderer renderer, bool sharedMaterial, string property, bool isFloat, bool resetColor)
		{
			if(renderer is SpriteRenderer &&
				!isFloat &&
				property == "_Color")
			{
				SpriteRenderer sprite = (SpriteRenderer)renderer;
				Maki.Fade.RemoveColor(new FieldSource(sprite, "color"), resetColor);
			}
			else
			{
				Material[] materials;
				if(sharedMaterial)
				{
					materials = renderer.sharedMaterials;
				}
				else
				{
					materials = renderer.materials;
				}

				for(int i = 0; i < materials.Length; i++)
				{
					if(materials[i].HasProperty(property))
					{
						Material mat = materials[i];
						Maki.Fade.RemoveColor(new FieldSource(mat, property), resetColor);
					}
				}
			}
		}

		public static void StopFade(IColorFadeable instance, bool resetColor)
		{
			Maki.Fade.RemoveColor(new FieldSource(instance, "Color"), resetColor);
		}

		public static void StopFade(Light light, bool resetColor)
		{
			Maki.Fade.RemoveColor(new FieldSource(light, "Color"), resetColor);
		}

		public static void StopFade(Component component, string fieldName, bool resetColor)
		{
			Maki.Fade.RemoveColor(new FieldSource(component, fieldName), resetColor);
		}
	}
}
