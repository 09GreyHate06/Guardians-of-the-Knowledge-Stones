﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseWaitForAnim
	{
		protected Coroutine coroutine;

		protected float maxWaitTime = -1;

		public virtual void Reset()
		{

		}

		public abstract void Play(string name, Notify callback, bool wait, float maxWaitTime);

		public virtual void Cancel()
		{
			if(this.coroutine != null)
			{
				Maki.StopCoroutine(this.coroutine);
				this.coroutine = null;
			}
		}
	}
}
