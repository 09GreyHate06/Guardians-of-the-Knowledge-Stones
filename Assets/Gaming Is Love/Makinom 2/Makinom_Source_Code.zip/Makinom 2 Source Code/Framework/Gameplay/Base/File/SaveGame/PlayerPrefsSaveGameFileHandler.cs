﻿
using UnityEngine;
using GamingIsLove.Makinom.IO;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("PlayerPrefs", "Save games are stored in Unity's PlayerPrefs.")]
	public class PlayerPrefsSaveGameFileHandler : BaseSaveGameFileHandler
	{
		public PlayerPrefsSaveGameFileHandler()
		{

		}

		public override void SaveFile(int index, string data)
		{
			PlayerPrefs.SetString(Maki.SaveGame.GetFileName(index),
				Maki.SaveGameSettings.encryptData ?
					Maki.SecurityHandler.SaveGame(data) :
					data);
			PlayerPrefs.Save();
		}

		public override string LoadFile(int index)
		{
			string data = PlayerPrefs.GetString(Maki.SaveGame.GetFileName(index));
			data = Maki.SecurityHandler.LoadGame(data);
			if(Maki.SaveGame.CompressionHandler != null)
			{
				data = Maki.SaveGame.CompressionHandler.DecompressString(data);
			}
			return data;
		}

		public override void DeleteFile(int index)
		{
			PlayerPrefs.DeleteKey(Maki.SaveGame.GetFileName(index));
		}

		public override bool FileExists(int index)
		{
			return PlayerPrefs.HasKey(Maki.SaveGame.GetFileName(index));
		}
	}
}
