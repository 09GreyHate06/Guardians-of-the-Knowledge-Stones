﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Exponential/Exponential In", "Exponential easing in, accelerating from zero velocity.",
		sortIndex=6)]
	public class ExponentialInInterpolation : BaseInterpolation
	{
		public ExponentialInInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			if(elapsedTime > duration)
			{
				elapsedTime = duration;
			}
			return distance * Mathf.Pow(2, 10 * (elapsedTime / duration - 1)) + start;
		}
	}

	[EditorSettingInfo("Exponential/Exponential Out", "Exponential easing out, decelerating to zero velocity.",
		sortIndex=6)]
	public class ExponentialOutInterpolation : BaseInterpolation
	{
		public ExponentialOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			if(elapsedTime > duration)
			{
				elapsedTime = duration;
			}
			return distance * (-Mathf.Pow(2, -10 * elapsedTime / duration) + 1) + start;
		}
	}

	[EditorSettingInfo("Exponential/Exponential In + Out", "Exponential easing in/out, acceleration until halfway, then deceleration.",
		sortIndex=6)]
	public class ExponentialInOutInterpolation : BaseInterpolation
	{
		public ExponentialInOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 2.0f : elapsedTime / (duration / 2);
			if(elapsedTime < 1)
			{
				return distance / 2 * Mathf.Pow(2, 10 * (elapsedTime - 1)) + start;
			}
			elapsedTime--;
			return distance / 2 * (-Mathf.Pow(2, -10 * elapsedTime) + 2) + start;
		}
	}
}
