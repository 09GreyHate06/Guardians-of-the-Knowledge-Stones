﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ShapecastSetting<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Shape Type", "Select the shape that will be used:", "")]
		[EditorInfo(settingBaseType=typeof(BaseShapecastType), settingAutoSetup="settings")]
		public string type = "";


		// settings
		[EditorSeparator]
		public BaseShapecastType<T> settings = new Box3DShapecastType<T>();


		// general
		[EditorSeparator]
		[EditorTitleLabel("Direction")]
		[EditorLabel("The direction into which to sweep the shape.")]
		public Vector3Value<T> direction = new Vector3Value<T>(Vector3Direction.Forward);

		[EditorHelp("Maximum Distance", "The maximum distance of the cast.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Maximum Distance")]
		public FloatValue<T> maxDistance = new FloatValue<T>(typeof(FloatValue_InfinityType<T>));

		[EditorHelp("Layer Mask", "The layer mask used for the cast.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Layer Mask")]
		public FloatValue<T> layerMask = new FloatValue<T>(typeof(FloatValue_LayerMaskType<T>));

		public ShapecastSetting()
		{
			this.type = this.settings.GetGenericTypeName();
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(!this.settings.IsType(this.type))
			{
				DataObject data = this.settings.GetData();
				System.Type tmpType = ReflectionTypeHandler.Instance.GetType(this.type, typeof(BaseShapecastType));
				if(tmpType != null)
				{
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						tmpType.MakeGenericType(typeof(T)));
					if(tmpSettings is BaseShapecastType<T>)
					{
						this.settings = (BaseShapecastType<T>)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new Box3DShapecastType<T>();
						this.settings.SetData(data);
						this.type = this.settings.GetGenericTypeName();
					}
				}
				else
				{
					this.settings = new Box3DShapecastType<T>();
					this.settings.SetData(data);
					this.type = this.settings.GetGenericTypeName();
				}
			}
		}

		public override string ToString()
		{
			return this.settings.ToString();
		}


		/*
		============================================================================
		Cast functions
		============================================================================
		*/
		public virtual bool CastSingle(out RaycastOutput hit, IDataCall call, bool storeCoords)
		{
			return this.settings.CastSingle(out hit, call, this.direction.GetValue(call),
				this.maxDistance.GetValue(call), (int)this.layerMask.GetValue(call), storeCoords);
		}

		public virtual RaycastOutput[] CastAll(IDataCall call, bool storeCoords)
		{
			return this.settings.CastAll(call, this.direction.GetValue(call),
				this.maxDistance.GetValue(call), (int)this.layerMask.GetValue(call), storeCoords);
		}
	}
}
