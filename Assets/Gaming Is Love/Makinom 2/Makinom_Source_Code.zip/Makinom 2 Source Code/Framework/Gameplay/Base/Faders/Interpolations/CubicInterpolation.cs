﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Cubic/Cubic In", "Cubic easing in, accelerating from zero velocity.",
		sortIndex=2)]
	public class CubicInInterpolation : BaseInterpolation
	{
		public CubicInInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 1.0f : elapsedTime / duration;
			return distance * elapsedTime * elapsedTime * elapsedTime + start;
		}
	}

	[EditorSettingInfo("Cubic/Cubic Out", "Cubic easing out, decelerating to zero velocity.",
		sortIndex=2)]
	public class CubicOutInterpolation : BaseInterpolation
	{
		public CubicOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 1.0f : elapsedTime / duration;
			elapsedTime--;
			return distance * (elapsedTime * elapsedTime * elapsedTime + 1) + start;
		}
	}

	[EditorSettingInfo("Cubic/Cubic In + Out", "Cubic easing in/out, acceleration until halfway, then deceleration.",
		sortIndex=2)]
	public class CubicInOutInterpolation : BaseInterpolation
	{
		public CubicInOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 2.0f : elapsedTime / (duration / 2);
			if(elapsedTime < 1)
			{
				return distance / 2 * elapsedTime * elapsedTime * elapsedTime + start;
			}
			elapsedTime -= 2;
			return distance / 2 * (elapsedTime * elapsedTime * elapsedTime + 2) + start;
		}
	}
}
