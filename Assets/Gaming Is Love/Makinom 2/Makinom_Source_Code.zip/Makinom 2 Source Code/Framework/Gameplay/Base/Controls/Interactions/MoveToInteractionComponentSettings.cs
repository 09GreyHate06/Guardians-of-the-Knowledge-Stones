﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MoveToInteractionComponentSettings : BaseData
	{
		[EditorHelp("Move To Interaction", "The player will automatically move to the interaction before starting it.")]
		public bool useMoveToInteraction = true;

		[EditorHelp("Destination Object", "Optionally select a destination object to move to.")]
		[EditorCondition("useMoveToInteraction", true)]
		[EditorInfo(allowSceneObjects=true)]
		public GameObject destinationObject;


		// interaction radius
		[EditorHelp("Override Interaction Radius", "Override the default interaction radius.")]
		[EditorCondition("destinationObject", null)]
		[EditorSeparator]
		public bool overrideInteractionRadius = false;

		[EditorHelp("Set Interaction Radius", "Set the interaction radius.\n" +
			"If disabled, the determined radius of the interaction's game object will be used, i.e. " +
			"either from a 'Radius' component, colliders or NavMesh agent attached to the game object.")]
		[EditorCondition("overrideInteractionRadius", true)]
		public bool setInteractionRadius = false;

		[EditorHelp("Interaction Radius", "Define the radius.\n" +
			"The destination of the movement will be calculated from the player's radius, " +
			"the interaction's radius and the stop distance.")]
		[EditorCondition("setInteractionRadius", true)]
		[EditorEndCondition(2)]
		public float interactionRadius = 1;


		// stop distance
		[EditorHelp("Override Stop Distance", "Override the default stop distance.")]
		[EditorSeparator]
		public bool overrideStopDistance = false;

		[EditorHelp("Stop Distance", "The distance in world units the player will stop before the interaction.")]
		[EditorCondition("overrideStopDistance", true)]
		[EditorEndCondition(2)]
		public float stopDistance = 1;


		// speed
		[EditorHelp("Override Speed", "Override the default speed setting.")]
		[EditorSeparator]
		public bool overrideMoveToSpeed = false;

		[EditorHelp("Speed", "Define the speed used to move the player.")]
		[EditorCondition("overrideMoveToSpeed", true)]
		[EditorEndCondition(2)]
		public FloatValue<GameObjectSelection> moveToSpeed = new FloatValue<GameObjectSelection>(5);

		public MoveToInteractionComponentSettings()
		{

		}
	}
}
