﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Unity Input Manager", "A key defined in the Unity input manager is used.")]
	public class UnityInputManagerInputIDKeySetting : BaseInputIDKeySetting
	{
		// input name
		[EditorHelp("Input Name", "The name of the Unity input manager key.\n" +
			"The name must match the spelling of the name given in the Unity input manager.", "")]
		[EditorWidth(true)]
		public string keyName = "";

		[EditorHelp("Is Joypad Axis", "The used Unity input manager key is a joypad axis.\n" +
			"A joypad axis dont have down/hold/up actions, enable this option if you want to use them.", "")]
		public bool isJoypadAxis = false;

		[EditorHelp("Up/Down Full Axis", "Input of 'Up' or 'Down' input handling will be interpreted as full axis value of 1/-1.\n" +
			"E.g. enable this setting when using 'Down' input handling for UI horizontal/vertical axis input coming from joypad axis, " +
			"as otherwise the value received when 'Down' is registered will be too low.", "")]
		[EditorIndent]
		[EditorCondition("isJoypadAxis", true)]
		[EditorEndCondition]
		public bool joypadUpDownFullAxis = false;


		// input handling
		[EditorHelp("Input Handling", "Select when the input will be recognized:\n" +
			"- Down: When the key is pressed down.\n" +
			"- Hold: While the key is held down.\n" +
			"- Up: When the key is released.\n" +
			"- Any: When the key is pressed down, held down or released.", "")]
		[EditorSeparator]
		public InputHandling handling = InputHandling.Down;

		[EditorHelp("Timeout (s)", "The time in seconds between recognizing two inputs.\n" +
			"Set to 0 to recognize the input every frame.", "")]
		[EditorLimit(0.0f, false)]
		public float inputTimeout = 0;

		[EditorHelp("Hold Time (s)", "The time in seconds the input has to be held to recognize the input.\n" +
			"Set to 0 to recognize the input immediately.", "")]
		[EditorLimit(0.0f, false)]
		[EditorCondition("handling", InputHandling.Down)]
		[EditorElseCondition]
		[EditorDefaultValue(0.0f)]
		public float inputHoldTime = 0;

		[EditorHelp("Max Hold Time (s)", "The maximum time in seconds the input can be held to recognize the input.\n" +
			"Holding the input for longer will stop recognizing it as input.\n" +
			"Set to 0 to not use a maximum hold time.")]
		[EditorLimit(0.0f, false)]
		[EditorEndCondition]
		[EditorDefaultValue(0.0f)]
		public float inputMaxHoldTime = 0;


		// in-game
		private float lastJoypadAxis = 0;

		public UnityInputManagerInputIDKeySetting()
		{

		}

		public override void Clear()
		{
			this.lastJoypadAxis = 0;
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override float InputTimeout
		{
			get { return this.inputTimeout; }
		}

		public override float InputHoldTime
		{
			get { return this.inputHoldTime; }
		}

		public override float InputMaxHoldTime
		{
			get { return this.inputMaxHoldTime; }
		}

		public override InputHandling Handling
		{
			get { return this.handling; }
		}

		public override void TickBlocked(InputIDKey inputKey, int inputKeyID)
		{
			if(this.inputHoldTime > 0 ||
				this.inputMaxHoldTime > 0)
			{
				if(this.isJoypadAxis)
				{
					float tmpAxis = Time.timeScale == 0 ?
						Input.GetAxisRaw(this.keyName) :
						Input.GetAxis(this.keyName);

					if(tmpAxis == 0 && this.lastJoypadAxis != 0)
					{
						this.lastJoypadAxis = tmpAxis;
						inputKey.ReleaseDownTime();
					}
				}
				else
				{
					if(Input.GetButtonUp(this.keyName))
					{
						inputKey.ReleaseDownTime();
					}
				}
			}
		}

		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			if(this.isJoypadAxis)
			{
				inputKey.UpdateAxis = Time.timeScale == 0 ?
					Input.GetAxisRaw(this.keyName) : Input.GetAxis(this.keyName);

				// set input down time
				if(this.inputHoldTime > 0 ||
					this.inputMaxHoldTime > 0)
				{
					// down
					if(inputKey.UpdateAxis != 0 && this.lastJoypadAxis == 0)
					{
						inputKey.SetDownTime();
						this.lastJoypadAxis = inputKey.UpdateAxis;
						return;
					}
					// up
					else if(inputKey.UpdateAxis == 0 && this.lastJoypadAxis != 0)
					{
						inputKey.ReleaseDownTime();
						if(InputHandling.Hold == this.handling)
						{
							this.lastJoypadAxis = inputKey.UpdateAxis;
							return;
						}
					}
				}

				if((InputHandling.Down == this.handling && inputKey.UpdateAxis != 0 && this.lastJoypadAxis == 0) ||
					(InputHandling.Hold == this.handling && inputKey.UpdateAxis != 0 && this.lastJoypadAxis != 0) ||
					(InputHandling.Up == this.handling && inputKey.UpdateAxis == 0 && this.lastJoypadAxis != 0) ||
					(InputHandling.Any == this.handling &&
						((inputKey.UpdateAxis != 0 && this.lastJoypadAxis == 0) ||
						(inputKey.UpdateAxis != 0 && this.lastJoypadAxis != 0) ||
						(inputKey.UpdateAxis == 0 && this.lastJoypadAxis != 0))))
				{
					if(this.joypadUpDownFullAxis)
					{
						// down
						if(inputKey.UpdateAxis != 0 && this.lastJoypadAxis == 0)
						{
							inputKey.UpdateAxis = inputKey.ManipulateAxisValue(inputKey.UpdateAxis > 0 ? 1 : -1);
						}
						// up
						else if(inputKey.UpdateAxis == 0 && this.lastJoypadAxis != 0)
						{
							this.lastJoypadAxis = inputKey.ManipulateAxisValue(this.lastJoypadAxis > 0 ? 1 : -1);
						}
					}

					if(InputHandling.Up == this.handling ||
						(InputHandling.Any == this.handling && inputKey.UpdateAxis == 0))
					{
						float tmp = inputKey.UpdateAxis;
						inputKey.SetUpdateAxisUnmanipulated(this.lastJoypadAxis);
						this.lastJoypadAxis = tmp;
					}
					else
					{
						this.lastJoypadAxis = inputKey.UpdateAxis;
					}
					inputKey.Timeout = Time.realtimeSinceStartup + this.inputTimeout;
					inputKey.InputReceived = true;
				}
				else
				{
					this.lastJoypadAxis = inputKey.UpdateAxis;
				}
			}
			else
			{
				inputKey.UpdateAxis = Time.timeScale == 0 ?
					Input.GetAxisRaw(this.keyName) : Input.GetAxis(this.keyName);

				// set input down time
				if(this.inputHoldTime > 0)
				{
					if(Input.GetButtonDown(this.keyName))
					{
						inputKey.HoldTimeout = Time.realtimeSinceStartup + this.inputHoldTime;
						return;
					}
					else if(Input.GetButtonUp(this.keyName))
					{
						inputKey.HoldTimeout = Mathf.NegativeInfinity;
						if(InputHandling.Hold == this.handling)
						{
							return;
						}
					}
				}

				if((InputHandling.Down == this.handling && Input.GetButtonDown(this.keyName)) ||
					(InputHandling.Hold == this.handling && Input.GetButton(this.keyName)) ||
					(InputHandling.Up == this.handling && Input.GetButtonUp(this.keyName)) ||
					(InputHandling.Any == this.handling &&
						(Input.GetButtonDown(this.keyName) || Input.GetButton(this.keyName) ||
						Input.GetButtonUp(this.keyName))))
				{
					inputKey.Timeout = Time.realtimeSinceStartup + this.inputTimeout;

					inputKey.InputReceived = true;
				}
			}
		}

		public override float GetAxis(InputIDKey inputKey, int inputKeyID)
		{
			if(this.isJoypadAxis &&
				!inputKey.InputReceived)
			{
				return 0;
			}
			return inputKey.UpdateAxis;
		}
	}
}
