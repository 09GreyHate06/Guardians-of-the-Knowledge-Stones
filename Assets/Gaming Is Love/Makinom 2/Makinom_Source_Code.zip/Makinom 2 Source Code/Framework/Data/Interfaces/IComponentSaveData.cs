﻿
namespace GamingIsLove.Makinom
{
	/// <summary>
	/// Interface used for saving/loading component data of a game object with a save game.
	/// </summary>
	public interface IComponentSaveData : ISaveData
	{
		/// <summary>
		/// The data of a component is stored with a save key to know which component will get which data.
		/// The save key mustn't contain any spaces.
		/// </summary>
		/// <returns>The key used for saving this data.</returns>
		string GetSaveKey();
	}
}
