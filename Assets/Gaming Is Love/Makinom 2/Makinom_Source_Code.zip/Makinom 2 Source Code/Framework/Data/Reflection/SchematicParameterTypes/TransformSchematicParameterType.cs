﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Transform", "The transform of a game object.")]
	public class TransformSchematicParameterType : BaseSchematicParameterType
	{
		[EditorTitleLabel("Game Object")]
		public SchematicObjectSelection gameObject = new SchematicObjectSelection();

		public TransformSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.gameObject.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return true;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(Transform);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			GameObject tmpObject = this.gameObject.GetObject(schematic);
			return tmpObject != null ? tmpObject.transform : null;
		}
	}
}
