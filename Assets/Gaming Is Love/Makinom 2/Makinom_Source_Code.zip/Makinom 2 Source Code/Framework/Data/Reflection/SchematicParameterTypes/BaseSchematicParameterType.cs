﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	public abstract class BaseSchematicParameterType : BaseTypeData
	{
		public virtual bool NeedsCall
		{
			get { return false; }
		}

		public abstract System.Type GetParameterType();

		public abstract object GetParameterValue(Schematic schematic);
	}
}
