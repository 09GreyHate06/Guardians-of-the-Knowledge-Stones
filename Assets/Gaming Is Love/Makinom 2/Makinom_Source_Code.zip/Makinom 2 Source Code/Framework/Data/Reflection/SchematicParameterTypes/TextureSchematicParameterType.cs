﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Texture", "A texture.")]
	public class TextureSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Texture", "Select the texture that will be used as parameter.", "")]
		public SchematicTextureSelection texture = new SchematicTextureSelection();

		public TextureSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.texture.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(Texture);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.texture.GetTexture(schematic);
		}
	}
}
