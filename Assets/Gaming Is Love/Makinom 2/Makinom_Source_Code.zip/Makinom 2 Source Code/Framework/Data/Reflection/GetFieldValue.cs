﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using System.Reflection;

namespace GamingIsLove.Makinom.Reflection
{
	public class GetFieldValue<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Class Name", "The name of the class that contains the field/property.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		public string className = "";

		[EditorHelp("Field Name", "The name of the field/property that will be used.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Field, typeof(Component), "className",
			propertyFieldName="isProperty")]
		public string fieldName = "";

		[EditorHelp("Is Property", "Uses the value of a property.\n" +
			"If disabled, the value of a field will be used.", "")]
		public bool isProperty = false;

		[EditorHelp("Is Array", "The field/property is an array.\n" +
			"A defined index of the array is used.", "")]
		public bool isArray = false;

		[EditorHelp("Use Array Length", "Use the length of the array instead of the value of a defined index in the array.", "")]
		[EditorIndent]
		[EditorCondition("isArray", true)]
		public bool useArrayLength = false;

		[EditorHelp("Array Index", "The index of the array that will be used.", "")]
		[EditorCondition("useArrayLength", false)]
		[EditorAutoInit]
		[EditorEndCondition(2)]
		public FloatValue<T> arrayIndex;

		public GetFieldValue()
		{

		}

		public object GetValue(object instance, bool isStatic, IDataCall call)
		{
			if(this.className != "")
			{
				System.Type instanceType = isStatic ?
					Maki.ReflectionHandler.GetType(this.className) :
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component));

				if(instanceType != null)
				{
					if(!isStatic && instance is GameObject)
					{
						instance = ((GameObject)instance).GetComponent(instanceType);
						if(instance == null)
						{
							Debug.LogWarning("Component not found on game object: " + this.className);
						}
					}

					if(isStatic || instance != null)
					{
						if(this.fieldName != "")
						{
							if(this.isProperty)
							{
								PropertyInfo propertyInfo = Maki.ReflectionHandler.GetProperty(
									this.fieldName, ref instance, ref instanceType);
								if(propertyInfo != null)
								{
									try
									{
										if(this.isArray)
										{
											return this.GetArrayValue(call,
												propertyInfo.GetValue(isStatic ? null : instance, null));
										}
										else
										{
											if(propertyInfo.PropertyType.IsEnum)
											{
												return (int)propertyInfo.GetValue(isStatic ? null : instance, null);
											}
											else
											{
												return propertyInfo.GetValue(isStatic ? null : instance, null);
											}
										}
									}
									catch(System.Exception ex)
									{
										Debug.LogWarning("Getting property value failed (" + instanceType + "): " +
											this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
									}
								}
								else
								{
									Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
								}
							}
							else
							{
								FieldInfo fieldInfo = Maki.ReflectionHandler.GetField(
									this.fieldName, ref instance, ref instanceType);
								if(fieldInfo != null)
								{
									try
									{
										if(this.isArray)
										{
											return this.GetArrayValue(call,
												fieldInfo.GetValue(isStatic ? null : instance));
										}
										else
										{
											if(fieldInfo.FieldType.IsEnum)
											{
												return (int)fieldInfo.GetValue(isStatic ? null : instance);
											}
											else
											{
												return fieldInfo.GetValue(isStatic ? null : instance);
											}
										}
									}
									catch(System.Exception ex)
									{
										Debug.LogWarning("Getting field value failed (" + instanceType + "): " +
											this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
									}
								}
								else
								{
									Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
								}
							}
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + this.className);
				}
			}
			return null;
		}

		private object GetArrayValue(IDataCall call, object value)
		{
			System.Array array = value as System.Array;
			if(array != null)
			{
				return this.useArrayLength ?
					array.Length :
					array.GetValue((int)this.arrayIndex.GetValue(call));
			}
			else
			{
				System.Collections.IList list = value as System.Collections.IList;
				if(list != null)
				{
					return this.useArrayLength ?
						list.Count :
						list[(int)this.arrayIndex.GetValue(call)];
				}
			}
			return null;
		}

		public override string ToString()
		{
			return this.className + "." + this.fieldName;
		}
	}
}
