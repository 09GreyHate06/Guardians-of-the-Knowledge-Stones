
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Text;

namespace GamingIsLove.Makinom.Reflection
{
	public class SchematicCheckFields : BaseData
	{
		[EditorHelp("Class Name", "The name of the class that contains the fields or properties.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		public string className = "";


		// fields
		[EditorHelp("Needed", "Either all or just one of the field/property checks needs to be valid.", "")]
		public Needed needed = Needed.All;

		[EditorArray("Add Field", "Adds a field that will be checked.", "",
			"Remove", "Removes this field.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {"Field", "The field's value will be checked.", ""})]
		public SchematicFieldCheck[] field = new SchematicFieldCheck[0];

		public SchematicCheckFields()
		{

		}

		public bool Check(object instance, Schematic schematic, bool isStatic)
		{
			if(this.className != "")
			{
				System.Type instanceType = isStatic ?
					Maki.ReflectionHandler.GetType(this.className) :
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component));

				if(instanceType != null)
				{
					if(!isStatic && instance is GameObject)
					{
						instance = ((GameObject)instance).GetComponent(instanceType);
						if(instance == null)
						{
							Debug.LogWarning("Component not found on game object: " + this.className);
						}
					}

					if(isStatic || instance != null)
					{
						if(this.field.Length > 0)
						{
							for(int i = 0; i < this.field.Length; i++)
							{
								if(this.field[i].Check(instance, instanceType, schematic, isStatic))
								{
									if(Needed.One == this.needed)
									{
										return true;
									}
								}
								else if(Needed.All == this.needed)
								{
									return false;
								}
							}
							if(Needed.All == this.needed)
							{
								return true;
							}
							else
							{
								return false;
							}
						}
						else
						{
							return true;
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + this.className);
				}
			}
			return false;
		}

		public override string ToString()
		{
			if(this.field.Length > 0)
			{
				StringBuilder builder = new StringBuilder(this.className).Append(": ");
				for(int i = 0; i < this.field.Length; i++)
				{
					if(i > 0)
					{
						builder.Append(", ");
					}
					builder.Append(this.field[i].ToString());
				}
				return builder.ToString();
			}
			return "";
		}
	}
}
