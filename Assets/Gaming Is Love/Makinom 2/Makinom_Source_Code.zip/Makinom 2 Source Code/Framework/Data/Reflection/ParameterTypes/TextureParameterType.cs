﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Texture", "A texture.")]
	public class TextureParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Texture", "Select the texture that will be used as parameter.", "")]
		public AssetSource<Texture> texture = new AssetSource<Texture>();

		public TextureParameterType()
		{

		}

		public override string ToString()
		{
			return this.texture.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(Texture);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.texture.StoredAsset;
		}
	}
}
