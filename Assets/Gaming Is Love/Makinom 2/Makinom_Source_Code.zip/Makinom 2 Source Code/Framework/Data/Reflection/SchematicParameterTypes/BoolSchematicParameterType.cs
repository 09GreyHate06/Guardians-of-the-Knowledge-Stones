﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Bool", "A bool value.")]
	public class BoolSchematicParameterType : BaseSchematicParameterType
	{
		[EditorTitleLabel("Bool Value")]
		public BoolValue<SchematicObjectSelection> boolValue = new BoolValue<SchematicObjectSelection>();

		public BoolSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.boolValue.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.boolValue.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(bool);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.boolValue.GetValue(schematic);
		}
	}
}
