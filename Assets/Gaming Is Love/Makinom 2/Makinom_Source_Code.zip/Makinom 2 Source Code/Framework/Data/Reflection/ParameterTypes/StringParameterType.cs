﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("String", "A string value.")]
	public class StringParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("String Value", "Define the string value that will be used as parameter.", "")]
		public StringValue<T> stringValue = new StringValue<T>();

		public StringParameterType()
		{

		}

		public override string ToString()
		{
			return this.stringValue.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.stringValue.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(string);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.stringValue.GetValue(call);
		}
	}
}
