
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Text;
using System.Reflection;

namespace GamingIsLove.Makinom.Reflection
{
	public class SchematicCheckMethod : BaseData
	{
		[EditorHelp("Class Name", "The name of the class that contains the function.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		public string className = "";

		[EditorHelp("Function Name", "The name of the function that will be called.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Function, typeof(Component), "className")]
		public string functionName = "";


		// return value
		[EditorHelp("Return Value Type", "Select the value type of the return value:\n" +
			"- String: A string value.\n" +
			"- Bool: A bool value.\n" +
			"- Int: An integer value.\n" +
			"- Float: A float value.\n" +
			"- Vector2: A Vector2 value (uses a Vector3, but only the X and Y axes).\n" +
			"- Vector3: A Vector3 value.\n" +
			"- Quaternion: A Quaternion value (uses a Vector3 as euler angles).", "")]
		public ParameterTypeSimple type = ParameterTypeSimple.String;


		// string
		[EditorHelp("String Value", "Define the string that will be used as parameter.", "")]
		[EditorCondition("type", ParameterTypeSimple.String)]
		[EditorEndCondition]
		[EditorAutoInit]
		public StringValue<SchematicObjectSelection> stringValue = new StringValue<SchematicObjectSelection>();


		// bool
		[EditorTitleLabel("Bool Value")]
		[EditorSeparator]
		[EditorCondition("type", ParameterTypeSimple.Bool)]
		[EditorEndCondition]
		[EditorAutoInit]
		public BoolValue<SchematicObjectSelection> boolValue;


		// int, float
		[EditorHelp("Int/Float Value", "Define the int/float value used as parameter.", "")]
		[EditorSeparator]
		[EditorCondition("type", ParameterTypeSimple.Int)]
		[EditorCondition("type", ParameterTypeSimple.Float)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<SchematicObjectSelection> floatValue;


		// vector3, vector3
		[EditorTitleLabel("Vector2/Vector3/Quaternion Value")]
		[EditorSeparator]
		[EditorCondition("type", ParameterTypeSimple.Vector2)]
		[EditorCondition("type", ParameterTypeSimple.Vector3)]
		[EditorCondition("type", ParameterTypeSimple.Quaternion)]
		[EditorEndCondition]
		[EditorAutoInit]
		public Vector3Value<SchematicObjectSelection> vector3Value;


		// parameters
		[EditorArray("Add Parameter", "Adds a parameter that will be used when calling the function.", "",
			"Remove", "Removes this parameter.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Parameter", "The parameter will be used when calling the function.", ""
			})]
		public SchematicParameterSetting[] parameters = new SchematicParameterSetting[0];

		public SchematicCheckMethod()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.ContainsArray<DataObject>("parameter"))
			{
				DataObject[] tmp = data.GetFileArray("parameter");
				if(tmp.Length > 0)
				{
					this.parameters = new SchematicParameterSetting[tmp.Length];
					for(int i = 0; i < this.parameters.Length; i++)
					{
						this.parameters[i] = SchematicParameterSetting.UpgradeData(tmp[i]);
					}
				}
			}
		}

		public System.Object GetValue(Schematic schematic)
		{
			if(ParameterTypeSimple.String == this.type)
			{
				return this.stringValue.GetValue(schematic);
			}
			else if(ParameterTypeSimple.Bool == this.type)
			{
				return this.boolValue.GetValue(schematic);
			}
			else if(ParameterTypeSimple.Int == this.type)
			{
				return (int)this.floatValue.GetValue(schematic);
			}
			else if(ParameterTypeSimple.Float == this.type)
			{
				return this.floatValue.GetValue(schematic);
			}
			else if(ParameterTypeSimple.Vector2 == this.type)
			{
				return (Vector2)this.vector3Value.GetValue(schematic);
			}
			else if(ParameterTypeSimple.Vector3 == this.type)
			{
				return this.vector3Value.GetValue(schematic);
			}
			else if(ParameterTypeSimple.Quaternion == this.type)
			{
				return Quaternion.Euler(this.vector3Value.GetValue(schematic));
			}
			return null;
		}

		public bool Check(object instance, Schematic schematic, bool isStatic)
		{
			if(this.className != "" && this.functionName != "")
			{
				System.Type instanceType = isStatic ?
					Maki.ReflectionHandler.GetType(this.className) :
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component));

				if(instanceType != null)
				{
					if(!isStatic && instance is GameObject)
					{
						instance = ((GameObject)instance).GetComponent(instanceType);
						if(instance == null)
						{
							Debug.LogWarning("Component not found on game object: " + this.className);
						}
					}

					if(isStatic || instance != null)
					{
						if(this.parameters.Length > 0)
						{
							System.Type[] types = new System.Type[this.parameters.Length];
							System.Object[] values = new System.Object[this.parameters.Length];

							for(int i = 0; i < this.parameters.Length; i++)
							{
								types[i] = this.parameters[i].settings.GetParameterType();
								values[i] = this.parameters[i].settings.GetParameterValue(schematic);
							}

							MethodInfo methodInfo = Maki.ReflectionHandler.GetMethod(
								this.functionName, types, ref instance, ref instanceType);
							if(methodInfo != null)
							{
								try
								{
									System.Object value = methodInfo.Invoke(isStatic ? null : instance, values);
									return value != null && value.Equals(this.GetValue(schematic));
								}
								catch(System.Exception ex)
								{
									Debug.LogWarning("Method call failed (" + instanceType + "): " +
										this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
								}
							}
							else
							{
								Debug.LogWarning("Method not found (" + instanceType + "): " + this.functionName);
							}
						}
						else
						{
							MethodInfo methodInfo = Maki.ReflectionHandler.GetMethod(
								this.functionName, new System.Type[] {}, ref instance, ref instanceType);
							if(methodInfo != null)
							{
								try
								{
									System.Object value = methodInfo.Invoke(isStatic ? null : instance, null);
									return value != null && value.Equals(this.GetValue(schematic));
								}
								catch(System.Exception ex)
								{
									Debug.LogWarning("Method call failed (" + instanceType + "): " +
										this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
								}
							}
							else
							{
								Debug.LogWarning("Method not found (" + instanceType + "): " + this.functionName);
							}
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + this.className);
				}
			}
			return false;
		}

		public override string ToString()
		{
			StringBuilder builder = new StringBuilder(this.className).
				Append(".").Append(this.functionName);
			if(this.parameters.Length > 0)
			{
				builder.Append("(");
				for(int i = 0; i < this.parameters.Length; i++)
				{
					if(i > 0)
					{
						builder.Append(", ");
					}
					builder.Append(this.parameters[i].ToString());
				}
				builder.Append(")");
			}

			builder.Append(" == ");
			if(ParameterTypeSimple.String == this.type)
			{
				builder.Append(this.stringValue.ToString());
			}
			else if(ParameterTypeSimple.Bool == this.type)
			{
				builder.Append(this.boolValue.ToString());
			}
			else if(ParameterTypeSimple.Int == this.type ||
				ParameterTypeSimple.Float == this.type)
			{
				builder.Append(this.floatValue.ToString());
			}
			else if(ParameterTypeSimple.Vector2 == this.type ||
				ParameterTypeSimple.Vector3 == this.type ||
				ParameterTypeSimple.Quaternion == this.type)
			{
				builder.Append(this.vector3Value.ToString());
			}

			return builder.ToString();
		}
	}
}
