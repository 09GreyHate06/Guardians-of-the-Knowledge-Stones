﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Sprite", "A sprite.")]
	public class SpriteSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Sprite", "Select the sprite that will be used as parameter.", "")]
		public SchematicSpriteSelection sprite = new SchematicSpriteSelection();

		public SpriteSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.sprite.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(Sprite);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.sprite.GetSprite(schematic);
		}
	}
}
