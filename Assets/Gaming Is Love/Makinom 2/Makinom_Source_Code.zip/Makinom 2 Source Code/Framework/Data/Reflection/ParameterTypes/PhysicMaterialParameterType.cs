﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Physic Material", "A physic material.")]
	public class PhysicMaterialParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Physic Material", "Select the physic material that will be used as parameter.", "")]
#if Unity_2019
		public AssetSource<PhysicMaterial> physicMaterial = new AssetSource<PhysicMaterial>();

		public override System.Type GetParameterType()
		{
			return typeof(PhysicMaterial);
		}
#else
		public AssetSource<PhysicsMaterial> physicMaterial = new AssetSource<PhysicsMaterial>();

		public override System.Type GetParameterType()
		{
			return typeof(PhysicsMaterial);
		}
#endif

		public PhysicMaterialParameterType()
		{

		}

		public override string ToString()
		{
			return this.physicMaterial.ToString();
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.physicMaterial.StoredAsset;
		}
	}
}
