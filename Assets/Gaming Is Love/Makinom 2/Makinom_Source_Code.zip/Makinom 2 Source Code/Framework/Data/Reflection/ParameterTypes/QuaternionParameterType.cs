﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Quaternion", "A Quaternion value (uses a Vector3 as euler angles).")]
	public class QuaternionParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Quaternion Value")]
		public Vector3Value<T> vector3Value = new Vector3Value<T>();

		public QuaternionParameterType()
		{

		}

		public override string ToString()
		{
			return this.vector3Value.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.vector3Value.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(Quaternion);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return Quaternion.Euler(this.vector3Value.GetValue(call));
		}
	}
}
