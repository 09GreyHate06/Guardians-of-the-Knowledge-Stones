﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	public class SchematicParameterSetting : BaseData
	{
		[EditorHelp("Value Type", "Select the value type that will be used:", "")]
		[EditorInfo(settingBaseType = typeof(BaseSchematicParameterType), settingAutoSetup = "settings")]
		public string type = typeof(StringSchematicParameterType).ToString();

		public BaseSchematicParameterType settings = new StringSchematicParameterType();

		public SchematicParameterSetting()
		{
			this.type = this.settings.GetGenericTypeName();
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if("settings" == fieldName)
			{
				if(!this.settings.IsType(this.type))
				{
					DataObject data = this.settings.GetData();
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						this.type, typeof(BaseSchematicParameterType));
					if(tmpSettings is BaseSchematicParameterType)
					{
						this.settings = (BaseSchematicParameterType)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new StringSchematicParameterType();
						this.settings.SetData(data);
						this.type = this.settings.GetType().ToString();
					}
				}
			}
		}

		public override string ToString()
		{
			return this.settings.ToString();
		}

		public static SchematicParameterSetting UpgradeData(DataObject data)
		{
			int tmp = 0;
			data.Get("type", ref tmp);

			BaseSchematicParameterType settings = null;
			if(tmp == 0)
			{
				settings = new StringSchematicParameterType();
			}
			else if(tmp == 1)
			{
				settings = new BoolSchematicParameterType();
			}
			else if(tmp == 2)
			{
				settings = new IntSchematicParameterType();
			}
			else if(tmp == 3)
			{
				settings = new FloatSchematicParameterType();
			}
			else if(tmp == 4)
			{
				settings = new Vector2SchematicParameterType();
			}
			else if(tmp == 5)
			{
			}
			else if(tmp == 6)
			{
				settings = new QuaternionSchematicParameterType();
			}
			else if(tmp == 7)
			{
				settings = new ColorSchematicParameterType();
			}
			else if(tmp == 8)
			{
				settings = new LayerMaskSchematicParameterType();
			}
			else if(tmp == 9)
			{
				settings = new GameObjectSchematicParameterType();
			}
			else if(tmp == 10)
			{
				settings = new PrefabSchematicParameterType();
			}
			else if(tmp == 11)
			{
				settings = new AudioClipSchematicParameterType();
			}
			else if(tmp == 12)
			{
				settings = new AudioMixerSchematicParameterType();
			}
			else if(tmp == 13)
			{
				settings = new AudioMixerGroupSchematicParameterType();
			}
			else if(tmp == 14)
			{
				settings = new SpriteSchematicParameterType();
			}
			else if(tmp == 15)
			{
				settings = new TextureSchematicParameterType();
			}
			else if(tmp == 16)
			{
				settings = new MaterialSchematicParameterType();
			}
			else if(tmp == 17)
			{
				settings = new PhysicMaterialSchematicParameterType();
			}
			else if(tmp == 18)
			{
				settings = new PhysicsMaterial2DSchematicParameterType();
			}
			else if(tmp == 19)
			{
				settings = new ComponentSchematicParameterType();
			}
			else if(tmp == 20)
			{
				settings = new EnumSchematicParameterType();
			}
			else if(tmp == 21)
			{
				settings = new TransformSchematicParameterType();
			}

			if(settings == null)
			{
				settings = new StringSchematicParameterType();
			}
			settings.SetData(data);

			SchematicParameterSetting parameter = new SchematicParameterSetting();
			parameter.settings = settings;
			parameter.type = parameter.settings.GetGenericTypeName();
			return parameter;
		}
	}
}
