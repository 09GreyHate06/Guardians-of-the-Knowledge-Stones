﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface ISecurityHandler
	{
		/*
		============================================================================
		Save game handling functions
		============================================================================
		*/
		string SaveGame(string text);

		string LoadGame(string text);


		/*
		============================================================================
		Project handling functions
		============================================================================
		*/
		string SaveData(string data);

		string LoadData(string data);

		byte[] Encrypt(byte[] data);

		byte[] Decrypt(byte[] cypher);
	}
}
