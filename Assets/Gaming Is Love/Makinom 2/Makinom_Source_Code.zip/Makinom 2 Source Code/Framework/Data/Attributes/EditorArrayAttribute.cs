
namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorArrayAttribute : System.Attribute
	{
		public bool showOnly = false;

		// enbox array element
		public bool enbox = false;
		public bool separator = false;

		// add button
		public bool isAdd = false;
		public string[] addText = new string[] {"", "", ""};

		// remove button
		public bool isRemove = false;
		public string[] removeText = new string[] {"", "", ""};
		public int noRemoveCount = 0;

		public bool isMove = false;
		public bool isCopy = false;

		// index labels
		public string titleLabel = "";
		public bool nameIndex = false;

		// alignment
		public bool isHorizontal = false;

		// index callbacks
		public string callbackBefore = "";
		public string callbackAfter = "";
		public string checkCallback = "";

		// add/remove callbacks
		public string callbackAdd = "";
		public string callbackRemove = "";

		// check fail
		public bool setDefaultValue = false;
		public object defaultValue;

		// foldout
		public bool foldout = false;
		public bool foldoutDefault = true;
		public string[] foldoutText;

		// special remove
		public string removeCheckField = "";
		public object defaultAddValue;

		public EditorArrayAttribute()
		{

		}

		public EditorArrayAttribute(string addName, string addHelp, string addInfo,
			string removeName, string removeHelp, string removeInfo)
		{
			this.isAdd = true;
			this.isRemove = true;
			this.addText = new string[] { addName, addHelp, addInfo };
			this.removeText = new string[] { removeName, removeHelp, removeInfo };
		}
	}
}

