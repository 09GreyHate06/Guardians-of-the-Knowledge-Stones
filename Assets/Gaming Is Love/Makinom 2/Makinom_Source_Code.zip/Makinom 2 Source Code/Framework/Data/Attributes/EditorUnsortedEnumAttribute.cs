﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Enum, AllowMultiple = false)]
	public class EditorUnsortedEnumAttribute : System.Attribute
	{
		public EditorUnsortedEnumAttribute()
		{

		}
	}
}
