﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum EditorReflectionFieldType { Class, Enum, Function, Field };

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorReflectionFieldAttribute : System.Attribute
	{
		public EditorReflectionFieldType type = EditorReflectionFieldType.Class;


		// string field defining class name
		public string classFieldName = "";

		// bool field defining if field or property
		public string propertyFieldName = "";


		// types
		public System.Type baseType = null;

		public System.Type fieldType = null;

		public EditorReflectionFieldAttribute(EditorReflectionFieldType type)
		{
			this.type = type;
		}

		public EditorReflectionFieldAttribute(EditorReflectionFieldType type, System.Type baseType)
		{
			this.type = type;
			this.baseType = baseType;
		}

		public EditorReflectionFieldAttribute(EditorReflectionFieldType type, System.Type baseType, string classFieldName)
		{
			this.type = type;
			this.baseType = baseType;
			this.classFieldName = classFieldName;
		}
	}
}
