﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorWidthAttribute : System.Attribute
	{
		public float width = 300;

		public bool expand = false;

		public bool hideName = false;

		public bool noHorizontal = false;

		public EditorWidthAttribute()
		{

		}

		public EditorWidthAttribute(float width)
		{
			this.width = width;
		}

		public EditorWidthAttribute(bool expand)
		{
			this.expand = expand;
		}

		public EditorWidthAttribute(float width, bool hideName)
		{
			this.width = width;
			this.hideName = hideName;
		}

		public GUILayoutOption GetWidth()
		{
			if(this.expand)
			{
				return GUILayout.ExpandWidth(true);
			}
			else
			{
				return GUILayout.Width(this.width);
			}
		}
	}
}
