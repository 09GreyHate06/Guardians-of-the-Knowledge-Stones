
using UnityEngine;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false)]
	public class HighlightSettingsAttribute : System.Attribute
	{
		// 0 == blue (string)
		// 1 == green (float)
		// 2 == brown (bool)
		// 3 == purple (Vector3)
		// 4 == lila (object selections)
		// 5 == yellow (selected data)
		public int color = 0;

		public HighlightSettingsAttribute()
		{

		}

		public HighlightSettingsAttribute(int color)
		{
			this.color = color;
		}
	}
}
