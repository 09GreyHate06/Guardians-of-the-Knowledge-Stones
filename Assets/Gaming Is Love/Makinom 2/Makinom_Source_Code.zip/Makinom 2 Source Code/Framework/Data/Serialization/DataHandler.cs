
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public sealed class DataHandler
	{
		// instance
		private static DataHandler instance;

		private static object instanceLock = new object();

		private MakinomProjectAsset projectAsset;

		private bool dataLoaded = false;


		// data
		private static List<MakinomDataExtension> extensions;

		private BaseSettings[] setting;

		private List<GenericAssetListSettings> listSetting;

		private Dictionary<System.Type, BaseSettings> lookup;

		private DataHandler(MakinomProjectAsset project)
		{
			if(instance != null)
			{
				Debug.LogError("You can't create two instances of DataHandler!");
			}
			else
			{
				instance = this;
				instance.projectAsset = project;
			}
		}

		public static DataHandler Initialize(MakinomProjectAsset project)
		{
			if(instance == null)
			{
				lock(instanceLock)
				{
					if(instance == null)
					{
						new DataHandler(project);
					}
				}
			}
			else
			{
				instance.projectAsset = project;
			}
			return instance;
		}

		public MakinomProjectAsset ProjectAsset
		{
			get { return this.projectAsset; }
			set
			{
				if(this.projectAsset != value)
				{
					this.projectAsset = value;
					this.LoadData();
				}
			}
		}

		public void SetProject(MakinomProjectAsset projectAsset)
		{
			this.projectAsset = projectAsset;
			this.LoadProject(this.projectAsset);
		}

		public static List<MakinomDataExtension> Extensions
		{
			get
			{
				if(DataHandler.extensions == null)
				{
					DataHandler.extensions = ReflectionTypeHandler.FindAndCreateAll<MakinomDataExtension>();
					DataHandler.extensions.Sort(new MakinomDataExtension.Sorter());
				}
				return DataHandler.extensions;
			}
		}


		/*
		============================================================================
		Data handling
		============================================================================
		*/
		public bool DataLoaded
		{
			get { return this.dataLoaded; }
		}

		public void LoadData()
		{
			this.LoadProject(this.projectAsset);
		}

		public void LoadProject(MakinomProjectAsset project)
		{
			this.dataLoaded = false;

			// load project
			if(project == null)
			{
				Debug.LogWarning("No Makinom Project Asset found!\n" +
					"Make sure to add a 'Game Starter' to your scene when you want to start playing in it.");
			}
			else
			{
				if(DataHandler.extensions == null)
				{
					DataHandler.extensions = ReflectionTypeHandler.FindAndCreateAll<MakinomDataExtension>();
				}

				List<System.Type> types = new List<System.Type>();
				// load first
				types.Add(typeof(UISystemSettings));
				// editor
				types.Add(typeof(EditorSettings));
				types.Add(typeof(BackupSettings));
				// base
				types.Add(typeof(LanguagesSettings));
				types.Add(typeof(GameControlsSettings));
				types.Add(typeof(GameStatesSettings));
				types.Add(typeof(InputKeysSettings));
				types.Add(typeof(PrefabSaversSettings));
				// game
				types.Add(typeof(GameSettings));
				types.Add(typeof(MusicClipsSettings));
				types.Add(typeof(GlobalMachinesSettings));
				types.Add(typeof(SceneConnectionsSettings));
				// menu
				types.Add(typeof(UILayersSettings));
				types.Add(typeof(UILayoutsSettings));
				types.Add(typeof(UIBoxesSettings));
				types.Add(typeof(SaveGameSettings));
				types.Add(typeof(UISettings));
				types.Add(typeof(TextCodeSettings));
				types.Add(typeof(HUDsSettings));
				// load plugins last
				types.Add(typeof(PluginsSettings));

				// extensions
				for(int i = 0; i < DataHandler.extensions.Count; i++)
				{
					DataHandler.extensions[i].GetDataTypes(types);
					DataHandler.extensions[i].CreateInstance();
				}

				// create settings
				this.setting = new BaseSettings[types.Count];
				this.listSetting = new List<GenericAssetListSettings>();
				this.lookup = new Dictionary<System.Type, BaseSettings>();

				System.Type[] constTypes = new System.Type[] { typeof(MakinomProjectAsset) };
				object[] constValues = new object[] { project };

				for(int i = 0; i < types.Count; i++)
				{
					this.setting[i] = (BaseSettings)ReflectionTypeHandler.Instance.
						CreateInstance(types[i], constTypes, constValues);
					this.lookup.Add(types[i], this.setting[i]);
					if(this.setting[i] is GenericAssetListSettings)
					{
						this.listSetting.Add((GenericAssetListSettings)this.setting[i]);
					}
				}

				if(Application.isPlaying &&
					Maki.GameSettings.performance.autoDataInit)
				{
					for(int i = 0; i < this.setting.Length; i++)
					{
						this.setting[i].InitDataAssetSettings();
					}
				}
				this.dataLoaded = true;
			}
		}

		public Dictionary<string, DataFile> GetSaveData(bool encrypt, DataFile.SaveFormatType format)
		{
			Dictionary<string, DataFile> fileList = new Dictionary<string, DataFile>();
			if(Application.isEditor)
			{
				for(int i = 0; i < this.setting.Length; i++)
				{
					fileList.Add(this.setting[i].Filename, this.setting[i].GetSaveData(encrypt, format));
				}
			}
			return fileList;
		}

		public List<string> GetFileDifferences(MakinomProjectAsset project, bool encrypt, DataFile.SaveFormatType format, Dictionary<string, DataFile> fileList)
		{
			List<string> list = new List<string>();
			if(Application.isEditor && project != null)
			{
				for(int i = 0; i < this.setting.Length; i++)
				{
					DataFile file = null;
					if(this.setting[i].HasChanged(project, encrypt, format, out file))
					{
						list.Add(this.setting[i].Filename);
						if(file == null)
						{
							file = this.setting[i].GetSaveData(encrypt, format);
						}
						fileList.Add(this.setting[i].Filename, file);
					}
					else
					{
						fileList.Add(this.setting[i].Filename, null);
					}
				}
			}
			return list;
		}


		/*
		============================================================================
		Get data variables
		============================================================================
		*/
		public T Get<T>() where T : BaseSettings
		{
			BaseSettings tmp = null;
			if(this.lookup.TryGetValue(typeof(T), out tmp))
			{
				return tmp as T;
			}
			return null;
		}

		public BaseSettings[] All
		{
			get { return this.setting; }
		}

		public IMakinomGenericAsset FindAsset(string guid)
		{
			IMakinomGenericAsset asset = null;
			for(int i = 0; i < this.listSetting.Count; i++)
			{
				if(this.listSetting[i] is GenericAssetListSettings)
				{
					asset = this.listSetting[i].GetGenericAssetForGUID(guid);
					if(asset !=  null)
					{
						break;
					}
				}
			}
			return asset;
		}
	}
}
