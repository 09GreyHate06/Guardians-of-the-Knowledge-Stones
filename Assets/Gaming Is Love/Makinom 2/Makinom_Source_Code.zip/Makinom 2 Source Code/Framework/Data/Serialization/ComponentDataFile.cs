﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom.IO;

namespace GamingIsLove.Makinom
{
	[System.Serializable]
	public class ComponentDataFile : DataFile
	{
		[SerializeField]
		[HideInInspector]
		private string stringData = null;

		public ComponentDataFile(string name, bool encrypted) : base(name, encrypted)
		{

		}

		public override void SetData(byte[] data)
		{
			base.SetData(data);
			this.stringData = System.Convert.ToBase64String(data);
		}

		public override DataObject ToDataObject()
		{
			if(this.dataObject == null)
			{
				try
				{
					if(string.IsNullOrEmpty(this.xmlData))
					{
						this.dataObject = this.byteData == null || this.byteData.Length == 0 ?
							new DataObject() :
							new DataObject(this.byteData, this.encrypted, this);
					}
					else
					{
						this.dataObject = new XMLParser(this.GetXMLData(), this.lookUp).Parse();
					}
				}
				catch
				{
					if(!string.IsNullOrEmpty(this.stringData))
					{
						byte[] data = System.Convert.FromBase64String(this.stringData);
						this.dataObject = data == null || data.Length == 0 ?
							new DataObject() :
							new DataObject(data, this.encrypted, this);
					}
					else
					{
						this.dataObject = new DataObject();
					}
				}
			}
			return this.dataObject;
		}
	}
}
