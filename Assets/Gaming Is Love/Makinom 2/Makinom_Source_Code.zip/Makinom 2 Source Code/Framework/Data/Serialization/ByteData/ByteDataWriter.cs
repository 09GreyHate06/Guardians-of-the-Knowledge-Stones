﻿
using UnityEngine;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.IO;

namespace GamingIsLove.Makinom.IO
{
	public class ByteDataWriter
	{
		private static System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();

		private readonly MemoryStream memoryStream;

		private readonly BinaryWriter binaryWriter;

		private bool encrypt = false;

		public ByteDataWriter(bool encrypt) : this(encrypt, 512)
		{

		}

		public ByteDataWriter(bool encrypt, int size)
		{
			this.encrypt = encrypt;
			this.memoryStream = new MemoryStream(size);
			this.binaryWriter = new BinaryWriter(this.memoryStream, encoding);
		}

		public byte[] Close()
		{
			byte[] result = this.memoryStream.ToArray();
			this.binaryWriter.Close();
			this.memoryStream.Close();
			return this.encrypt ? Maki.SecurityHandler.Encrypt(result) : result;
		}


		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public void Write(bool value)
		{
			this.binaryWriter.Write(value);
		}

		public void Write(int value)
		{
			this.binaryWriter.Write(value);
		}

		public void Write(float value)
		{
			this.binaryWriter.Write(value);
		}

		public void Write(string value)
		{
			this.binaryWriter.Write(value);
		}


		/*
		============================================================================
		Array functions
		============================================================================
		*/
		public void Write(int[] array)
		{
			this.binaryWriter.Write(array.Length);
			for(int i = 0; i < array.Length; i++)
			{
				this.binaryWriter.Write(array[i]);
			}
		}

		public void Write(float[] array)
		{
			this.binaryWriter.Write(array.Length);
			for(int i = 0; i < array.Length; i++)
			{
				this.binaryWriter.Write(array[i]);
			}
		}

		public void Write(bool[] array)
		{
			this.binaryWriter.Write(array.Length);
			for(int i = 0; i < array.Length; i++)
			{
				this.binaryWriter.Write(array[i]);
			}
		}

		public void Write(string[] array)
		{
			this.binaryWriter.Write(array.Length);
			for(int i = 0; i < array.Length; i++)
			{
				this.binaryWriter.Write(array[i]);
			}
		}
	}
}
