
using UnityEngine;

namespace GamingIsLove.Makinom
{
	public class UILayersSettings : GenericAssetListSettings<UILayerAsset, UILayerSetting>
	{
		public UILayersSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "UI Layers"; }
		}
	}
}

