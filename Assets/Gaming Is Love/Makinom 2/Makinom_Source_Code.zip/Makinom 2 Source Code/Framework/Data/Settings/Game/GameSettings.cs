
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GameSettings : BaseSettings
	{
		// base settings
		[EditorFoldout("Base Settings", "Base game settings, e.g. start volumes, raycasting and random range check limits.")]
		[EditorHelp("Default Horizontal Plane", "Select the default horizontal plane (i.e. which axes are used as the ground/horizontal level):\n" +
			"- XZ: The X and Z axes define the ground, i.e. default 3D behaviour.\n" +
			"- XY: The X and Y axes define the ground, i.e. default 2D behaviour.", "")]
		public HorizontalPlaneType horizontalPlane = HorizontalPlaneType.XZ;

		[EditorHelp("Default Raycast Type", "Select the default type of raycast that is used:\n" +
			"- Only 3D: Only 3D raycasts are used.\n" +
			"- Only 2D: Only 2D raycasts are used.\n" +
			"- First 3D: Uses a 3D raycast first, if no object is found, a 2D raycast are used.\n" +
			"- First 2D: Uses a 2D raycast first, if no object is found, a 3D raycast is used.")]
		public RaycastType raycastType = RaycastType.First3D;

		[EditorHelp("Default Rounding", "Select the default rounding of float values (when their 'Rounding' setting uses 'Default'):\n" +
			"- None: No rounding.\n" +
			"- Ceil: The value will be rounded up (e.g. 14.2 will become 15).\n" +
			"- Floor: The value will be rounded down (e.g. 14.8 will become 14).\n" +
			"- Round: The value will be rounded to the nearest integer (e.g. 14.2 will become 14, 14.8 will become 15).", "")]
		public RoundingDefault defaultRounding = RoundingDefault.None;

		// random range
		[EditorSeparator]
		[EditorTitleLabel("Chance Settings")]
		[EditorHelp("Min. Random Range", "The minimum number used for calculating a random number " +
			"for chance checks (e.g. hit chance, counter chance, item drop chance, etc.).")]
		public float minRandomRange = 0;

		[EditorHelp("Max. Random Range", "The maximum number used for calculating a random number " +
			"for chance checks (e.g. hit chance, counter chance, item drop chance, etc.).")]
		public float maxRandomRange = 100;

		// visibility settings
		[EditorSeparator]
		[EditorTitleLabel("Visibility Settings")]
		public VisibilityCheck visibilityCheck = new VisibilityCheck();

		// data encryption
		[EditorSeparator]
		[EditorTitleLabel("Data Settings")]
		[EditorHelp("Data Format", "Select the format used to save settings data:\n" +
			"- Byte Array: The data is converted into a byte array. Fast save/load access, " +
			"but no version control (only per asset).\n" +
			"- XML String: The data is converted into an XML-based string. Slower save/load access, " +
			"but allows version control merging of assets.\n" +
			"\n" +
			"It's recommended to use 'Byte Array' for your built games to make use of the faster load times.")]
		public DataFile.SaveFormatType dataSaveFormat = DataFile.SaveFormatType.ByteArray;

		[EditorHelp("Encrypt Data", "The project data files will be encrypted.\n" +
			"If disabled, the files are saved in plain text.")]
		[EditorEndFoldout]
		public bool encryptData = false;


		// audio settings
		// start volumes
		[EditorHelp("Global Volume (0-1)", "Define the global volume (between 0 and 1) that will be used when Makinom is initialized.\n" +
			"The global volume is used to scale both music and sound volume.")]
		[EditorFoldout("Audio Settings", "Define the start volumes and initial sound/music channels.\n" +
			"Sound and music channels can be added at any time during a running game, these settings are only used to initialize them at the start of a game.")]
		[EditorTitleLabel("Start Volume Settings")]
		[EditorLimit(0.0f, 1.0f, isSlider = true)]
		public float startGlobalVolume = 1;

		[EditorHelp("Music Volume (0-1)", "Define the music volume (between 0 and 1) that will be used when Makinom is initialized.")]
		[EditorLimit(0.0f, 1.0f, isSlider = true)]
		public float startMusicVolume = 1;

		[EditorHelp("Sound Volume (0-1)", "Define the sound volume (between 0 and 1) that will be used when Makinom is initialized.")]
		[EditorLimit(0.0f, 1.0f, isSlider = true)]
		public float startSoundVolume = 1;

		// channels
		[EditorFoldout("Initial Sound Channels", "Define sound channels that will be initialized at the start of the game.")]
		[EditorEndFoldout]
		[EditorArray("Add Initial Sound Channel", "Add a sound channel that will be initialized at the start of the game.", "",
			"Remove", "Remove this initial sound channel", "", isCopy = true, isMove = true, foldout = true, foldoutText = new string[] {
				"Initial Sound Channel", "Define the initial setup of this sound channel.", ""
		})]
		public SoundChannelSetting[] soundChannel = new SoundChannelSetting[0];

		[EditorFoldout("Initial Music Channels", "Define music channels that will be initialized at the start of the game.")]
		[EditorEndFoldout(2)]
		[EditorArray("Add Initial Music Channel", "Add a music channel that will be initialized at the start of the game.", "",
			"Remove", "Remove this initial music channel", "", isCopy = true, isMove = true, foldout = true, foldoutText = new string[] {
				"Initial Music Channel", "Define the initial setup of this music channel.", ""
		})]
		public MusicChannelSetting[] musicChannel = new MusicChannelSetting[0];


		// default screen fade
		[EditorFoldout("Default Screen Fade", "The default screen fade settings for scene changes.\n" +
			"Can be overruled by individual 'Scene Changer' components, scene change nodes and save game settings.")]
		[EditorEndFoldout]
		public ScreenFadeSettings defaultScreenFade = new ScreenFadeSettings();


		// initial variables
		[EditorFoldout("Initial Variables",
			"Define variables that will be automatically set when starting the game.\n" +
			"The variables will be set when the game is initialized, " +
			"i.e. before the main menu - you can use this to set up custom options.\n" +
			"The variables will be kept when starting a new game - " +
			"but keep in mind that loading a saved game will clear all previous variables.")]
		[EditorEndFoldout]
		public SimpleVariableSetter<GameObjectSelection> initialVariables = new SimpleVariableSetter<GameObjectSelection>();


		// asset settings
		[EditorFoldout("Asset Settings", "Define base asset settings that are used in this project.\n" +
			"E.g. setting the default path for asset bundles.")]
		[EditorEndFoldout]
		public AssetSettings assetSettings = new AssetSettings();


		// unity functionality wrapper
		[EditorFoldout("Unity Wrapper", "You can optionally use custom functions when Makinom calls standard Unity functionality " +
			"(e.g. instantiating game objects).")]
		[EditorEndFoldout]
		public UnityWrapper unityWrapper = new UnityWrapper();


		// performance
		[EditorFoldout("Performance Settings", "Settings that can influence the performance of your game/application.\n" +
			"Creating lists and freeing their used memory can have an impact on your game's performance.\n" +
			"Makinom pools a defined amount of those lists and reuses them to increase performance.")]
		[EditorEndFoldout]
		public PerformanceSettings performance = new PerformanceSettings();

		public GameSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Game Settings"; }
		}


		/*
		============================================================================
		Chance/Random functions
		============================================================================
		*/
		public float GetRandom()
		{
			return UnityWrapper.Range(this.minRandomRange, this.maxRandomRange);
		}

		public float GetRandom(float minOffset, float maxOffset)
		{
			return UnityWrapper.Range(this.minRandomRange + minOffset, this.maxRandomRange + maxOffset);
		}

		public bool CheckRandom(float chance)
		{
			float rnd = this.GetRandom();
			return rnd > this.minRandomRange &&
				rnd <= chance;
		}
	}
}
