
using UnityEngine;
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using UnityEditorInternal;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public abstract class BaseEditorTab : BaseEditor
	{
		protected MakinomEditorWindow parent;

		protected string headerTitle = "";

		protected bool addSeparator = false;


		// list index
		protected int index = -1;

		protected int lastCount = 0;

		protected bool filterFoldout = false;

		protected bool editable = true;


		// searching
		protected SearchField settingsSearchField;


		// scroll views
		protected Vector2 listScroll = Vector2.zero;

		protected Vector2 generalSettingsScroll = Vector2.zero;

		protected Vector2 settingsScroll = Vector2.zero;


		// foldout limit
		protected int foldoutLimitChange = 0;

		protected GUIContent previousFoldoutLimit;

		protected string previousFoldoutHelp = "";

		protected GUIContent nextFoldoutLimit;

		protected string nextFoldoutHelp = "";

		protected string scrollToFoldout = "";

		protected List<string> foldoutLimitList = new List<string>();

		protected List<string> foldoutHelpList = new List<string>();

		protected GUIContent[] foldoutLimitContent = new GUIContent[0];


		// keep scroll position on index change
		protected string keepScrollPositionFoldout = "";

		protected string keepScrollPositionRootFoldout = "";

		protected float keepScrollPositionRootOffset = 0;

		protected float keepScrollPositionOffset = 0;


		// GUID field
		protected EditorGUIDField guidField = new EditorGUIDField();

		public override void GetLocalVariables(ref List<string> list, string searchvalue)
		{
			if(this.DisplayedSettings != null)
			{
				DataSerializer.GetVariables(this.DisplayedSettings, ref list, searchvalue);
			}
		}


		/*
		============================================================================
		Initialization functions
		============================================================================
		*/
		public virtual void Reloaded()
		{
			this.CancelTextEditing();
			this.DefaultSetup();
		}

		public virtual void BeforeSaving()
		{
			this.AcceptTextEditing();
		}

		public virtual void DefaultSetup()
		{

		}

		public override void Repaint()
		{
			if(this.parent != null)
			{
				this.parent.Repaint();
			}
		}

		public virtual MakinomEditorWindow Editor
		{
			get { return this.parent; }
		}

		public override bool BlockScroll
		{
			get { return this.blockScroll; }
			set
			{
				this.blockScroll = value;
				if(this.Editor != null)
				{
					this.Editor.blockScroll = value;
				}
			}
		}

		public virtual bool FocusSearchField()
		{
			if(this.settingsSearchField != null)
			{
				this.settingsSearchField.SetFocus();
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public virtual string Header
		{
			get { return this.headerTitle; }
			set { this.headerTitle = value; }
		}

		public virtual bool AddSeparator
		{
			get { return this.addSeparator; }
			set { this.addSeparator = value; }
		}

		public abstract string Name
		{
			get;
		}

		public abstract string HelpText
		{
			get;
		}

		public abstract string HelpInfo
		{
			get;
		}

		public virtual System.Type InstanceType
		{
			get { return this.Settings != null ? this.Settings.InstanceType : null; }
		}

		protected abstract BaseSettings Settings
		{
			get;
		}

		public virtual int Count
		{
			get { return this.Settings != null ? this.Settings.Count : 0; }
		}

		public virtual bool HasGeneralSettings
		{
			get { return this.Settings != null ? this.Settings.HasGeneralSettings : false; }
		}

		protected abstract IBaseData DisplayedSettings
		{
			get;
		}

		public virtual bool IsGeneralSetting
		{
			get { return this.HasGeneralSettings && this.index == -1; }
		}

		public virtual int Index
		{
			get { return this.index; }
			set
			{
				if(this.index != value)
				{
					if(this.index == -1 ||
						value == -1)
					{
						this.foldoutLimit = "";
					}
					else
					{
						this.RememberCurrentFoldoutScroll();
					}
					this.index = value;

					if(this.index >= this.Count)
					{
						this.index = this.Count - 1;
					}
					else if(this.HasGeneralSettings)
					{
						if(this.index < -1)
						{
							this.index = -1;
						}
					}
					else
					{
						if(this.index < 0)
						{
							this.index = 0;
						}
					}
				}
			}
		}

		public virtual string GeneralSettingsName
		{
			get { return "General Settings"; }
		}

		public virtual string GeneralSettingsHelpText
		{
			get { return ""; }
		}

		public virtual string GeneralSettingsHelpInfo
		{
			get { return ""; }
		}

		public virtual Vector2 SettingsScroll
		{
			get
			{
				if(this.IsGeneralSetting)
				{
					return this.generalSettingsScroll;
				}
				else
				{
					return this.settingsScroll;
				}
			}
			set
			{
				if(this.IsGeneralSetting)
				{
					this.generalSettingsScroll = value;
				}
				else
				{
					this.settingsScroll = value;
				}
			}
		}


		/*
		============================================================================
		Foldout functions
		============================================================================
		*/
		protected override string GetOpenFoldoutNames()
		{
			return this.Name + this.GetOpenFoldoutPath();
			/*if(Maki.EditorSettings.rememberFoldouts)
			{
				return this.Name + this.GetOpenFoldoutPath();
			}
			return "";*/
		}

		protected virtual float GetNextFoldoutPosition(int index)
		{
			for(int i = index; i < this.foldout.Count; i++)
			{
				if(i > this.currentFoldout)
				{
					break;
				}
				else if(this.foldout[i].Displayed)
				{
					return this.foldout[i].StartPosition;
				}
			}
			return -1;
		}

		public virtual void ShowFoldoutJumpList(float height)
		{
			this.ShowFoldoutLimitSelection(true);

			if(this.scrollToFoldout != "" &&
				Event.current.type == EventType.Repaint)
			{
				for(int i = 0; i < this.foldout.Count; i++)
				{
					if(this.foldout[i].Name == this.scrollToFoldout)
					{
						this.SettingsScroll = new Vector2(0, this.foldout[i].StartPosition);
						this.Editor.Repaint();
						break;
					}
				}
				this.scrollToFoldout = "";
			}

			bool highlighted = false;
			for(int i = 0; i < this.foldout.Count; i++)
			{
				if(i > this.currentFoldout)
				{
					break;
				}
				else if(this.foldout[i].Displayed &&
					this.foldout[i].Depth < Maki.EditorSettings.maxJumpListDepth)
				{
					if(Maki.EditorSettings.highlightVisibleJumpList)
					{
						if(Event.current.type == EventType.Layout)
						{
							this.foldout[i].CheckVisible(this.SettingsScroll.y, this.GetNextFoldoutPosition(i + 1), height);
						}

						if(this.foldout[i].Visible)
						{
							if(!highlighted)
							{
								highlighted = true;
								EditorGUILayout.BeginVertical(EditorContent.Instance.JumpListHighlightStyle);
							}
						}
						else if(highlighted)
						{
							highlighted = false;
							EditorGUILayout.EndVertical();
						}
					}

					if(this.foldout[i].Button())
					{
						if(Maki.EditorSettings.allowViewLimiting &&
							EditorApplication.timeSinceStartup - this.Editor.lastClickTime < 0.3)
						{
							for(int j = i; j >= 0; j--)
							{
								if(this.foldout[j].Depth == 0)
								{
									if(this.foldoutLimit == this.foldout[j].Name)
									{
										this.foldoutLimit = "";
										this.scrollToFoldout = this.foldout[j].Name;
									}
									else
									{
										this.foldoutLimit = this.foldout[j].Name;
										this.scrollToFoldout = this.foldout[i].Name;
									}
									break;
								}
							}
						}
						else
						{
							this.SettingsScroll = new Vector2(0, this.foldout[i].StartPosition - 10);
						}
						this.Editor.lastClickTime = EditorApplication.timeSinceStartup;
					}
				}
			}

			if(highlighted)
			{
				highlighted = false;
				EditorGUILayout.EndVertical();
			}
		}

		protected virtual void RememberCurrentFoldoutScroll()
		{
			if(Maki.EditorSettings.scrollFoldoutIndexChange)
			{
				int index = -1;
				int rootIndex = -1;
				float distance = Mathf.Infinity;
				float rootDistance = Mathf.Infinity;
				for(int i = 0; i < this.foldout.Count; i++)
				{
					if(this.foldout[i].Displayed)
					{
						float tmpDistance = Mathf.Abs(this.SettingsScroll.y - this.foldout[i].StartPosition);
						if(tmpDistance < distance)
						{
							distance = tmpDistance;
							index = i;
						}
						if(this.foldout[i].Depth == 0 &&
							tmpDistance < rootDistance)
						{
							rootDistance = tmpDistance;
							rootIndex = i;
						}
					}
				}
				if(index >= 0)
				{
					this.keepScrollPositionFoldout = this.foldout[index].Path;
					this.keepScrollPositionOffset = this.SettingsScroll.y - this.foldout[index].StartPosition;
				}
				if(rootIndex >= 0)
				{
					this.keepScrollPositionRootFoldout = this.foldout[rootIndex].Path;
					this.keepScrollPositionRootOffset = this.SettingsScroll.y - this.foldout[rootIndex].StartPosition;
				}
			}
		}

		protected virtual void UpdateFoldoutLimitList()
		{
			if(Event.current.type == EventType.Repaint)
			{
				if(this.searchScrollToFirst)
				{
					this.SearchScrollIndex = 0;
					this.searchScrollToFirst = false;
				}
				if(Maki.EditorSettings.scrollFoldoutIndexChange &&
					this.keepScrollPositionFoldout != "")
				{
					bool found = false;
					for(int i = 0; i < this.foldout.Count; i++)
					{
						if(i > this.currentFoldout)
						{
							break;
						}
						else if(this.foldout[i].Displayed &&
							this.foldout[i].Path == this.keepScrollPositionFoldout)
						{
							found = true;
							this.SettingsScroll = new Vector2(0, this.foldout[i].StartPosition + this.keepScrollPositionOffset);
							this.Editor.Repaint();
							break;
						}
					}

					if(!found &&
						this.keepScrollPositionRootFoldout != "")
					{
						for(int i = 0; i < this.foldout.Count; i++)
						{
							if(i > this.currentFoldout)
							{
								break;
							}
							else if(this.foldout[i].Displayed &&
								this.foldout[i].Depth == 0 &&
								this.foldout[i].Path == this.keepScrollPositionRootFoldout)
							{
								found = true;
								this.SettingsScroll = new Vector2(0, this.foldout[i].StartPosition + this.keepScrollPositionRootOffset);
								this.Editor.Repaint();
								break;
							}
						}
					}

					this.keepScrollPositionRootFoldout = "";
					this.keepScrollPositionFoldout = "";
					this.keepScrollPositionRootOffset = 0;
					this.keepScrollPositionOffset = 0;
				}
			}
			if(Maki.EditorSettings.allowViewLimiting &&
				Event.current.type == EventType.Layout)
			{
				this.foldoutLimitList.Clear();
				this.foldoutHelpList.Clear();
				this.foldoutLimitList.Add("< All Settings >");
				this.foldoutHelpList.Add("Show all settings.");
				for(int i = 0; i < this.foldout.Count; i++)
				{
					if(i > this.currentFoldout)
					{
						break;
					}
					else if(this.foldout[i].Depth == 0)
					{
						this.foldoutLimitList.Add(this.foldout[i].Name);
						this.foldoutHelpList.Add(this.foldout[i].HelpText);
					}
				}
				int check = this.foldoutLimitContent.Length;
				this.foldoutLimitContent = new GUIContent[this.foldoutLimitList.Count];
				for(int i = 0; i < this.foldoutLimitList.Count; i++)
				{
					this.foldoutLimitContent[i] = new GUIContent(this.foldoutLimitList[i], this.foldoutHelpList[i]);
				}
				if(check != this.foldoutLimitContent.Length &&
					this.keepScrollPositionFoldout == "")
				{
					this.Editor.Repaint();
				}
			}
		}

		public virtual void ShowFoldoutLimitSelection(bool show)
		{
			if(Maki.EditorSettings.allowViewLimiting)
			{
				int foldoutSelection = 0;
				bool found = false;

				for(int i = 0; i < this.foldoutLimitList.Count; i++)
				{
					if(this.foldoutLimit == this.foldoutLimitList[i])
					{
						foldoutSelection = i;
						found = true;
						break;
					}
				}

				int tmp = foldoutSelection;
				if(this.foldoutLimitChange == -1)
				{
					if(foldoutSelection > 0)
					{
						foldoutSelection--;
					}
					this.foldoutLimitChange = 0;
					tmp = -1;
				}
				else if(this.foldoutLimitChange == 1)
				{
					if(foldoutSelection < this.foldoutLimitList.Count - 1)
					{
						foldoutSelection++;
					}
					this.foldoutLimitChange = 0;
					tmp = -1;
				}
				if(!found &&
					this.foldoutLimit != "")
				{
					this.foldoutLimit = "";
					tmp = -1;
				}

				if(show)
				{
					foldoutSelection = EditorGUILayout.Popup(foldoutSelection, this.foldoutLimitList.ToArray(), EditorTool.W_EXPAND);
				}
				if(tmp != foldoutSelection)
				{
					if(foldoutSelection <= 0)
					{
						this.foldoutLimit = "";
						this.SettingsScroll = Vector2.zero;
					}
					else if(foldoutSelection < this.foldoutLimitList.Count)
					{
						this.foldoutLimit = this.foldoutLimitList[foldoutSelection];
						this.SettingsScroll = Vector2.zero;
					}
				}

				if(this.previousFoldoutLimit == null)
				{
					this.previousFoldoutLimit = new GUIContent(
						"", EditorContent.Instance.MoveUpIcon,
						"Navigate to the previous settings.");
				}
				if(foldoutSelection <= 1)
				{
					this.previousFoldoutLimit.text = "";
					this.previousFoldoutHelp = "";
				}
				else
				{
					this.previousFoldoutLimit.text = " " + this.foldoutLimitList[foldoutSelection - 1];
					this.previousFoldoutHelp = this.foldoutHelpList[foldoutSelection - 1];
				}

				if(this.nextFoldoutLimit == null)
				{
					this.nextFoldoutLimit = new GUIContent(
						"", EditorContent.Instance.MoveDownIcon,
						"Navigate to the next settings");
				}
				if(foldoutSelection >= this.foldoutLimitList.Count - 1)
				{
					this.nextFoldoutLimit.text = "";
					this.nextFoldoutHelp = "";
				}
				else
				{
					this.nextFoldoutLimit.text = " " + this.foldoutLimitList[foldoutSelection + 1];
					this.nextFoldoutHelp = this.foldoutHelpList[foldoutSelection + 1];
				}
			}
			else if(this.foldoutLimit != "")
			{
				this.foldoutLimit = "";
			}
		}


		/*
		============================================================================
		List display
		============================================================================
		*/
		public virtual void ListReordered(int oldIndex, int newIndex)
		{

		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		protected string rememberFoldoutLimit = "";

		public virtual void BeforeTab()
		{
			if(this.foldout.Count == 0 &&
				this.foldoutLimit != "")
			{
				this.rememberFoldoutLimit = this.foldoutLimit;
				this.foldoutLimit = "";
			}
		}

		public virtual void AfterTab()
		{
			if(Event.current.type == EventType.Repaint &&
				this.foldout.Count > 0 &&
				this.rememberFoldoutLimit != "")
			{
				this.foldoutLimit = this.rememberFoldoutLimit;
				this.rememberFoldoutLimit = "";
				this.parent.Repaint();
			}
		}

		public virtual void ShowTab()
		{
			this.ClearShow();

			EditorGUILayout.BeginHorizontal();

			this.BeforeSettings();

			EditorGUILayout.BeginVertical();
			this.ShowSearchSettings();
			this.BeforeScrollView();
			this.SettingsScroll = EditorGUILayout.BeginScrollView(this.SettingsScroll);
			EditorGUI.BeginDisabledGroup(!this.editable);
			this.ShowSettings();
			this.CloseAllFoldouts();
			EditorGUI.EndDisabledGroup();
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndScrollView();
			this.AfterScrollView();
			EditorGUILayout.EndVertical();

			this.AfterSettings();

			EditorGUILayout.EndHorizontal();
		}

		public virtual void BeforeSettings()
		{

		}

		public virtual void BeforeScrollView()
		{
			if(Maki.EditorSettings.allowViewLimiting &&
				Maki.EditorSettings.viewLimitSettingsButtons)
			{
				if(this.foldoutLimit != "")
				{
					if(this.previousFoldoutLimit.text == "")
					{
						if(EditorTool.ShowButton(EditorContent.Instance.AllFoldouts,
							"Shows all settings.", "", EditorTool.W_EXPAND))
						{
							this.foldoutLimitChange = -1;
						}
					}
					else if(EditorTool.ShowButton(this.previousFoldoutLimit,
						this.previousFoldoutHelp, "", EditorTool.W_EXPAND))
					{
						this.foldoutLimitChange = -1;
					}
				}
			}
		}

		public virtual void ShowSettings()
		{
			IBaseData settings = this.DisplayedSettings;
			if(settings != null)
			{
				this.guidField.Edit(settings as BaseIndexData, this);
				EditorAutomation.Automate(settings, this);
			}
		}

		public virtual void AfterScrollView()
		{
			if(Maki.EditorSettings.allowViewLimiting &&
				Maki.EditorSettings.viewLimitSettingsButtons)
			{
				if(this.foldoutLimit != "")
				{
					if(this.nextFoldoutLimit.text != "" &&
						EditorTool.ShowButton(this.nextFoldoutLimit,
							this.nextFoldoutHelp, "", EditorTool.W_EXPAND))
					{
						this.foldoutLimitChange = 1;
					}
				}
				else if(EditorTool.ShowButton(EditorContent.Instance.LimitFoldout,
					"Limits the view to a single foldout.", "", EditorTool.W_EXPAND))
				{
					this.foldoutLimitChange = 1;
				}
			}
		}

		public virtual void AfterSettings()
		{
			this.UpdateFoldoutLimitList();

			if(Maki.EditorSettings.showJumpList)
			{
				this.Editor.ShowFoldoutJumpList(true);
			}
			else
			{
				this.ShowFoldoutLimitSelection(false);
			}
		}

		public virtual void ShowAfterEditor()
		{

		}


		/*
		============================================================================
		Search
		============================================================================
		*/
		protected virtual int SearchScrollIndex
		{
			get { return this.searchScrollIndex; }
			set
			{
				this.searchScrollIndex = value;
				if(this.searchScrollIndex < 0)
				{
					this.searchScrollIndex = this.searchScrollPositions.Count - 1;
				}
				else if(this.searchScrollIndex >= this.searchScrollPositions.Count)
				{
					this.searchScrollIndex = 0;
				}
				if(this.searchScrollIndex >= 0 &&
					this.searchScrollIndex < this.searchScrollPositions.Count)
				{
					this.SettingsScroll = new Vector2(0, this.searchScrollPositions[this.searchScrollIndex] - 20);
					this.Editor.Repaint();
				}
			}
		}

		public virtual void ShowSearchSettings()
		{
			if(this.settingsSearchField == null)
			{
				this.settingsSearchField = new SearchField();
			}

			EditorGUILayout.BeginVertical(EditorContent.Instance.SearchBoxStyle, GUILayout.Height(24));
			EditorGUILayout.BeginHorizontal();

			// search field
			EditorGUILayout.BeginVertical(EditorStyles.label, EditorTool.W_EXPAND);
			GUILayout.FlexibleSpace();

			string tmpSearch = this.searchSettings;
			this.searchSettings = this.settingsSearchField.OnGUI(this.searchSettings, EditorTool.W_EXPAND);

			GUILayout.FlexibleSpace();
			EditorGUILayout.EndVertical();
			EditorTool.CheckHelpText("Search Settings", "Search settings in this tab.", "");

			if(this.searchSettings != tmpSearch)
			{
				this.UpdateSearch();
			}

			// buttons
			EditorGUILayout.BeginVertical();
			GUILayout.FlexibleSpace();
			EditorGUILayout.BeginHorizontal();

			// search navigation
			if(this.searchSettings.Length >= 3)
			{
				if(Event.current.type == EventType.Repaint &&
					this.searchScrollLastCount != this.searchScrollPositions.Count)
				{
					this.Repaint();
				}
				if(Event.current.type == EventType.KeyDown &&
					Event.current.keyCode == KeyCode.F3 &&
					!Event.current.control && !Event.current.command && !Event.current.alt)
				{
					if(Event.current.shift)
					{
						this.SearchScrollIndex--;
					}
					else
					{
						this.SearchScrollIndex++;
					}
				}

				if(this.searchScrollLastCount > 0)
				{
					GUILayout.Label((this.searchScrollIndex + 1) + "/" + this.searchScrollLastCount,
						EditorContent.Instance.SearchFoundLabelStyle);
				}
				else
				{
					GUILayout.Label("0/0", EditorContent.Instance.SearchFoundLabelStyle);
				}

				// previous
				if(EditorTool.ShowButton2(new GUIContent(EditorContent.Instance.SearchPreviousIcon, "Previous highlighed setting."),
					"Previous highlighed setting.", "", EditorStyles.miniButtonLeft, EditorTool.WIDTH_25, EditorTool.HEIGHT_18))
				{
					this.SearchScrollIndex--;
				}
				// next
				if(EditorTool.ShowButton2(new GUIContent(EditorContent.Instance.SearchNextIcon, "Next highlighed setting."),
					"Next highlighed setting.", "", EditorStyles.miniButtonRight, EditorTool.WIDTH_25, EditorTool.HEIGHT_18))
				{
					this.SearchScrollIndex++;
				}
			}

			// close/open foldouts
			if(EditorTool.ShowButton2(new GUIContent(EditorContent.Instance.CloseFoldoutsIcon, "Close all foldouts."),
				"Close all foldouts.", "", EditorStyles.miniButtonLeft, EditorTool.WIDTH_25, EditorTool.HEIGHT_18))
			{
				this.ExpandFoldouts(false);
			}
			if(EditorTool.ShowButton2(new GUIContent(EditorContent.Instance.OpenFoldoutsIcon, "Open all foldouts."),
				"Open all foldouts.", "", EditorStyles.miniButtonRight, EditorTool.WIDTH_25, EditorTool.HEIGHT_18))
			{
				this.ExpandFoldouts(true);
			}

			// foldout buttons button
			if(Maki.EditorSettings.allowViewLimiting)
			{
				EditorTool.BeginSetting("Show Foldout Buttons", false);
				Maki.EditorSettings.viewLimitSearchBarButtons = GUILayout.Toggle(Maki.EditorSettings.viewLimitSearchBarButtons,
					new GUIContent(EditorContent.Instance.FoldoutButtonsIcon, "Show Foldout Buttons"),
					EditorStyles.miniButtonLeft, EditorTool.WIDTH_25, EditorTool.HEIGHT_18);
				EditorTool.CheckHelpText("Show Foldout Buttons", "Display the view limit buttons for root foldouts below the search bar.", "");

				// jump list button
				EditorTool.BeginSetting("Show Jump List", false);
				Maki.EditorSettings.showJumpList = GUILayout.Toggle(Maki.EditorSettings.showJumpList,
					new GUIContent(EditorContent.Instance.ListIcon, "Show jump list"),
					EditorStyles.miniButtonRight, EditorTool.WIDTH_25, EditorTool.HEIGHT_18);
				EditorTool.CheckHelpText("Show Jump List", "Display the foldout quick jump list.", "");
			}
			else
			{
				// jump list button
				EditorTool.BeginSetting("Show Jump List", false);
				Maki.EditorSettings.showJumpList = GUILayout.Toggle(Maki.EditorSettings.showJumpList,
					new GUIContent(EditorContent.Instance.ListIcon, "Show jump list"),
					"button", EditorTool.WIDTH_30, EditorTool.HEIGHT_18);
				EditorTool.CheckHelpText("Show Jump List", "Display the foldout quick jump list.", "");
			}

			EditorGUILayout.EndHorizontal();
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndVertical();

			EditorGUILayout.EndHorizontal();
			this.ShowSearchBarFoldoutButtons();
			this.ShowSearchBarExtension();
			EditorGUILayout.EndVertical();
		}

		protected virtual bool EnableSearchBarFoldoutButtons
		{
			get { return true; }
		}

		protected virtual void ShowSearchBarFoldoutButtons()
		{
			if(Maki.EditorSettings.allowViewLimiting &&
				Maki.EditorSettings.viewLimitSearchBarButtons &&
				this.EnableSearchBarFoldoutButtons)
			{
				int foldoutSelection = 0;

				for(int i = 0; i < this.foldoutLimitContent.Length; i++)
				{
					if(this.foldoutLimit == this.foldoutLimitContent[i].text)
					{
						foldoutSelection = i;
						break;
					}
				}

				EditorGUILayout.BeginVertical();
				EditorGUILayout.BeginHorizontal();

				int tmp = foldoutSelection;
				EditorTool.SelectionGrid("FoldoutGridSearchbar", ref foldoutSelection, this.foldoutLimitContent, 5);

				if(tmp != foldoutSelection)
				{
					if(foldoutSelection <= 0)
					{
						this.foldoutLimit = "";
						this.SettingsScroll = Vector2.zero;
					}
					else if(foldoutSelection < this.foldoutLimitContent.Length)
					{
						this.foldoutLimit = this.foldoutLimitContent[foldoutSelection].text;
						this.SettingsScroll = Vector2.zero;
					}
				}

				if(this.previousFoldoutLimit == null)
				{
					this.previousFoldoutLimit = new GUIContent(
						"", EditorContent.Instance.MoveUpIcon,
						"Navigate to the previous settings.");
				}
				if(foldoutSelection <= 1)
				{
					this.previousFoldoutLimit.text = "";
					this.previousFoldoutHelp = "";
				}
				else
				{
					this.previousFoldoutLimit.text = " " + this.foldoutLimitList[foldoutSelection - 1];
					this.previousFoldoutHelp = this.foldoutHelpList[foldoutSelection - 1];
				}

				if(this.nextFoldoutLimit == null)
				{
					this.nextFoldoutLimit = new GUIContent(
						"", EditorContent.Instance.MoveDownIcon,
						"Navigate to the next settings");
				}
				if(foldoutSelection >= this.foldoutLimitList.Count - 1)
				{
					this.nextFoldoutLimit.text = "";
					this.nextFoldoutHelp = "";
				}
				else
				{
					this.nextFoldoutLimit.text = " " + this.foldoutLimitList[foldoutSelection + 1];
					this.nextFoldoutHelp = this.foldoutHelpList[foldoutSelection + 1];
				}

				EditorGUILayout.EndHorizontal();
				EditorGUILayout.Separator();
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndVertical();
			}
		}

		protected virtual void ShowSearchBarExtension()
		{

		}
	}
}
