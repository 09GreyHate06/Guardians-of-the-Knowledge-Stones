﻿
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class UILayoutsTab : GenericAssetListTab<UILayoutAsset, UILayoutSetting>
	{
		public UILayoutsTab(MakinomEditorWindow parent) : base(parent)
		{
			Maki.UILayouts.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			Maki.UILayouts.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "UI Layouts"; }
		}

		public override string HelpText
		{
			get
			{
				return "UI layouts can be used to align UI boxes and HUDs.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/ui-system/ui-layouts/"; }
		}
	}
}

