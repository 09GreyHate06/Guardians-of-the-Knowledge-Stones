
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	public class ProjectSaveHandler
	{
		private MakinomEditorWindow editor;

		private bool close = false;

		private bool createBackup = true;

		private bool updateSchematics = true;

		private string schematicUpdateFolder = "";

		private bool updatePrefabs = false;

		private bool updateScenes = false;

		private bool[] sceneUpdate = new bool[0];

		private Vector2 scroll = Vector2.zero;

		private Vector2 sceneScroll = Vector2.zero;


		// data changes
		private List<string> changes;

		private Dictionary<string, DataFile> fileList;

		private Dictionary<IMakinomGenericAsset, DataFile> dataFiles;

		private bool doSave = false;

		public ProjectSaveHandler(MakinomEditorWindow editor)
		{
			this.editor = editor;
			this.fileList = new Dictionary<string, DataFile>();
			this.dataFiles = new Dictionary<IMakinomGenericAsset, DataFile>();
			this.changes = Maki.Data.GetFileDifferences(Maki.Data.ProjectAsset,
				Maki.GameSettings.encryptData, Maki.GameSettings.dataSaveFormat, this.fileList);
			EditorDataHandler.Instance.GetFileDifferences(Maki.GameSettings.encryptData,
				Maki.GameSettings.dataSaveFormat, ref this.changes, ref this.dataFiles);

			MakinomEditorAsset editorAsset = MakinomAssetHelper.LoadEditorAsset();
			this.createBackup = editorAsset.CreateBackup;
			this.updateSchematics = editorAsset.UpdateSchematics;
			this.schematicUpdateFolder = editorAsset.SchematicUpdateFolder;
			this.updatePrefabs = editorAsset.UpdatePrefabs;
			this.updateScenes = editorAsset.UpdateScenes;
			this.sceneUpdate = editorAsset.SceneUpdate;
		}

		public bool HasChanges
		{
			get { return this.changes.Count > 0; }
		}

		public bool DoSave
		{
			get { return this.doSave; }
		}


		/*
		============================================================================
		GUI functions
		============================================================================
		*/
		public bool ShowGUI()
		{
			EditorGUILayout.BeginVertical(EditorContent.Instance.BoxSlimStyle);


			EditorGUILayout.BeginHorizontal();
			GUILayout.FlexibleSpace();

			EditorGUILayout.BeginVertical();
			EditorGUILayout.Separator();
			EditorTool.BoldLabel("The following data will change:");
			EditorGUILayout.Separator();

			this.scroll = EditorGUILayout.BeginScrollView(
				this.scroll, EditorTool.W_EXPAND,
				GUILayout.MinWidth(500), GUILayout.MaxHeight(250));

			GUIStyle guiStyle = new GUIStyle(EditorStyles.label);
			guiStyle.richText = true;
			for(int i = 0; i < this.changes.Count; i++)
			{
				GUILayout.Label(this.changes[i], guiStyle);
			}
			EditorGUILayout.EndScrollView();

			// options
			EditorGUILayout.Separator();
			EditorGUILayout.Separator();

			EditorGUILayout.BeginVertical(EditorContent.Instance.BoxStyle);

			if(Maki.Backups.numberOfBackups > 0)
			{
				this.createBackup = EditorGUILayout.Toggle("Create Backup", this.createBackup);
				if(this.createBackup)
				{
					EditorGUILayout.HelpBox("Creates a backup of the old data before saving any changes.\n" +
						"A backup is only created if the number of backups is set to 1 or higher in 'Editor > Backups'.\n" +
						"Please note that creating a backup will significantly increase the time needed for saving.",
						MessageType.Info);
				}
				else
				{
					EditorGUILayout.HelpBox("No backup will be created!",
						MessageType.Warning);
				}
			}

			EditorGUILayout.Separator();
			if(EditorDataHandler.Instance.HasDataChanges)
			{
				EditorTool.BoldLabel("Update Schematics");
				this.updateSchematics = EditorGUILayout.Toggle("Update Schematics", this.updateSchematics);
				if(this.updateSchematics)
				{
					EditorGUILayout.HelpBox("Update all schematic asset files found in this Unity project.\n" +
						"Updating can be optionally limited to a defined folder in the Assets path.",
						MessageType.Info);
					this.schematicUpdateFolder = EditorGUILayout.TextField("Folder (in Assets)", this.schematicUpdateFolder);
				}

				EditorGUILayout.Separator();
				EditorTool.BoldLabel("Update Prefabs");
				this.updatePrefabs = EditorGUILayout.Toggle("Update Prefabs", this.updatePrefabs);
				if(this.updatePrefabs)
				{
					EditorGUILayout.HelpBox("Update all prefabs in your project.",
						MessageType.Info);
				}

				EditorGUILayout.Separator();
				EditorTool.BoldLabel("Update Scenes");
				this.updateScenes = EditorGUILayout.Toggle("Update Scenes", this.updateScenes);
				if(this.updateScenes)
				{
					EditorGUILayout.HelpBox("Update all scenes added to the Unity build settings.",
						MessageType.Info);
					EditorGUILayout.HelpBox("This will close the currently opened scene.\n" +
						"Unsaved data will be lost!",
						MessageType.Warning);

					if(this.sceneUpdate.Length != EditorBuildSettings.scenes.Length)
					{
						bool[] tmp = this.sceneUpdate;
						this.sceneUpdate = new bool[EditorBuildSettings.scenes.Length];
						for(int i = 0; i < this.sceneUpdate.Length; i++)
						{
							if(i < tmp.Length)
							{
								this.sceneUpdate[i] = tmp[i];
							}
							else
							{
								this.sceneUpdate[i] = true;
							}
						}
					}

					// scene buttons
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.Button("Select All"))
					{
						for(int i = 0; i < this.sceneUpdate.Length; i++)
						{
							this.sceneUpdate[i] = true;
						}
					}
					if(EditorTool.Button("Select None"))
					{
						for(int i = 0; i < this.sceneUpdate.Length; i++)
						{
							this.sceneUpdate[i] = false;
						}
					}
					EditorGUILayout.EndHorizontal();

					// scene list
					this.sceneScroll = EditorGUILayout.BeginScrollView(
						this.sceneScroll, EditorTool.W_EXPAND);
					for(int i = 0; i < EditorBuildSettings.scenes.Length; i++)
					{
						if(EditorBuildSettings.scenes[i].enabled)
						{
							this.sceneUpdate[i] = EditorGUILayout.ToggleLeft(
								EditorBuildSettings.scenes[i].path, this.sceneUpdate[i]);
						}
					}
					EditorGUILayout.EndScrollView();
				}
			}
			else
			{
				EditorTool.BoldLabel("Update Schematics");
				EditorGUILayout.HelpBox("No update to schematic asset files required.",
					MessageType.Info);

				EditorGUILayout.Separator();
				EditorTool.BoldLabel("Update Prefabs");
				EditorGUILayout.HelpBox("No update to prefabs required.",
					MessageType.Info);

				EditorGUILayout.Separator();
				EditorTool.BoldLabel("Update Scenes");
				EditorGUILayout.HelpBox("No update to scenes required.",
					MessageType.Info);
			}
			EditorGUILayout.EndVertical();

			EditorGUILayout.EndVertical();
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();

			GUILayout.FlexibleSpace();

			EditorGUILayout.BeginHorizontal();
			GUI.SetNextControlName("Cancel");
			if(EditorTool.Button(EditorContent.Instance.CancelContent))
			{
				GUI.FocusControl("Cancel");
				this.close = true;
			}
			GUI.SetNextControlName("Save");
			if(EditorTool.Button(EditorContent.Instance.ConfirmContent))
			{
				GUI.FocusControl("Save");
				this.close = true;
				this.doSave = true;
			}
			EditorGUILayout.EndHorizontal();

			EditorGUILayout.EndVertical();

			return this.close;
		}


		/*
		============================================================================
		Save handling
		============================================================================
		*/
		public void SaveData()
		{
			if(this.createBackup)
			{
				MakinomAssetHelper.CreateBackup();
			}

			// save project and data assets
			string saveTime = System.DateTime.UtcNow.ToString();
			EditorDataHandler.Instance.SaveChanges(
				Maki.GameSettings.encryptData, Maki.GameSettings.dataSaveFormat,
				MakinomAssetHelper.DATA_PATH, false, saveTime, this.dataFiles);
			MakinomAssetHelper.SaveProjectAsset(this.fileList, Maki.GameSettings.encryptData, false, saveTime);
			this.editor.checkBackups = true;
			try
			{
				EditorVariables.Instance.UpdateSettings(false);
			}
			catch(System.Exception ex)
			{
				Debug.LogWarning("Warning! An issue occured while searching for variables after saving.");
			}

			// update other data
			if(EditorDataHandler.Instance.HasDataChanges)
			{
				this.editor.UpdateEditorSchematic();
				if(this.updateScenes)
				{
					this.UpdateScenes();
				}
				if(this.updateSchematics)
				{
					MakinomAssetHelper.ChangeSavedSchematics(this.schematicUpdateFolder);
				}
				if(this.updatePrefabs)
				{
					this.UpdatePrefabs();
				}
			}

			// update editor asset
			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
			EditorVariables.Instance.SaveVariables(editorAsset);
			editorAsset.LastSaveFormat = Maki.GameSettings.dataSaveFormat;
			editorAsset.CreateBackup = this.createBackup;
			editorAsset.UpdateSchematics = this.updateSchematics;
			editorAsset.SchematicUpdateFolder = this.schematicUpdateFolder;
			editorAsset.UpdatePrefabs = this.updatePrefabs;
			editorAsset.UpdateScenes = this.updateScenes;
			editorAsset.SceneUpdate = this.sceneUpdate;

			// refresh asset database
			EditorUtility.SetDirty(editorAsset);
			AssetDatabase.SaveAssets();
			AssetDatabase.Refresh();

			// clear editor changes
			EditorDataHandler.Instance.ClearDataChanges();
		}


		/*
		============================================================================
		Prefab update handling
		============================================================================
		*/
		private void UpdatePrefabs()
		{
			try
			{
				List<GameObject> prefabs = MakinomAssetHelper.GetAllPrefabs();
				for(int i = 0; i < prefabs.Count; i++)
				{
					try
					{
						if(prefabs[i] != null)
						{
							MonoBehaviour[] behaviour = prefabs[i].GetComponentsInChildren<MonoBehaviour>();
							if(behaviour != null)
							{
								for(int j = 0; j < behaviour.Length; j++)
								{
									if(behaviour[j] != null)
									{
										FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(behaviour[j].GetType());
										for(int k = 0; k < field.Length; k++)
										{
											if(typeof(IBaseData).IsAssignableFrom(field[k].FieldType))
											{
												IBaseData tmp = (IBaseData)field[k].GetValue(behaviour[j]);
												if(EditorDataHandler.Instance.UseDataChanges(tmp))
												{
													EditorUtility.SetDirty(behaviour[j]);
												}
											}
										}
									}
								}
							}
						}
					}
					catch(System.Exception ex)
					{
						if(prefabs[i] != null)
						{
							Debug.LogWarning("Something happened while updating " + prefabs[i] +
								", this prefab maybe wasn't updated successfully.\n" +
								ex.Message + "\n" + ex.StackTrace);
						}
						else
						{
							Debug.LogWarning("Something happened while updating prefabs, " +
								"some prefabs maybe aren't updated successfully.\n" +
								ex.Message + "\n" + ex.StackTrace);
						}
					}
				}
			}
			catch(System.Exception ex)
			{
				Debug.LogWarning(ex.Message + ":\n" + ex.StackTrace);
			}
		}


		/*
		============================================================================
		Scene update handling
		============================================================================
		*/
		private void UpdateScenes()
		{
			// remember current scene
			string path = EditorSceneManager.GetActiveScene().path;

			for(int i = 0; i < EditorBuildSettings.scenes.Length; i++)
			{
				if(this.sceneUpdate[i] &&
					EditorBuildSettings.scenes[i].path != "")
				{
					this.UpdateScene(EditorBuildSettings.scenes[i].path);
				}
			}

			// open remembered scene
			EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
		}

		private void UpdateScene(string path)
		{
			try
			{
				EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
				bool changed = false;

#if Unity_2019
				MonoBehaviour[] behaviour = Object.FindObjectsOfType<MonoBehaviour>();
#else
				MonoBehaviour[] behaviour = Object.FindObjectsByType<MonoBehaviour>(FindObjectsSortMode.None);
#endif
				if(behaviour != null)
				{
					for(int j = 0; j < behaviour.Length; j++)
					{
						if(behaviour[j] != null)
						{
							FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(behaviour[j].GetType());
							for(int k = 0; k < field.Length; k++)
							{
								if(typeof(IBaseData).IsAssignableFrom(field[k].FieldType))
								{
									IBaseData tmp = (IBaseData)field[k].GetValue(behaviour[j]);
									if(EditorDataHandler.Instance.UseDataChanges(tmp))
									{
										EditorUtility.SetDirty(behaviour[j]);
										changed = true;
									}
								}
							}
						}
					}
				}

				if(changed)
				{
					EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
				}
			}
			catch(System.Exception ex)
			{
				Debug.LogWarning("Something happened while updating scene " + path +
					", this scene maybe wasn't updated successfully.\n" +
					ex.Message + "\n" + ex.StackTrace);
			}
		}
	}
}
