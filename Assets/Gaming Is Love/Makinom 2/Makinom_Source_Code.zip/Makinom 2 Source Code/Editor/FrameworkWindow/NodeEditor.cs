
using UnityEngine;
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public delegate BaseNode[] NodeChange(BaseNode node);

	public delegate NodeGroup[] NodeGroupChange(NodeGroup group);

	public delegate void AddContextMenuOption(List<ContextMenuPopup.Element> tree);

	public delegate string[] AddLayer();

	public class NodeEditor
	{
		private BaseEditorTab parent;

		// editor
		private bool markContextMenuCall = false;

		private int currentLayer = 0;

		private Vector2 nodeScroll = Vector2.zero;

		private bool isFirstFocus = true;


		// nodes
		private BaseNode realStartNode;

		private BaseNode startNode;

		private BaseNode newStartNode;

		private BaseNode[] nodes;

		private NodeGroup[] nodeGroups;

		private List<NodeGroup> groupOrder = new List<NodeGroup>();

		private string[] layers;

		private List<BaseNode> visited = new List<BaseNode>();


		// clipboard
		private List<EditorClipboard> clipboard;


		// change callbacks
		private NodeChange AddNode;

		private NodeChange RemoveNode;

		private NodeGroupChange AddNodeGroup;

		private NodeGroupChange RemoveNodeGroup;

		private AddLayer AddLayer;

		private AddContextMenuOption AddContextMenuOption;


		// node info data
		private System.Type baseNodeType;

		private Dictionary<System.Type, NodeInfo> nodeInfos;

		private System.Type gateType;

		private System.Type groupType;

		private NodeInfo groupNodeInfo;


		// interaction
		private List<BaseNode> selectedNode = new List<BaseNode>();

		private BaseNode focusedNode;

		private BaseNode slotIndexNode;

		private int selectedIndex = -1;

		private int connectionMode = 0;

		private bool connectionDragged = false;

		private bool draggingNode = false;

		private bool draggingGroup = false;

		private Vector2 dragStartPosition = Vector2.zero;

		private List<BaseNode> dragNodes;

		private List<Vector2> dragStartPositions;

		private bool mouseDown = false;

		private Vector2 lastClickPosition = Vector2.zero;

		private bool boxSelecting = false;

		private Rect boxSelectionRect = new Rect();


		// display
		private Vector2 contextPosition = Vector2.zero;


		// sizes
		private static int GRID_SIZE = 19;

		private static Vector2 NODE_START_POSITION = new Vector2(38, 38);

		private static Vector2 NODE_SPACING = new Vector2(37, 37);//56, 56);

		private static Vector2 NODE_SIZE = new Vector2(191, 20);

		private static Vector2 CONNECTION_BOX_SIZE = new Vector2(14, 21);

		private static Vector2 ENABLE_TOGGLE_SIZE = new Vector2(14, 14);

		private static float TOOLBAR_HEIGHT = 29;


		// grid
		private Grid grid = new Grid(NodeEditor.GRID_SIZE * 5, 5,
			Maki.EditorSettings.gridLineColor, Maki.EditorSettings.gridLineFullColor,
			Maki.EditorSettings.gridBackgroundColor);

		private Rect viewBounds;

		private Rect visibleArea;

		private Rect nodeArea;


		// node styles
		private GUIStyle headerStyle;

		private GUIStyle centerStyle;

		private GUIStyle bottomStyle;

		private GUIStyle headerFocusedStyle;

		private GUIStyle centerFocusedStyle;

		private GUIStyle bottomFocusedStyle;

		private GUIStyle connectedStyle;

		private GUIStyle notConnectedStyle;

		private GUIStyle boxSelectionStyle;

		private GUIStyle nodeGroupStyle;

		private GUIStyle nodeGroupFocusedStyle;

		private GUIStyle nodeDebugStyle;

		private Texture2D debugFillTexture;

		private Texture2D breakpointTexture;


		// toolbar
		// toggles
		private bool markRepaint = false;

		private bool showGrid = true;

		private bool snapToGrid = true;

		private bool colorizeNodes = true;

		private bool showEnableToggle = true;

		private bool mergeSingleSlot = true;

		public bool showSettings = true;

		private bool renameLayer = false;

		// zoom
		private float zoom = 1;

		private Vector2 zoomOffset = Vector2.zero;

		// search
		private SearchField searchField = new SearchField();

		private string search = "";

		private string[] searchSplit = null;


		// grid content
		protected GUIContent showSettingsContent = new GUIContent("Show Settings", "Show Settings");

		protected GUIContent showGridContent = new GUIContent("Show Grid", "Show Grid");

		protected GUIContent snapToGridContent = new GUIContent("Snap to Grid", "Snap to Grid");

		protected GUIContent colorizeNodesContent = new GUIContent("Colorize Nodes", "Colorize Nodes");

		protected GUIContent showEnableToggleContent = new GUIContent("Enable/Disable Node", "Enable/Disable Node");

		protected GUIContent mergeSingleSlotContent = new GUIContent("Merge Single Slot", "Merge Single Slot");

		protected GUIContent placeOnGridContent = new GUIContent("Place on Grid", "Place on Grid");

		// sort content
		protected GUIContent sortHorizontalContent = new GUIContent("Sort Horizontal", "Sort Horizontal");

		protected GUIContent sortVerticalContent = new GUIContent("Sort Vertical", "Sort Vertical");

		// node content
		protected GUIContent addNodeContent = new GUIContent("Add Node", "Add Node");

		protected GUIContent removeContent = new GUIContent("Remove Node", "Remove Node");

		protected GUIContent removeChainContent = new GUIContent("Remove Chain", "Remove Chain");

		protected GUIContent copyContent = new GUIContent("Copy", "Copy");

		protected GUIContent copyToClipboardContent = new GUIContent("Copy to Clipboard", "Copy to Clipboard");

		protected GUIContent pasteFromClipboardContent = new GUIContent("Paste from Clipboard", "Paste from Clipboard");

		protected GUIContent pasteSettingsContent = new GUIContent("Paste Settings", "Paste Settings");

		protected GUIContent swapNodesContent = new GUIContent("Swap Nodes", "Swap Nodes");

		// layer content
		protected GUIContent removeLayerContent = new GUIContent("Remove Layer", "Remove Layer");

		protected GUIContent renameLayerContent = new GUIContent("Rename Layer", "Rename Layer");

		public NodeEditor(BaseEditorTab parent, List<EditorClipboard> clipboard,
			NodeChange add, NodeChange remove, NodeGroupChange addGroup, NodeGroupChange removeGroup,
			AddLayer addLayer, AddContextMenuOption addContextMenuOption)
		{
			this.parent = parent;

			this.clipboard = clipboard;

			this.AddNode = add;
			this.RemoveNode = remove;
			this.AddNodeGroup = addGroup;
			this.RemoveNodeGroup = removeGroup;
			this.AddLayer = addLayer;
			this.AddContextMenuOption = addContextMenuOption;


			// toolbar
			this.showGrid = Maki.EditorSettings.showNodesGrid;
			this.snapToGrid = Maki.EditorSettings.nodesDragGrid;
			this.colorizeNodes = Maki.EditorSettings.colorizeNodeTypes;
			this.showEnableToggle = Maki.EditorSettings.showNodeEnableToggle;
			this.mergeSingleSlot = Maki.EditorSettings.mergeSingleSlot;
		}

		public void InitStyles()
		{
			// images
			System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();

			// show grid
			this.showSettingsContent.image = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Nodes.ShowSettings.png"),
				24, 24);
			// show grid
			this.showGridContent.image = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Nodes.ShowGrid.png"),
				24, 24);
			// snap to grid
			this.snapToGridContent.image = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Nodes.SnapToGrid.png"),
				24, 24);
			// colorize nodes
			this.colorizeNodesContent.image = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Nodes.ColorizeNodes.png"),
				24, 24);
			// enable toggle
			this.showEnableToggleContent.image = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Nodes.ShowEnableToggle.png"),
				24, 24);
			// short node mode
			this.mergeSingleSlotContent.image = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Nodes.MergeSingleSlot.png"),
				24, 24);
			// sort horizontal
			this.sortHorizontalContent.image = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Nodes.SortHorizontal.png"),
				24, 24);
			// sort vertical
			this.sortVerticalContent.image = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Nodes.SortVertical.png"),
				24, 24);
			// place on grid
			this.placeOnGridContent.image = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Nodes.PlaceOnGrid.png"),
				24, 24);
			// add
			this.addNodeContent.image = EditorContent.Instance.AddIcon;
			// remove
			this.removeContent.image = EditorContent.Instance.RemoveIcon;
			// remove chain
			this.removeChainContent.image = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Nodes.RemoveChain.png"),
				24, 24);
			// copy
			this.copyContent.image = EditorContent.Instance.CopyIcon;
			// copy to clipboard
			this.copyToClipboardContent.image = EditorContent.Instance.CopyToClipboardIcon;
			// paste from clipboard
			this.pasteFromClipboardContent.image = EditorContent.Instance.PasteFromClipboardIcon;
			// paste settings
			this.pasteSettingsContent.image = EditorContent.Instance.PasteSettingsIcon;
			// remove layer
			this.removeLayerContent.image = EditorContent.Instance.RemoveIcon;
			// rename layer
			this.renameLayerContent.image = EditorContent.Instance.EditIcon;
			// swap nodes
			this.swapNodesContent.image = EditorContent.Instance.SwapIcon;


			// header style
			this.headerStyle = new GUIStyle(EditorContent.Instance.NodeBoxStyle);
			this.headerStyle.wordWrap = false;
			this.headerStyle.clipping = TextClipping.Clip;
			this.headerStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_header.png"),
					22, 22);
			this.headerStyle.border = new RectOffset(10, 10, 10, 5);
			this.headerStyle.overflow = new RectOffset(4, 4, 4, 0);
			this.headerStyle.padding = new RectOffset(0, 0, 3, 0);
			this.headerStyle.alignment = TextAnchor.UpperCenter;
			this.headerStyle.fontStyle = FontStyle.Bold;
			this.headerStyle.fontSize = 10;
			this.headerStyle.normal.textColor = Color.white;

			this.headerFocusedStyle = new GUIStyle(this.headerStyle);
			this.headerFocusedStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_header_focused.png"),
					22, 22);


			// center style
			this.centerStyle = new GUIStyle(EditorContent.Instance.NodeBoxStyle);
			this.centerStyle.wordWrap = false;
			this.centerStyle.clipping = TextClipping.Clip;
			this.centerStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_center.png"),
					22, 20);
			this.centerStyle.border = new RectOffset(10, 10, 5, 5);
			this.centerStyle.overflow = new RectOffset(4, 4, 0, 0);
			this.centerStyle.padding.left = 7;
			this.centerStyle.padding.right = 8;
			this.centerStyle.alignment = TextAnchor.UpperLeft;
			this.centerStyle.fontStyle = FontStyle.Normal;

			this.centerFocusedStyle = new GUIStyle(this.centerStyle);
			this.centerFocusedStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_center_focused.png"),
					22, 20);

			// bottom style
			this.bottomStyle = new GUIStyle(EditorContent.Instance.NodeBoxStyle);
			this.bottomStyle.wordWrap = false;
			this.bottomStyle.clipping = TextClipping.Clip;
			this.bottomStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_bottom.png"),
					22, 23);
			this.bottomStyle.border = new RectOffset(10, 10, 5, 10);
			this.bottomStyle.overflow = new RectOffset(4, 4, 0, 4);
			this.bottomStyle.padding.left = 7;
			this.bottomStyle.padding.right = 8;
			this.bottomStyle.alignment = TextAnchor.UpperLeft;
			this.bottomStyle.fontStyle = FontStyle.Normal;

			this.bottomFocusedStyle = new GUIStyle(this.bottomStyle);
			this.bottomFocusedStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_bottom_focused.png"),
					22, 23);


			// connected styles
			this.connectedStyle = new GUIStyle(EditorContent.Instance.NodeBoxStyle);
			this.connectedStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_connected.png"),
					(int)NodeEditor.CONNECTION_BOX_SIZE.x, (int)NodeEditor.CONNECTION_BOX_SIZE.y);
			this.connectedStyle.border = new RectOffset(5, 5, 5, 5);

			// not connected styles
			this.notConnectedStyle = new GUIStyle(EditorContent.Instance.NodeBoxStyle);
			this.notConnectedStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_not_connected.png"),
					(int)NodeEditor.CONNECTION_BOX_SIZE.x, (int)NodeEditor.CONNECTION_BOX_SIZE.y);
			this.notConnectedStyle.border = new RectOffset(5, 5, 5, 5);

			// box selection style
			this.boxSelectionStyle = new GUIStyle(EditorContent.Instance.NodeBoxStyle);
			this.boxSelectionStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_box_selection.png"),
					16, 16);
			this.boxSelectionStyle.border = new RectOffset(2, 2, 2, 2);

			// node group style
			this.nodeGroupStyle = new GUIStyle(EditorContent.Instance.NodeBoxStyle);
			this.nodeGroupStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_group.png"),
					24, 24);
			this.nodeGroupStyle.border = new RectOffset(6, 6, 6, 6);
			this.nodeGroupStyle.overflow = new RectOffset(3, 5, 4, 4);
			this.nodeGroupStyle.padding = new RectOffset(3, 3, 3, 3);
			this.nodeGroupStyle.alignment = TextAnchor.UpperCenter;
			this.nodeGroupStyle.fontStyle = FontStyle.Bold;
			this.nodeGroupStyle.fontSize = 10;
			this.nodeGroupStyle.normal.textColor = Color.white;

			// focused node group style
			this.nodeGroupFocusedStyle = new GUIStyle(this.nodeGroupStyle);
			this.nodeGroupFocusedStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_group_focused.png"),
					24, 24);

			// node debug style
			this.nodeDebugStyle = new GUIStyle(EditorContent.Instance.NodeBoxStyle);
			this.nodeDebugStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_debug.png"),
					24, 24);
			this.nodeDebugStyle.border = new RectOffset(7, 7, 7, 7);
			this.nodeDebugStyle.overflow = new RectOffset(6, 6, 6, 7);

			this.breakpointTexture = EditorContent.LoadImage(
				assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Nodes.node_breakpoint.png"),
				20, 20);
		}

		public BaseNode NewStartNode
		{
			get { return this.newStartNode; }
			set { this.newStartNode = value; }
		}

		public void SetNodeInfos(System.Type baseNodeType, System.Type gateType)
		{
			this.baseNodeType = baseNodeType;
			this.nodeInfos = EditorAttributes.GetNodeInfos(baseNodeType);
			this.gateType = gateType;
			this.groupType = typeof(NodeGroup);
			this.groupNodeInfo = EditorAttributes.GetNodeInfo(this.groupType);
		}

		private Vector2 NodeScroll
		{
			get { return this.nodeScroll + this.zoomOffset; }
			set { this.nodeScroll = value - this.zoomOffset; }
		}

		public Vector2 RealNodeScroll
		{
			get { return this.nodeScroll; }
			set { this.nodeScroll = value; }
		}

		public Vector2 ZoomOffset
		{
			get { return this.zoomOffset; }
			set { this.zoomOffset = value; }
		}

		public int GetFocusedNodeIndex()
		{
			if(this.focusedNode != null &&
				this.nodes != null)
			{
				for(int i = 0; i < this.nodes.Length; i++)
				{
					if(this.nodes[i] == this.focusedNode)
					{
						return i;
					}
				}
			}
			return -1;
		}

		public virtual NodeInfo GetNodeInfo(System.Type nodeType)
		{
			if(this.groupType == nodeType)
			{
				return this.groupNodeInfo;
			}
			else
			{
				NodeInfo info = null;
				this.nodeInfos.TryGetValue(nodeType, out info);
				return info;
			}
		}


		/*
		============================================================================
		Notification functions
		============================================================================
		*/
		private void ResetNotifications()
		{
			PlayerPrefs.DeleteKey("GamingIsLove.Makinom.NodeEditor.ShowDragGroupNotification");
		}

		private void ShowDragGroupNotification()
		{
			if(this.nodeGroups.Length > 0 &&
				PlayerPrefs.GetInt("GamingIsLove.Makinom.NodeEditor.ShowDragGroupNotification", 0) == 0)
			{
				this.parent.Editor.ShowNotification(new GUIContent("Hold 'CTRL' to add or remove the dragged nodes/groups from a group."), 5);
				PlayerPrefs.SetInt("GamingIsLove.Makinom.NodeEditor.ShowDragGroupNotification", 1);
			}
		}


		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public List<BaseNode> Selected
		{
			get { return this.selectedNode; }
		}

		public List<string> SelectedName
		{
			get
			{
				if(this.IsNodeSelected)
				{
					List<string> list = new List<string>();

					for(int i = 0; i < this.selectedNode.Count; i++)
					{
						list.Add(this.selectedNode[i] == this.realStartNode ?
							"Settings" :
							EditorAttributes.GetTypeHelpText(this.selectedNode[i].GetType()).content.text);
					}

					return list;
				}
				return null;
			}
		}

		public bool IsNodeSelected
		{
			get { return this.selectedNode.Count > 0; }
		}

		public bool IsTypeSelected(System.Type type)
		{
			for(int i = 0; i < this.selectedNode.Count; i++)
			{
				if(this.selectedNode[i].GetType() == type)
				{
					return true;
				}
			}
			return false;
		}

		public bool IsTypeSelected(List<System.Type> type)
		{
			if(type != null)
			{
				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					for(int j = 0; j < type.Count; j++)
					{
						if(this.selectedNode[i].GetType() == type[j])
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public bool IsSelectedRemovable()
		{
			for(int i = 0; i < this.selectedNode.Count; i++)
			{
				if(!this.selectedNode[i].IsRemovable())
				{
					return false;
				}
			}
			return true;
		}

		public void SelectNode(BaseNode node, bool add, int slotIndex)
		{
			/*if(this.realStartNode == node ||
				node.GetType() == this.gateType ||
				this.selectedNode.Contains(this.realStartNode) ||
				this.IsTypeSelected(this.gateType))
			{
				add = false;
			}*/

			this.focusedNode = node;
			this.slotIndexNode = node;
			this.selectedIndex = slotIndex;

			if(add)
			{
				if(!this.selectedNode.Contains(node))
				{
					this.parent.FoldoutLimit = "";
					this.selectedNode.Add(node);
				}
			}
			else if(this.selectedNode.Count != 1 ||
				!this.selectedNode.Contains(node))
			{
				this.parent.FoldoutLimit = "";
				this.selectedNode.Clear();
				this.selectedNode.Add(node);
			}
		}

		public void ClearSelected()
		{
			this.parent.FoldoutLimit = "";
			this.selectedNode.Clear();
			this.focusedNode = null;
			this.slotIndexNode = null;
			this.selectedIndex = -1;
		}

		public int Layer
		{
			get { return this.currentLayer; }
			set
			{
				this.currentLayer = value;
				this.isFirstFocus = true;
			}
		}

		public bool FirstFocus
		{
			get { return this.isFirstFocus; }
			set { this.isFirstFocus = value; }
		}

		public void FocusSelectedNode()
		{
			int count = 0;
			Vector2 min = Vector2.zero;
			Vector2 max = Vector2.zero;
			Vector2 position = Vector2.zero;
			if(this.IsNodeSelected)
			{
				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					if(this.selectedNode[i].IsOnLayer(this.currentLayer))
					{
						count++;
						Vector2 tmpPos = this.selectedNode[i].GetPosition(this.currentLayer);
						position += tmpPos;
						if(i == 0)
						{
							min = tmpPos;
							max = tmpPos;
							max.x += NodeEditor.NODE_SIZE.x;
							max.y += NodeEditor.NODE_SIZE.y * this.selectedNode[i].GetNextCount();
						}
						else
						{
							if(min.x > tmpPos.x)
							{
								min.x = tmpPos.x;
							}
							if(min.y > tmpPos.y)
							{
								min.y = tmpPos.y;
							}

							tmpPos.x += NodeEditor.NODE_SIZE.x;
							tmpPos.y += NodeEditor.NODE_SIZE.y * this.selectedNode[i].GetNextCount();
							if(max.x < tmpPos.x)
							{
								max.x = tmpPos.x;
							}
							if(max.y < tmpPos.y)
							{
								max.y = tmpPos.y;
							}
						}
					}
				}
			}
			if(count == 0 &&
				this.realStartNode != null &&
				this.realStartNode.IsOnLayer(this.currentLayer))
			{
				count++;
				Vector2 tmpPos = this.realStartNode.GetPosition(this.currentLayer);
				position = tmpPos;
				min = tmpPos;
				max = tmpPos;
				max.x += NodeEditor.NODE_SIZE.x;
				max.y += NodeEditor.NODE_SIZE.y * this.realStartNode.GetNextCount();
			}
			if(count == 0)
			{
				for(int i = 0; i < this.nodes.Length; i++)
				{
					if(this.nodes[i].IsOnLayer(this.currentLayer))
					{
						count++;
						Vector2 tmpPos = this.nodes[i].GetPosition(this.currentLayer);
						position = tmpPos;

						min = tmpPos;
						max = tmpPos;
						max.x += NodeEditor.NODE_SIZE.x;
						max.y += NodeEditor.NODE_SIZE.y * this.nodes[i].GetNextCount() + 1;
						break;
					}
				}
			}
			if(count > 0)
			{
				position /= count;
				position *= -1;
				max.y += NodeEditor.NODE_SIZE.y;
				min *= -1;
				max *= -1;
				TextAnchor anchor = this.isFirstFocus ?
					Maki.EditorSettings.nodeInitialAnchor :
					Maki.EditorSettings.nodeFocusAnchor;

				// x
				if(TextAnchor.UpperLeft == anchor ||
					TextAnchor.MiddleLeft == anchor ||
					TextAnchor.LowerLeft == anchor)
				{
					position.x = min.x + NodeEditor.GRID_SIZE * 2;
				}
				else if(TextAnchor.UpperCenter == anchor ||
					TextAnchor.MiddleCenter == anchor ||
					TextAnchor.LowerCenter == anchor)
				{
					position.x += (this.viewBounds.width - NodeEditor.NODE_SIZE.x) / 2;
				}
				else if(TextAnchor.UpperRight == anchor ||
					TextAnchor.MiddleRight == anchor ||
					TextAnchor.LowerRight == anchor)
				{
					position.x = max.x + this.viewBounds.width - NodeEditor.GRID_SIZE * 2;
				}

				// y
				if(TextAnchor.UpperLeft == anchor ||
					TextAnchor.UpperCenter == anchor ||
					TextAnchor.UpperRight == anchor)
				{
					position.y = min.y + NodeEditor.GRID_SIZE * 2;
				}
				else if(TextAnchor.MiddleLeft == anchor ||
					TextAnchor.MiddleCenter == anchor ||
					TextAnchor.MiddleRight == anchor)
				{
					position.y += (this.viewBounds.height - NodeEditor.NODE_SIZE.y) / 2;
				}
				else if(TextAnchor.LowerLeft == anchor ||
					TextAnchor.LowerCenter == anchor ||
					TextAnchor.LowerRight == anchor)
				{
					position.y = max.y + this.viewBounds.height - NodeEditor.GRID_SIZE * 2;
				}

				this.NodeScroll = position;
				this.parent.Editor.Repaint();
			}
		}

		public void FocusNode(BaseNode node)
		{
			if(node != null &&
				node.IsOnLayer(this.currentLayer))
			{
				Vector2 position = node.GetPosition(this.currentLayer);
				position *= -1;
				position.x += (this.viewBounds.width - NodeEditor.NODE_SIZE.x) / 2;
				position.y += (this.viewBounds.height - NodeEditor.NODE_SIZE.y) / 2;
				this.NodeScroll = position;
				this.parent.Editor.Repaint();
			}
		}


		/*
		============================================================================
		Sort functions
		============================================================================
		*/
		private void SortHorizontal(List<BaseNode> tmp, BaseNode node, ref Vector2 position, ref int highest)
		{
			if(node != null && !tmp.Contains(node) &&
				node.IsOnLayer(this.currentLayer))
			{
				tmp.Add(node);

				node.SetPosition(this.currentLayer, position);

				int nextCount = node.GetType() == this.gateType && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();

				if(highest < nextCount)
				{
					highest = nextCount;
				}

				int count = 0;
				for(int i = 0; i < nextCount; i++)
				{
					int next = node.GetNext(i);
					if(next >= 0 && next < this.nodes.Length)
					{
						position.x = node.GetPosition(this.currentLayer).x +
							NodeEditor.NODE_SIZE.x + NodeEditor.NODE_SPACING.x;
						if(count > 0)
						{
							position.y += ((highest + 1) * (NodeEditor.NODE_SIZE.y - 1)) +
								NodeEditor.NODE_SIZE.y + NodeEditor.NODE_SPACING.y;
							highest = 0;
						}
						this.SortHorizontal(tmp, this.nodes[next], ref position, ref highest);
						count++;
					}
				}
			}
		}

		private void SortHorizontal(List<BaseNode> onlySort, List<BaseNode> tmp, BaseNode node, ref Vector2 position, ref int highest)
		{
			if(node != null && !tmp.Contains(node) &&
				onlySort.Contains(node) &&
				node.IsOnLayer(this.currentLayer))
			{
				tmp.Add(node);

				node.SetPosition(this.currentLayer, position);

				int nextCount = node.GetType() == this.gateType && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();

				if(highest < nextCount)
				{
					highest = nextCount;
				}

				int count = 0;
				for(int i = 0; i < nextCount; i++)
				{
					int next = node.GetNext(i);
					if(next >= 0 && next < this.nodes.Length)
					{
						position.x = node.GetPosition(this.currentLayer).x +
							NodeEditor.NODE_SIZE.x + NodeEditor.NODE_SPACING.x;
						if(count > 0)
						{
							position.y += ((highest + 1) * (NodeEditor.NODE_SIZE.y - 1)) +
								NodeEditor.NODE_SIZE.y + NodeEditor.NODE_SPACING.y;
							highest = 0;
						}
						this.SortHorizontal(onlySort, tmp, this.nodes[next], ref position, ref highest);
						count++;
					}
				}
			}
		}

		private void SortVertical(List<BaseNode> tmp, BaseNode node, ref Vector2 position)
		{
			if(node != null && !tmp.Contains(node) &&
				node.IsOnLayer(this.currentLayer))
			{
				tmp.Add(node);

				node.SetPosition(this.currentLayer, position);

				int count = 0;
				int nextCount = node.GetType() == this.gateType && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();

				for(int i = 0; i < nextCount; i++)
				{
					if(node.GetNext(i) >= 0 && node.GetNext(i) < this.nodes.Length)
					{
						position.y = node.GetPosition(this.currentLayer).y +
							((nextCount + 1) * (NodeEditor.NODE_SIZE.y - 1)) +
							NodeEditor.NODE_SIZE.y + NodeEditor.NODE_SPACING.y;
						if(count > 0)
						{
							position.x += NodeEditor.NODE_SIZE.x + NodeEditor.NODE_SPACING.x;
						}
						this.SortVertical(tmp, this.nodes[node.GetNext(i)], ref position);
						count++;
					}
				}
			}
		}

		private void PlaceOnGrid(List<BaseNode> tmp, BaseNode node)
		{
			if(node != null && !tmp.Contains(node) &&
				node.IsOnLayer(this.currentLayer))
			{
				tmp.Add(node);

				this.SnapToGrid(node);
				int nextCount = node.GetType() == this.gateType && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();
				for(int i = 0; i < nextCount; i++)
				{
					if(node.GetNext(i) >= 0 && node.GetNext(i) < this.nodes.Length)
					{
						this.PlaceOnGrid(tmp, this.nodes[node.GetNext(i)]);
					}
				}
			}
		}

		public void UpdateVisit()
		{
			this.visited = new List<BaseNode>();
			this.VisitNode(this.startNode);
		}

		private void VisitNode(BaseNode node)
		{
			if(node != null && !this.visited.Contains(node))
			{
				this.visited.Add(node);
				int nextCount = node.GetNextCount();
				for(int i = 0; i < nextCount; i++)
				{
					if(node.GetNext(i) >= 0 && node.GetNext(i) < this.nodes.Length)
					{
						this.VisitNode(this.nodes[node.GetNext(i)]);
					}
				}
			}
		}


		/*
		============================================================================
		Toolbar functions
		============================================================================
		*/
		public virtual void FocusSearchField()
		{
			this.searchField.SetFocus();
			this.markRepaint = true;
			if(EventType.Repaint != Event.current.type &&
				EventType.Layout != Event.current.type)
			{
				Event.current.Use();
			}
		}

		public void ShowToolbar(ref string[] layers)
		{
			bool isGateSelected = this.IsTypeSelected(this.gateType);
			bool isGroupSelected = this.IsTypeSelected(this.groupType);
			bool isStartSelected = this.selectedNode.Contains(this.realStartNode);

			// begin toolbar
			// control keys
			if(EditorContent.CTRL_F)
			{
				this.FocusSearchField();
			}
			else if(EditorContent.CTRL_D &&
				this.IsNodeSelected &&
				!isStartSelected &&
				!isGateSelected &&
				!isGroupSelected &&
				string.IsNullOrEmpty(GUI.GetNameOfFocusedControl()))
			{
				this.ContextCopyNode();
				if(EventType.Repaint != Event.current.type &&
					EventType.Layout != Event.current.type)
				{
					Event.current.Use();
				}
			}
			else if(EditorContent.CTRL_C &&
				this.IsNodeSelected &&
				!isStartSelected &&
				!isGateSelected &&
				!isGroupSelected &&
				string.IsNullOrEmpty(GUI.GetNameOfFocusedControl()))
			{
				this.ContextCopyNodeToClipboard();
				if(EventType.Repaint != Event.current.type &&
					EventType.Layout != Event.current.type)
				{
					Event.current.Use();
				}
			}
			else if(EditorContent.CTRL_V &&
				this.clipboard.Count > 0 &&
				string.IsNullOrEmpty(GUI.GetNameOfFocusedControl()))
			{
				this.contextPosition = Event.current.mousePosition;
				this.contextPosition.y -= this.viewBounds.y;
				this.ContextPasteNodeFromClipboard();
				this.parent.Editor.Repaint();
				if(EventType.Repaint != Event.current.type &&
					EventType.Layout != Event.current.type)
				{
					Event.current.Use();
				}
			}
			else if(EditorContent.CTRL_X &&
				this.IsNodeSelected && this.IsSelectedRemovable() &&
				!isStartSelected &&
				!isGateSelected &&
				!isGroupSelected &&
				string.IsNullOrEmpty(GUI.GetNameOfFocusedControl()))
			{
				this.ContextCopyNodeToClipboard();
				this.ContextRemoveNode();
				if(EventType.Repaint != Event.current.type &&
					EventType.Layout != Event.current.type)
				{
					Event.current.Use();
				}
			}
			else if(Event.current.type == EventType.KeyDown &&
				Event.current.keyCode == KeyCode.G &&
				Event.current.control)
			{
				if(this.CheckClick(new Rect(0, 0, this.viewBounds.width, this.viewBounds.height)))
				{
					this.contextPosition = Event.current.mousePosition;
				}
				else
				{
					this.contextPosition.x = 128;
					this.contextPosition.y = 128;
				}
				this.ContextAddNodeGroup();
				this.parent.Editor.Repaint();
			}

			EditorGUILayout.BeginHorizontal(EditorContent.Instance.BoxSlimStyle, GUILayout.Height(NodeEditor.TOOLBAR_HEIGHT));

			// grid buttons
			bool checkChange = this.showSettings;
			EditorTool.ToggleButtonNoName(this.showSettingsContent,
				ref this.showSettings, "Display the node's settings.", "");
			if(checkChange != this.showSettings)
			{
				this.markRepaint = true;
			}
			EditorTool.ToggleButtonNoName(this.showGridContent,
				ref this.showGrid, "Display the background grid.", "");
			EditorTool.ToggleButtonNoName(this.snapToGridContent,
				ref this.snapToGrid, "Place the nodes on the grid.", "");
			EditorTool.ToggleButtonNoName(this.colorizeNodesContent,
				ref this.colorizeNodes, "Colorize the different node types.", "");
			EditorTool.ToggleButtonNoName(this.showEnableToggleContent,
				ref this.showEnableToggle, "Show the enable/disable toggle on the nodes.", "");
			EditorTool.ToggleButtonNoName(this.mergeSingleSlotContent,
				ref this.mergeSingleSlot, "The 'Next' slot of single-slot nodes will be part of the info area.", "");

			EditorGUILayout.Separator();

			// sort
			if(EditorTool.ShowButtonNoNameNoWidth(this.sortHorizontalContent,
				"Automatically aligns the nodes horizontally.\n" +
				"If a node is selected, the node and all following nodes will be aligned.", ""))
			{
				this.ContextSortHorizontal();
			}
			if(EditorTool.ShowButtonNoNameNoWidth(this.sortVerticalContent,
				"Automatically aligns the nodes vertically.\n" +
				"If a node is selected, the node and all following nodes will be aligned.", ""))
			{
				this.ContextSortVertical();
			}
			if(EditorTool.ShowButtonNoNameNoWidth(this.placeOnGridContent,
				"Automatically places the nodes on the grid.\n" +
				"If a node is selected, the node and all following nodes will be placed.", ""))
			{
				this.ContextPlaceOnGrid();
			}

			EditorGUILayout.Separator();

			// nodes
			// add
			bool showContextMenu = false;
			if(EditorTool.ShowButtonNoNameNoWidth(this.addNodeContent,
				"Adds a new node.\n" +
				"If a node is selected, the new node will be connected " +
				"to the selected node's selected slot or first slot.", ""))
			{
				showContextMenu = true;
			}

			EditorGUI.BeginDisabledGroup(!this.IsNodeSelected ||
				isStartSelected ||
				isGateSelected ||
				isGroupSelected);
			// copy
			if(EditorTool.ShowButtonNoNameNoWidth(this.copyContent,
				"Copies the selected node.", ""))
			{
				this.ContextCopyNode();
			}
			// copy to clipboard
			if(EditorTool.ShowButtonNoNameNoWidth(this.copyToClipboardContent,
				"Copies the selected node to the clipboard.", ""))
			{
				this.ContextCopyNodeToClipboard();
			}
			EditorGUI.EndDisabledGroup();

			// paste from clipboard
			EditorGUI.BeginDisabledGroup(this.clipboard.Count == 0 ||
				(this.IsNodeSelected &&
					(isStartSelected ||
					isGateSelected ||
					isGroupSelected)));
			if(EditorTool.ShowButtonNoNameNoWidth(this.pasteFromClipboardContent,
				"Pastes a node form the clipboard.", ""))
			{
				this.ContextPasteNodeFromClipboard();
			}
			EditorGUI.EndDisabledGroup();

			// paste settings
			EditorGUI.BeginDisabledGroup(this.clipboard.Count == 0 || !this.IsNodeSelected ||
				isStartSelected ||
				isGateSelected ||
				isGroupSelected);
			if(EditorTool.ShowButtonNoNameNoWidth(this.pasteSettingsContent,
				"Pastes the settings of a node from the clipboard.", ""))
			{
				this.ContextPasteNodeSettings();
			}
			EditorGUI.EndDisabledGroup();

			// swap nodes
			EditorGUI.BeginDisabledGroup(this.selectedNode.Count != 2 ||
				isStartSelected ||
				isGateSelected ||
				isGroupSelected);
			if(EditorTool.ShowButtonNoNameNoWidth(this.swapNodesContent,
				"Swap two selected nodes.", ""))
			{
				this.ContextSwapNodes();
			}
			EditorGUI.EndDisabledGroup();

			EditorGUILayout.Separator();

			EditorGUI.BeginDisabledGroup(!this.IsNodeSelected || isStartSelected);
			// remove
			if(EditorTool.ShowButtonNoNameNoWidth(this.removeContent,
				"Removes the selected node.", ""))
			{
				this.ContextRemoveNode();
			}
			if(EditorTool.ShowButtonNoNameNoWidth(this.removeChainContent,
				"Removes the selected node and all following nodes.", ""))
			{
				this.ContextRemoveChain();
			}
			EditorGUI.EndDisabledGroup();

			// zoom
			EditorGUILayout.Separator();

			EditorGUILayout.BeginVertical();
			GUILayout.FlexibleSpace();
			EditorGUILayout.BeginHorizontal();
			EditorTool.Label("+/-");
			this.zoom = GUILayout.HorizontalSlider(this.zoom, 1, Maki.EditorSettings.nodeMaxZoom, EditorTool.W_MICRO_BUTTON);
			EditorGUILayout.EndHorizontal();
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndVertical();

			// search field
			EditorGUILayout.Separator();

			string tmpSearch = this.search;
			EditorGUILayout.BeginVertical();
			GUILayout.FlexibleSpace();
			this.search = this.searchField.OnGUI(this.search);
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndVertical();
			if(tmpSearch != this.search)
			{
				this.searchSplit = this.search.Split(new char[] { ' ' },
					System.StringSplitOptions.RemoveEmptyEntries);
			}

			GUILayout.FlexibleSpace();

			// layers
			EditorGUILayout.BeginVertical();
			GUILayout.FlexibleSpace();
			EditorGUILayout.BeginHorizontal();
			EditorTool.Label("Layer");
			if(this.renameLayer)
			{
				EditorTool.NoTitleField<string>("Rename Layer", ref layers[this.currentLayer],
					"Rename the current layer.", "", null, EditorTool.WIDTH_150);
			}
			else
			{
				string[] tmpLayers = new string[layers.Length + 1];
				tmpLayers[tmpLayers.Length - 1] = "Add Layer...";
				for(int i = 0; i < layers.Length; i++)
				{
					tmpLayers[i] = i + ": " + layers[i];
				}

				int tmpLayer = this.currentLayer;
				EditorTool.NoTitlePopup("Layer", ref this.currentLayer, tmpLayers,
					"Select the layer that will be displayed.", "", this.parent);
				if(this.currentLayer == tmpLayers.Length - 1)
				{
					layers = this.AddLayer();
					this.currentLayer = layers.Length - 1;
				}
				if(tmpLayer != this.currentLayer)
				{
					this.isFirstFocus = true;
				}
			}
			EditorGUILayout.EndHorizontal();
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndVertical();

			EditorGUILayout.BeginVertical();
			GUILayout.FlexibleSpace();
			EditorTool.ToggleButtonNoName(this.renameLayerContent,
				ref this.renameLayer, "Rename the current layer.", "");
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndVertical();

			EditorGUI.BeginDisabledGroup(this.currentLayer == 0);
			if(EditorTool.ShowButtonNoNameNoWidth(this.removeLayerContent,
				"Removes this layer and all nodes on it.", "") &&
				EditorUtility.DisplayDialog("Delete Layer",
					"Deleting this layer will also delete all nodes on this layer.",
					"Delete", "Cancel"))
			{
				ArrayHelper.RemoveAt(ref layers, this.currentLayer);
				for(int i = 0; i < this.nodes.Length; i++)
				{
					if(this.nodes[i] != null &&
						this.nodes[i].RemoveLayer(this.currentLayer))
					{
						this.DoRemoveNode(this.nodes[i--], false);
					}
				}
				this.currentLayer--;
			}
			EditorGUI.EndDisabledGroup();

			EditorGUILayout.EndHorizontal();
			// end toolbar

			if(showContextMenu)
			{
				this.contextPosition.x = 128;
				this.contextPosition.y = 128;
				List<ContextMenuPopup.Element> tree = new List<ContextMenuPopup.Element>();
				this.AddNodesToContext(ref tree, null);
				PopupWindow.Show(new Rect(Event.current.mousePosition, Vector2.zero),
					new ContextMenuPopup("Add Node", tree,
						EditorGUIUtility.GUIToScreenPoint(Event.current.mousePosition),
						this.parent.Editor.Focus, this.parent));
			}
		}


		/*
		============================================================================
		Draw functions
		============================================================================
		*/
		public bool ShowNodes(Rect rect, BaseNode start, BaseNode[] nodes, NodeGroup[] nodeGroups, List<BaseNode.DebugInfo> debug, ref string[] layers)
		{
			try
			{
				if(this.headerStyle == null)
				{
					this.InitStyles();
				}

				// nodes
				this.realStartNode = start;
				this.startNode = this.newStartNode != null ? this.newStartNode : this.realStartNode;
				this.nodes = nodes;
				this.nodeGroups = nodeGroups;
				this.UpdateGroupOrder();

				if(this.markRepaint &&
					Event.current.type == EventType.Repaint)
				{
					this.markRepaint = false;
					this.parent.Editor.Repaint();
				}


				// show toolbar
				GUILayout.BeginArea(new Rect(rect.x, rect.y, rect.width, NodeEditor.TOOLBAR_HEIGHT));
				this.ShowToolbar(ref layers);
				GUILayout.EndArea();
				rect.y += NodeEditor.TOOLBAR_HEIGHT - 1;
				rect.height -= NodeEditor.TOOLBAR_HEIGHT - 1;


				// set layers
				if(this.currentLayer >= layers.Length)
				{
					this.currentLayer = 0;
					this.isFirstFocus = true;
				}
				if(this.IsNodeSelected)
				{
					for(int i = 0; i < this.selectedNode.Count; i++)
					{
						if(!this.selectedNode[i].IsOnLayer(this.currentLayer))
						{
							if(this.slotIndexNode == this.selectedNode[i])
							{
								this.selectedIndex = -1;
							}
							this.selectedNode.RemoveAt(i--);
						}
					}
				}
				this.layers = layers;


				// zoom
				Matrix4x4 tmpMatrix = GUI.matrix;
				GUI.EndClip();

				bool isDocked = this.parent.Editor.IsDocked;
				this.viewBounds.Set(
					-((rect.width * this.zoom) - rect.width) + (rect.x + (isDocked ? 2 : 0)) * this.zoom,
					-(((rect.height * this.zoom) - rect.height)) + ((rect.y + (isDocked ? 19 : 22)) * this.zoom),
					rect.width * this.zoom,
					rect.height * this.zoom);
				this.zoomOffset = (this.viewBounds.size - (this.viewBounds.size / this.zoom)) / 2;
				Vector2 scrollOffset = this.NodeScroll;

				this.visibleArea.Set(
					-NodeEditor.NODE_SIZE.x - NodeEditor.GRID_SIZE,
					-NodeEditor.NODE_SIZE.y - NodeEditor.GRID_SIZE,
					this.viewBounds.width + NodeEditor.NODE_SIZE.x + NodeEditor.GRID_SIZE * 2,
					this.viewBounds.height + NodeEditor.NODE_SIZE.y + NodeEditor.GRID_SIZE * 2);

				GUIUtility.ScaleAroundPivot(Vector2.one / this.zoom, rect.size);
				GUI.BeginClip(this.viewBounds);

				// grid
				if(this.showGrid)
				{
					Rect areaBounds = new Rect(
						1 + scrollOffset.x,
						1 + scrollOffset.y,
						this.viewBounds.width - scrollOffset.x,
						this.viewBounds.height - scrollOffset.y);
					this.grid.SetBounds(areaBounds, this.viewBounds);
					this.grid.ShowGrid(this.zoom > 4);
				}

				this.nodeArea = new Rect();
				int count = 0;
				if(this.realStartNode.IsOnLayer(this.currentLayer))
				{
					this.nodeArea.position = this.realStartNode.GetPosition(this.currentLayer);
					count++;
				}
				for(int i = 0; i < this.nodes.Length; i++)
				{
					if(this.nodes[i].IsOnLayer(this.currentLayer))
					{
						Vector2 position = this.nodes[i].GetPosition(this.currentLayer);

						if(count == 0)
						{
							this.nodeArea.position = position;
						}
						else if(this.nodeArea.x > position.x)
						{
							this.nodeArea.x = position.x;
						}
						if(this.nodeArea.y > position.y)
						{
							this.nodeArea.y = position.y;
						}
						count++;
					}
				}
				if(count > 0)
				{
					this.nodeArea.size = this.nodeArea.position;
				}
				else
				{
					this.nodeArea = new Rect();
				}

				if(this.connectionMode == 0 &&
					!this.draggingNode && !this.draggingGroup)
				{
					this.UpdateVisit();
				}


				// only in repaint
				if(Event.current.type == EventType.Repaint)
				{
					if(this.nodeGroups.Length > 0)
					{
						if((!this.draggingNode && !this.draggingGroup) || !Event.current.control)
						{
							for(int i = 0; i < this.nodeGroups.Length; i++)
							{
								this.nodeGroups[i].OwnIndex = i;
								this.nodeGroups[i].ClearNodes();
							}
							if(this.realStartNode != null)
							{
								if(this.realStartNode.IsOnLayer(this.currentLayer))
								{
									int index = this.realStartNode.GetNodeGroup(this.currentLayer);
									if(index >= 0)
									{
										this.nodeGroups[index].AddNode(this.realStartNode);
									}
								}
							}
							for(int i = 0; i < this.nodeGroups.Length; i++)
							{
								if(this.nodeGroups[i].IsOnLayer(this.currentLayer))
								{
									int index = this.nodeGroups[i].GetNodeGroup(this.currentLayer);
									if(index >= 0)
									{
										this.nodeGroups[index].AddNode(this.nodeGroups[i]);
									}
								}
							}
							for(int i = 0; i < this.nodes.Length; i++)
							{
								if(this.nodes[i].IsOnLayer(this.currentLayer))
								{
									int index = this.nodes[i].GetNodeGroup(this.currentLayer);
									if(index >= 0)
									{
										this.nodeGroups[index].AddNode(this.nodes[i]);
									}
								}
							}
							this.UpdateAllGroupPositions();
						}

						// node group display
						for(int i = 0; i < this.groupOrder.Count; i++)
						{
							if(this.groupOrder[i] != null)
							{
								this.DrawNodeGroup(this.groupOrder[i],
									this.selectedNode.Contains(this.groupOrder[i]), scrollOffset);
							}
						}
					}

					// draw connections
					if(this.newStartNode == null)
					{
						this.DrawConnections(this.startNode, -1, true, scrollOffset);
					}
					for(int i = 0; i < this.nodes.Length; i++)
					{
						this.DrawConnections(this.nodes[i], i, this.visited.Contains(this.nodes[i]), scrollOffset);
					}
					// draw debug connections
					if(debug != null && debug.Count > 0)
					{
						if(this.newStartNode == null)
						{
							this.DrawDebugConnections(this.startNode, -1, debug[0].nodeIndex, true, debug.Count == 1, scrollOffset);
						}
						for(int i = 1; i < debug.Count; i++)
						{
							this.DrawDebugConnections(this.nodes[debug[i - 1].nodeIndex], -1, debug[i].nodeIndex,
								this.visited.Contains(this.nodes[debug[i - 1].nodeIndex]), i == debug.Count - 1, scrollOffset);
						}
					}
				}


				// draw debug nodes
				if(debug != null)
				{
					if(this.newStartNode == null)
					{
						this.DrawDebugNode(this.startNode, debug.Count == 0, true, scrollOffset);
					}
					for(int i = 0; i < debug.Count; i++)
					{
						this.DrawDebugNode(this.nodes[debug[i].nodeIndex], i == debug.Count - 1,
							this.visited.Contains(this.nodes[debug[i].nodeIndex]), scrollOffset);
					}
				}

				// node display
				List<int> nodeIndex = new List<int>();
				for(int i = 0; i < this.nodes.Length; i++)
				{
					if(this.nodes[i] != null)
					{
						if(this.selectedNode.Contains(this.nodes[i]))
						{
							nodeIndex.Add(i);
						}
						else
						{
							this.DrawNode(this.nodes[i], false,
								this.visited.Contains(this.nodes[i]),
								this.nodes[i].GetType() == this.gateType,
								scrollOffset);
						}
					}
				}
				if(this.newStartNode == null)
				{
					this.DrawNode(this.startNode, this.selectedNode.Contains(this.startNode),
						true, false, scrollOffset);
				}
				if(nodeIndex.Count > 0)
				{
					for(int i = 0; i < nodeIndex.Count; i++)
					{
						if(this.nodes[nodeIndex[i]] != null)
						{
							this.DrawNode(this.nodes[nodeIndex[i]], true,
								this.visited.Contains(this.nodes[nodeIndex[i]]),
								this.nodes[nodeIndex[i]].GetType() == this.gateType,
								scrollOffset);
						}
					}
				}

				// draw debug fill
				if(debug != null && debug.Count > 0)
				{
					if(this.debugFillTexture == null)
					{
						Color tmpColor = Color.yellow;
						this.debugFillTexture = new Texture2D(2, 2);
						this.debugFillTexture.SetPixels(new Color[] { tmpColor, tmpColor, tmpColor, tmpColor });
						this.debugFillTexture.Apply();
					}
					BaseNode.DebugInfo info = debug[debug.Count - 1];
					if(info.maxTime >= 0)
					{
						this.DrawDebugFillNode(this.nodes[info.nodeIndex],
							(info.maxTime - info.time) / info.maxTime,
							this.visited.Contains(this.nodes[info.nodeIndex]),
							scrollOffset);
					}
				}

				if(this.connectionMode > 0 && this.slotIndexNode != null)
				{
					if(Event.current.type == EventType.MouseDrag)
					{
						this.connectionDragged = true;
					}

					if(this.connectionDragged)
					{
						GUI.changed = true;
						Vector2 pos = this.slotIndexNode.GetPosition(this.currentLayer) + scrollOffset;
						Vector3 startPos = new Vector3(
							pos.x + NodeEditor.NODE_SIZE.x / 2,
							pos.y + (NodeEditor.NODE_SIZE.y - 1) *
								(this.slotIndexNode.GetNextCount() > 1 || !this.mergeSingleSlot ? 2.5f : 1.5f) +
								((NodeEditor.NODE_SIZE.y - 1) * this.selectedIndex),
							0.0f);
						Vector3 endPos = new Vector3(Event.current.mousePosition.x, Event.current.mousePosition.y, 0.0f);
						float curveValue = Mathf.Min(50, (Vector3.Distance(startPos, endPos) / 4));

						Color tmpColor = Handles.color;
						Handles.color = Color.red;
						Handles.DrawAAPolyLine(5, startPos, endPos);
						Handles.color = tmpColor;
					}
				}


				// box selection
				if(this.boxSelecting)
				{
					this.boxSelectionRect.Set(
						this.lastClickPosition.x < Event.current.mousePosition.x ? this.lastClickPosition.x : Event.current.mousePosition.x,
						this.lastClickPosition.y < Event.current.mousePosition.y ? this.lastClickPosition.y : Event.current.mousePosition.y,
						Mathf.Abs(Event.current.mousePosition.x - this.lastClickPosition.x),
						Mathf.Abs(Event.current.mousePosition.y - this.lastClickPosition.y));
					GUI.Label(this.boxSelectionRect, "", this.boxSelectionStyle);

				}
				if(this.mouseDown ||
					this.connectionMode > 0)
				{
					int controlID = GUIUtility.GetControlID(FocusType.Passive);
					GUIUtility.hotControl = controlID;

					EventType eventType = Event.current.GetTypeForControl(controlID);
					if(eventType == EventType.MouseUp)
					{
						this.mouseDown = false;
						GUIUtility.hotControl = 0;

						if(!this.CheckClick(new Rect(0, 0, this.viewBounds.width, this.viewBounds.height)))
						{
							this.connectionMode = 0;
							this.connectionDragged = false;
						}

						if(this.boxSelecting)
						{
							this.boxSelecting = false;
							GUI.changed = true;
							this.UseInteraction();
						}
					}
				}

				// node interactions
				if(nodeIndex.Count > 0)
				{
					for(int i = 0; i < nodeIndex.Count; i++)
					{
						this.NodeInteraction(this.nodes[nodeIndex[i]], nodeIndex[i], scrollOffset);
					}
				}
				if(this.newStartNode == null)
				{
					this.NodeInteraction(this.startNode, -1, scrollOffset);
				}
				for(int i = this.nodes.Length - 1; i >= 0; i--)
				{
					if(this.nodes[i] != null &&
						!this.selectedNode.Contains(this.nodes[i]) &&
						(this.newStartNode == null || this.visited.Contains(this.nodes[i])) &&
						this.nodes[i].IsOnLayer(this.currentLayer))
					{
						this.NodeInteraction(this.nodes[i], i, scrollOffset);
					}
				}

				// node group interactions
				for(int i = 0; i < this.groupOrder.Count; i++)
				{
					if(this.groupOrder[i] != null)
					{
						this.NodeGroupInteraction(this.groupOrder[i], scrollOffset);
					}
				}

				// grid interactions
				this.EditorInteraction(this.viewBounds);
				this.LimitScroll();

				if(this.isFirstFocus &&
					Event.current.type == EventType.Layout)
				{
					this.FocusSelectedNode();
					this.isFirstFocus = false;
				}


				// reset zoom
				GUI.matrix = tmpMatrix;

				if(this.markContextMenuCall)
				{
					this.markContextMenuCall = false;
					this.ShowContextMenu(Event.current.mousePosition);
				}

				return true;
			}
			catch(UnityEngine.ExitGUIException ex)
			{
				return true;
			}
			catch(System.Exception ex)
			{
				Debug.LogWarning("Error occured in node editor: " + ex.Message);
				return false;
			}
		}

		public void DrawConnections(BaseNode node, int index, bool visited, Vector2 scrollOffset)
		{
			if(node != null && (visited || this.newStartNode == null) &&
				node.IsOnLayer(this.currentLayer))
			{
				Vector2 nodePosition = node.GetPosition(this.currentLayer) + scrollOffset;
				int nextCount = node.GetType() == this.gateType && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();

				for(int i = 0; i < nextCount; i++)
				{
					int nextIndex = node.GetNext(i);
					if(nextIndex >= 0 && nextIndex < this.nodes.Length &&
						this.nodes[nextIndex] != null &&
						this.nodes[nextIndex].IsOnLayer(this.currentLayer))
					{
						Vector2 nextNodePosition = this.nodes[nextIndex].GetPosition(this.currentLayer) + scrollOffset;
						Vector3 startPos = new Vector3(
							nodePosition.x + NodeEditor.NODE_SIZE.x,
							nodePosition.y +
								(NodeEditor.NODE_SIZE.y - 1) * (nextCount > 1 || !this.mergeSingleSlot ? 2.5f : 1.5f) +
								((NodeEditor.NODE_SIZE.y - 1) * i),
							0.0f);

						Vector3 endPos = Vector3.zero;

						int startFactor = 1;
						int endFactor = -1;
						if(Maki.EditorSettings.nodesFlexibleLines)
						{
							int nextNodeNextCount = this.nodes[nextIndex].GetType() == this.gateType &&
								this.nodes[nextIndex].nodeLayer == this.currentLayer ?
									0 : this.nodes[nextIndex].GetNextCount();
							if(nextNodeNextCount == 1 && this.mergeSingleSlot)
							{
								nextNodeNextCount = 0;
							}

							Rect nextBounds = new Rect(nextNodePosition.x, nextNodePosition.y,
								NodeEditor.NODE_SIZE.x,
								NodeEditor.NODE_SIZE.y +
									((NodeEditor.NODE_SIZE.y - 1) *
									((nextNodeNextCount) + 1)));

							if(startPos.x > nextBounds.x + NodeEditor.NODE_SIZE.x)
							{
								startFactor = -1;
								startPos.x -= NodeEditor.NODE_SIZE.x;
							}

							if(startPos.y + (NodeEditor.NODE_SPACING.y / 2) < nextBounds.y)
							{
								endPos.x = nextBounds.x + nextBounds.width / 2;
								endPos.y = nextBounds.y;
							}
							else if(startPos.y > nextBounds.y + nextBounds.height + (NodeEditor.NODE_SPACING.y / 2))
							{
								endFactor = 1;
								endPos.x = nextBounds.x + nextBounds.width / 2;
								endPos.y = nextBounds.y + nextBounds.height;
							}
							else if(startPos.x < nextBounds.x + nextBounds.width / 2)
							{
								endFactor = 0;
								endPos.x = nextBounds.x;
								endPos.y = nextBounds.y + NodeEditor.NODE_SIZE.y * 0.5f;
							}
							else
							{
								endFactor = 0;
								endPos.x = nextBounds.x + nextBounds.width;
								endPos.y = nextBounds.y + NodeEditor.NODE_SIZE.y * 0.5f;
							}
						}
						else
						{
							endPos.x = nextNodePosition.x + NodeEditor.NODE_SIZE.x / 2;
							endPos.y = nextNodePosition.y;
						}

						float curveValue = nextIndex == index ? 100.0f : Mathf.Min(50.0f, (Vector3.Distance(startPos, endPos) / 4.0f));
						float colorValue = 1.0f - (((float)i) / ((float)nextCount)) * 0.1f;

						startPos.x += ((NodeEditor.CONNECTION_BOX_SIZE.x / 2) - 1) * startFactor;

						bool isSelected = this.slotIndexNode == node;
						bool nextSelected = this.slotIndexNode == this.nodes[nextIndex];

						Handles.DrawBezier(
							startPos, endPos,
							startPos + Vector3.right * curveValue * 2 * startFactor + Vector3.up * startFactor,
							endPos + (endFactor == 0 ? Vector3.left * curveValue * startFactor : Vector3.up * curveValue * endFactor),
							(isSelected && (this.selectedIndex == -1 || this.selectedIndex == i)) ?
								Maki.EditorSettings.childConnectionColor :
								((nextSelected && this.selectedIndex == -1) ?
									Maki.EditorSettings.parentConnectionColor :
									new Color(colorValue, 1.0f, colorValue, 1.0f)),
							null,
							((isSelected && (this.selectedIndex == -1 || this.selectedIndex == i)) ||
								(nextSelected && this.selectedIndex == -1)) ? 5 : 4
						);
					}
				}
			}
		}

		public void DrawDebugConnections(BaseNode node, int index, int nextNode, bool visited, bool isCurrent, Vector2 scrollOffset)
		{
			if(node != null && (visited || this.newStartNode == null) &&
				node.IsOnLayer(this.currentLayer))
			{
				Vector2 nodePosition = node.GetPosition(this.currentLayer) + scrollOffset;
				int nextCount = node.GetType() == this.gateType && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();

				for(int i = 0; i < nextCount; i++)
				{
					int nextIndex = node.GetNext(i);
					if(nextNode == nextIndex &&
						nextIndex >= 0 && nextIndex < this.nodes.Length &&
						this.nodes[nextIndex] != null &&
						this.nodes[nextIndex].IsOnLayer(this.currentLayer))
					{
						Vector2 nextNodePosition = this.nodes[nextIndex].GetPosition(this.currentLayer) + scrollOffset;
						Vector3 startPos = new Vector3(
							nodePosition.x + NodeEditor.NODE_SIZE.x,
							nodePosition.y +
								(NodeEditor.NODE_SIZE.y - 1) * (nextCount > 1 || !this.mergeSingleSlot ? 2.5f : 1.5f) +
								((NodeEditor.NODE_SIZE.y - 1) * i),
							0.0f);

						Vector3 endPos = Vector3.zero;

						int startFactor = 1;
						int endFactor = -1;
						if(Maki.EditorSettings.nodesFlexibleLines)
						{
							int nextNodeNextCount = this.nodes[nextIndex].GetType() == this.gateType &&
								this.nodes[nextIndex].nodeLayer == this.currentLayer ?
									0 : this.nodes[nextIndex].GetNextCount();
							if(nextNodeNextCount == 1 && this.mergeSingleSlot)
							{
								nextNodeNextCount = 0;
							}

							Rect nextBounds = new Rect(nextNodePosition.x, nextNodePosition.y,
								NodeEditor.NODE_SIZE.x,
								NodeEditor.NODE_SIZE.y +
									((NodeEditor.NODE_SIZE.y - 1) *
									((nextNodeNextCount) + 1)));

							if(startPos.x > nextBounds.x + NodeEditor.NODE_SIZE.x)
							{
								startFactor = -1;
								startPos.x -= NodeEditor.NODE_SIZE.x;
							}

							if(startPos.y + (NodeEditor.NODE_SPACING.y / 2) < nextBounds.y)
							{
								endPos.x = nextBounds.x + nextBounds.width / 2;
								endPos.y = nextBounds.y;
							}
							else if(startPos.y > nextBounds.y + nextBounds.height + (NodeEditor.NODE_SPACING.y / 2))
							{
								endFactor = 1;
								endPos.x = nextBounds.x + nextBounds.width / 2;
								endPos.y = nextBounds.y + nextBounds.height;
							}
							else if(startPos.x < nextBounds.x + nextBounds.width / 2)
							{
								endFactor = 0;
								endPos.x = nextBounds.x;
								endPos.y = nextBounds.y + NodeEditor.NODE_SIZE.y * 0.5f;
							}
							else
							{
								endFactor = 0;
								endPos.x = nextBounds.x + nextBounds.width;
								endPos.y = nextBounds.y + NodeEditor.NODE_SIZE.y * 0.5f;
							}
						}
						else
						{
							endPos.x = nextNodePosition.x + NodeEditor.NODE_SIZE.x / 2;
							endPos.y = nextNodePosition.y;
						}

						float curveValue = nextIndex == index ? 100.0f : Mathf.Min(50.0f, (Vector3.Distance(startPos, endPos) / 4.0f));
						float colorValue = 1.0f - (((float)i) / ((float)nextCount)) * 0.1f;
						Color color = isCurrent ? Maki.EditorSettings.debugConnectionCurrentColor : Maki.EditorSettings.debugConnectionColor;
						color.a = 0.7f;

						startPos.x += ((NodeEditor.CONNECTION_BOX_SIZE.x / 2) - 1) * startFactor;

						bool isSelected = this.slotIndexNode == node;
						bool nextSelected = this.slotIndexNode == this.nodes[nextIndex];

						Handles.DrawBezier(
							startPos, endPos,
							startPos + Vector3.right * curveValue * 2 * startFactor + Vector3.up * startFactor,
							endPos + (endFactor == 0 ? Vector3.left * curveValue * startFactor : Vector3.up * curveValue * endFactor),
							color, null,
							((isSelected && (this.selectedIndex == -1 || this.selectedIndex == i)) ||
								(nextSelected && this.selectedIndex == -1)) ? 10 : 8
						);
					}
				}
			}
		}

		public void DrawNode(BaseNode node, bool isSelected, bool visited, bool isGate, Vector2 scrollOffset)
		{
			if(node != null && (visited || this.newStartNode == null) &&
				node.IsOnLayer(this.currentLayer))
			{
				// position
				Vector2 nodePosition = node.GetPosition(this.currentLayer) + scrollOffset;
				int nextCount = isGate && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();
				if(this.nodeArea.width < nodePosition.x - scrollOffset.x)
				{
					this.nodeArea.width = nodePosition.x - scrollOffset.x;
				}
				float bottomPosition = nodePosition.y + (NodeEditor.NODE_SIZE.y - 1) * nextCount;
				if(this.nodeArea.height < bottomPosition - scrollOffset.y)
				{
					this.nodeArea.height = bottomPosition - scrollOffset.y;
				}

				// colors
				Color originalFG = GUI.contentColor;
				Color originalBG = GUI.backgroundColor;
				Color nodeColor = isSelected ? Maki.EditorSettings.selectedNodeColor :
					(node.IsEnabled ?
						(this.startNode == node ?
							Maki.EditorSettings.startNodeColor :
							(isGate ?
								Maki.EditorSettings.layerGateNodeColor :
								(visited ?
									(this.colorizeNodes ? node.EditorColor :
										Maki.EditorSettings.baseNodeColor) :
									Maki.EditorSettings.unreachableNodeColor))) :
						Maki.EditorSettings.disabledNodeColor);
				GUI.backgroundColor = nodeColor;

				NodeInfo nodeInfo;
				if(!this.nodeInfos.TryGetValue(node.GetType(), out nodeInfo))
				{
					nodeInfo = new NodeInfo(new GUIContent(node.GetNodeName(), ""), "", null);
				}

				float alpha = 1;
				if(this.search != "")
				{
					alpha = 0.5f;
					if(nodeInfo.content.text.IndexOf(this.search, System.StringComparison.OrdinalIgnoreCase) >= 0 ||
						nodeInfo.content.tooltip.IndexOf(this.search, System.StringComparison.OrdinalIgnoreCase) >= 0)
					{
						alpha = 1.0f;
					}
					else
					{
						int count = 0;
						for(int j = 0; j < searchSplit.Length; j++)
						{
							if(nodeInfo.content.text.IndexOf(searchSplit[j], System.StringComparison.OrdinalIgnoreCase) >= 0 ||
								nodeInfo.content.tooltip.IndexOf(searchSplit[j], System.StringComparison.OrdinalIgnoreCase) >= 0)
							{
								count++;
							}
						}
						if(count == searchSplit.Length)
						{
							alpha = 1;
						}
					}
					Color searchColor = GUI.backgroundColor;
					searchColor.a = alpha;
					GUI.backgroundColor = searchColor;
					searchColor = GUI.contentColor;
					searchColor.a = alpha;
					GUI.contentColor = searchColor;
				}

				// node header
				Rect rect = new Rect(nodePosition.x, nodePosition.y,
					NodeEditor.NODE_SIZE.x, NodeEditor.NODE_SIZE.y);

				if(Event.current.type == EventType.Repaint &&
					rect.Contains(Event.current.mousePosition))
				{
					EditorContent.Instance.SetEditorHelp(nodeInfo.content.text, nodeInfo.content.tooltip, nodeInfo.info);
				}

				if(node.IsEnabled)
				{
					GUI.Label(rect,
						new GUIContent(
							node.overrideNodeName ?
								node.nodeName :
								(isGate ?
									(node.nodeLayer == this.currentLayer ? "Gate Entry" : "Gate Exit") :
									nodeInfo.content.text),
							nodeInfo.content.tooltip),
						node == this.focusedNode && isSelected ?
							this.headerFocusedStyle :
							this.headerStyle);
				}
				else
				{
					GUI.Label(rect,
						new GUIContent("DISABLED " + (node.overrideNodeName ? node.nodeName : nodeInfo.content.text), nodeInfo.content.tooltip),
						node == this.focusedNode && isSelected ?
							this.headerFocusedStyle :
							this.headerStyle);
				}

				if(node.IsBreakpoint)
				{
					Color tmp = GUI.backgroundColor;
					GUI.backgroundColor = originalBG;
					GUI.Label(new Rect(nodePosition.x - 9, nodePosition.y - 9, 20, 20),
						new GUIContent("", this.breakpointTexture, "Breakpoint"));
					GUI.backgroundColor = tmp;
				}

				// node details/information
				string nodeDetails = "";
				try
				{
					nodeDetails = node.GetNodeDetails();
				}
				catch(System.Exception ex)
				{
					Debug.LogWarning("An issue occured displaying the details of this node: " +
						(node.overrideNodeName ?
								node.nodeName :
								(isGate ?
									(node.nodeLayer == this.currentLayer ? "Gate Entry" : "Gate Exit") :
									nodeInfo.content.text)) +
						"\n" + ex.Message + "\n" + ex.StackTrace);
				}
				if(isGate)
				{
					if(node.nodeLayer == this.currentLayer)
					{
						int tmp = 0;
						if(int.TryParse(nodeDetails, out tmp))
						{
							nodeDetails = "To " + tmp + ": " + this.layers[tmp];
						}
					}
					else
					{
						nodeDetails = "From " + node.nodeLayer + ": " + this.layers[node.nodeLayer];
					}
				}

				rect.y += NodeEditor.NODE_SIZE.y - 1;

				if(Event.current.type == EventType.Repaint &&
					rect.Contains(Event.current.mousePosition))
				{
					EditorContent.Instance.SetEditorHelp(nodeInfo.content.text, nodeDetails, nodeInfo.info);
				}

				if(node == this.focusedNode && isSelected)
				{
					GUI.Label(rect, new GUIContent(nodeDetails, nodeDetails),
						nextCount > 0 && (nextCount > 1 || !this.mergeSingleSlot) ?
							this.centerFocusedStyle : this.bottomFocusedStyle);
				}
				else
				{
					GUI.Label(rect, new GUIContent(nodeDetails, nodeDetails),
						nextCount > 0 && (nextCount > 1 || !this.mergeSingleSlot) ?
							this.centerStyle : this.bottomStyle);
				}

				// node connections
				for(int i = 0; i < nextCount; i++)
				{
					Color searchColor = originalBG;
					if(nextCount > 1 || !this.mergeSingleSlot)
					{
						rect.y += NodeEditor.NODE_SIZE.y - 1;
						if(this.slotIndexNode == node && this.selectedIndex == i)
						{
							searchColor = Maki.EditorSettings.selectedSlotColor;
							searchColor.a = alpha;
							GUI.backgroundColor = searchColor;
						}
						string nextName = "";
						try
						{
							nextName = node.GetNextName(i);
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("An issue occured displaying the details of this node's slot (" + i + "): " +
								(node.overrideNodeName ?
										node.nodeName :
										(isGate ?
											(node.nodeLayer == this.currentLayer ? "Gate Entry" : "Gate Exit") :
											nodeInfo.content.text)) +
								"\n" + ex.Message + "\n" + ex.StackTrace);
						}
						if(node == this.focusedNode && isSelected)
						{
							GUI.Label(rect, new GUIContent(nextName, nextName), i < nextCount - 1 ?
								this.centerFocusedStyle : this.bottomFocusedStyle);
						}
						else
						{
							GUI.Label(rect, new GUIContent(nextName, nextName), i < nextCount - 1 ?
								this.centerStyle : this.bottomStyle);
						}
					}

					// connection box
					searchColor = originalBG;
					searchColor.a = alpha;
					GUI.backgroundColor = searchColor;
					int nextIndex = node.GetNext(i);
					if(nextIndex >= 0 && nextIndex < this.nodes.Length &&
						this.nodes[nextIndex] != null &&
						this.nodes[nextIndex].IsOnLayer(this.currentLayer))
					{
						GUI.Label(
							new Rect(rect.x +
								(rect.x <= this.nodes[nextIndex].GetPosition(this.currentLayer).x + scrollOffset.x ?
									NodeEditor.NODE_SIZE.x - 6 : -8), rect.y,
								NodeEditor.CONNECTION_BOX_SIZE.x, NodeEditor.CONNECTION_BOX_SIZE.y), "",
							this.connectedStyle);
					}
					else
					{
						GUI.Label(
							new Rect(rect.x + NodeEditor.NODE_SIZE.x - 6, rect.y,
								NodeEditor.CONNECTION_BOX_SIZE.x, NodeEditor.CONNECTION_BOX_SIZE.y), "",
							(nextIndex == -1 ? this.notConnectedStyle : this.connectedStyle));
					}

					searchColor = nodeColor;
					searchColor.a = alpha;
					GUI.backgroundColor = searchColor;
				}
				GUI.backgroundColor = originalBG;
				GUI.contentColor = originalFG;

				if(this.showEnableToggle &&
					node.ShowEnableToggle)
				{
					node.IsEnabled = GUI.Toggle(
						new Rect(nodePosition.x - NodeEditor.ENABLE_TOGGLE_SIZE.x / 2 + NodeEditor.NODE_SIZE.x,
							nodePosition.y - NodeEditor.ENABLE_TOGGLE_SIZE.y / 2,
							NodeEditor.ENABLE_TOGGLE_SIZE.x, NodeEditor.ENABLE_TOGGLE_SIZE.y),
						node.IsEnabled, "");
				}
			}
		}

		public void DrawDebugNode(BaseNode node, bool isCurrent, bool visited, Vector2 scrollOffset)
		{
			if(node != null && (visited || this.newStartNode == null) &&
				node.IsOnLayer(this.currentLayer))
			{
				Vector2 nodePosition = node.GetPosition(this.currentLayer) + scrollOffset;
				int nextCount = node.GetType() == this.gateType && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();
				Rect rect = new Rect(nodePosition.x, nodePosition.y, NodeEditor.NODE_SIZE.x,
					(NodeEditor.NODE_SIZE.y - 1) * ((nextCount > 1 || nextCount == 0 || !this.mergeSingleSlot ? 2 : 1) + nextCount));

				Color originalBG = GUI.backgroundColor;
				GUI.backgroundColor = isCurrent ? Maki.EditorSettings.debugNodeCurrentColor : Maki.EditorSettings.debugNodeColor;
				GUI.Label(rect, "", this.nodeDebugStyle);
				GUI.backgroundColor = originalBG;
			}
		}

		public void DrawDebugFillNode(BaseNode node, float fillPercent, bool visited, Vector2 scrollOffset)
		{
			if(node != null && (visited || this.newStartNode == null) &&
				node.IsOnLayer(this.currentLayer))
			{
				Vector2 nodePosition = node.GetPosition(this.currentLayer) + scrollOffset;
				int nextCount = node.GetType() == this.gateType && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();
				Rect rect = new Rect(nodePosition.x, nodePosition.y + NodeEditor.NODE_SIZE.y - 4,
					NodeEditor.NODE_SIZE.x, 3);
				Rect rect2 = new Rect(rect);
				rect.width *= fillPercent;

				GUI.DrawTextureWithTexCoords(rect, this.debugFillTexture, rect2);
			}
		}

		public void DrawNodeGroup(NodeGroup group, bool isSelected, Vector2 scrollOffset)
		{
			if(group != null &&
				group.IsOnLayer(this.currentLayer))
			{
				// position
				Vector2 nodePosition = group.GetPosition(this.currentLayer) + scrollOffset;
				if(this.nodeArea.width < nodePosition.x - scrollOffset.x)
				{
					this.nodeArea.width = nodePosition.x - scrollOffset.x;
				}
				float bottomPosition = nodePosition.y + group.size.y;
				if(this.nodeArea.height < bottomPosition - scrollOffset.y)
				{
					this.nodeArea.height = bottomPosition - scrollOffset.y;
				}

				// colors
				Color originalFG = GUI.contentColor;
				Color originalBG = GUI.backgroundColor;
				GUI.backgroundColor = group.groupColor;

				float alpha = 1;
				if(this.search != "")
				{
					alpha = 0.5f;
					if(group.name.IndexOf(this.search, System.StringComparison.OrdinalIgnoreCase) >= 0)
					{
						alpha = 1.0f;
					}
					else
					{
						int count = 0;
						for(int j = 0; j < searchSplit.Length; j++)
						{
							if(group.name.IndexOf(searchSplit[j], System.StringComparison.OrdinalIgnoreCase) >= 0)
							{
								count++;
							}
						}
						if(count == searchSplit.Length)
						{
							alpha = 1;
						}
					}
					Color searchColor = GUI.backgroundColor;
					searchColor.a = alpha;
					GUI.backgroundColor = searchColor;
					searchColor = GUI.contentColor;
					searchColor.a = alpha;
					GUI.contentColor = searchColor;
				}

				// node
				Rect rect = new Rect(nodePosition, group.size);

				if(Event.current.type == EventType.Repaint &&
					rect.Contains(Event.current.mousePosition))
				{
					EditorContent.Instance.SetEditorHelp(group.OwnIndex + ": " + group.name, "", "");
				}

				this.nodeGroupStyle.normal.textColor = group.textColor;
				this.nodeGroupFocusedStyle.normal.textColor = group.textColor;
				GUI.Label(rect, group.OwnIndex + ": " + group.name,
					group == this.focusedNode && isSelected ?
						this.nodeGroupFocusedStyle :
						this.nodeGroupStyle);

				GUI.backgroundColor = originalBG;
				GUI.contentColor = originalFG;
			}
		}

		private void GetChildNodes(ref List<BaseNode> list, List<BaseNode> nodes)
		{
			for(int i = 0; i < nodes.Count; i++)
			{
				this.GetChildNodes(ref list, nodes[i]);
			}
		}

		private void GetChildNodes(ref List<BaseNode> list, BaseNode node)
		{
			if(node != null && !list.Contains(node))
			{
				list.Add(node);
				int nextCount = node.GetType() == this.gateType && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();
				for(int i = 0; i < nextCount; i++)
				{
					int index = node.GetNext(i);
					if(index >= 0 && index < this.nodes.Length)
					{
						this.GetChildNodes(ref list, this.nodes[index]);
					}
				}
			}
		}


		/*
		============================================================================
		Node group functions
		============================================================================
		*/
		private void GetGroupNodes(ref List<BaseNode> list, NodeGroup group)
		{
			if(!list.Contains(group))
			{
				list.Add(group);
				for(int i = 0; i < group.Nodes.Count; i++)
				{
					if(group.Nodes[i] is NodeGroup)
					{
						this.GetGroupNodes(ref list, (NodeGroup)group.Nodes[i]);
					}
					else if(!list.Contains(group.Nodes[i]))
					{
						list.Add(group.Nodes[i]);
					}
				}
			}
		}

		private int GetRootGroupIndex(int index)
		{
			if(index >= 0)
			{
				if(this.nodeGroups[index].GetNodeGroup(this.currentLayer) == -1)
				{
					return index;
				}
				return this.GetRootGroupIndex(this.nodeGroups[index].GetNodeGroup(this.currentLayer));
			}
			return -1;
		}

		private NodeGroup GetRootGroup(int index)
		{
			index = this.GetRootGroupIndex(index);
			if(index >= 0)
			{
				return this.nodeGroups[index];
			}
			return null;
		}

		private void UpdateNodeGroup(BaseNode node)
		{
			if(node != null)
			{
				NodeGroup group = this.GetRootGroup(node.GetNodeGroup(this.currentLayer));
				if(group != null)
				{
					this.UpdateGroupPosition(group);
				}
			}
		}

		private void UpdateAllGroupPositions()
		{
			for(int i = 0; i < this.nodeGroups.Length; i++)
			{
				if(this.nodeGroups[i] != null &&
					this.nodeGroups[i].GetNodeGroup(this.currentLayer) == -1)
				{
					this.UpdateGroupPosition(this.nodeGroups[i]);
				}
			}
		}

		private void UpdateGroupPosition(NodeGroup group)
		{
			if(group != null)
			{
				bool first = true;
				group.size = NodeGroup.DefaultSize;
				Rect rect = new Rect();

				for(int i = 0; i < group.Nodes.Count; i++)
				{
					if(group.Nodes[i] is NodeGroup)
					{
						NodeGroup otherGroup = (NodeGroup)group.Nodes[i];
						this.UpdateGroupPosition(otherGroup);
						Rect otherRect = new Rect(otherGroup.nodePosition, otherGroup.size);
						if(first)
						{
							first = false;
							rect = otherRect;
						}
						else
						{
							ValueHelper.RectCombine(ref rect, otherRect);
						}
					}
					else
					{
						Vector2 nodePosition = group.Nodes[i].GetPosition(this.currentLayer);
						int nextCount = group.Nodes[i].GetType() == this.gateType &&
							group.Nodes[i].nodeLayer == this.currentLayer ?
								0 : group.Nodes[i].GetNextCount();
						Rect otherRect = new Rect(nodePosition.x, nodePosition.y,
							NodeEditor.NODE_SIZE.x,
							1 + (NodeEditor.NODE_SIZE.y - 1) * (nextCount == 1 && this.mergeSingleSlot ? 2 : (nextCount + 2)));
						if(first)
						{
							first = false;
							rect = otherRect;
						}
						else
						{
							ValueHelper.RectCombine(ref rect, otherRect);
						}
					}
				}

				if(!first)
				{
					group.nodePosition = rect.position;
					group.nodePosition.x -= 2 * NodeEditor.GRID_SIZE;
					group.nodePosition.y -= 2 * NodeEditor.GRID_SIZE;
					group.size = rect.size;
					group.size.x += 4 * NodeEditor.GRID_SIZE;
					group.size.y += 4 * NodeEditor.GRID_SIZE;
				}
			}
		}

		private void UpdateGroupOrder()
		{
			this.groupOrder.Clear();

			for(int i = 0; i < this.nodeGroups.Length; i++)
			{
				if(this.nodeGroups[i] != null)
				{
					if(this.nodeGroups[i].GetNodeGroup(this.currentLayer) == -1)
					{
						this.AddToGroupOrder(i);
					}
				}
			}
			this.groupOrder.Reverse();
		}

		private void AddToGroupOrder(int index)
		{
			this.groupOrder.Add(this.nodeGroups[index]);
			for(int i = 0; i < this.nodeGroups.Length; i++)
			{
				if(this.nodeGroups[i] != null &&
					this.nodeGroups[i].GetNodeGroup(this.currentLayer) == index)
				{
					this.AddToGroupOrder(i);
				}
			}
		}

		private NodeGroup GetSelectedGroup()
		{
			if(this.IsNodeSelected)
			{
				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					if(this.selectedNode[i] is NodeGroup)
					{
						return (NodeGroup)this.selectedNode[i];
					}
				}
			}
			return null;
		}

		private int GetNodeGroupAt(NodeGroup ignore, Vector2 position, Vector2 scrollOffset, int parentIndex)
		{
			for(int i = 0; i < this.nodeGroups.Length; i++)
			{
				if(this.nodeGroups[i] != ignore &&
					this.nodeGroups[i].IsOnLayer(this.currentLayer))
				{
					Vector2 nodePosition = this.nodeGroups[i].GetPosition(this.currentLayer) + scrollOffset;
					Rect rect = new Rect(nodePosition, this.nodeGroups[i].size);
					if(rect.Contains(position))
					{
						int index = this.nodeGroups[i].GetNodeGroup(this.currentLayer);
						if(parentIndex == index)
						{
							return this.GetNodeGroupAt(ignore, position, scrollOffset, i);
						}
					}
				}
			}
			return parentIndex;
		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		private bool CheckClick(Rect rect)
		{
			return rect.Contains(Event.current.mousePosition);
		}

		public void EditorInteraction(Rect rect)
		{
			rect.x = 0;
			rect.y = 0;

			// drag > CTRL repaint
			if((this.draggingNode || this.draggingGroup) &&
				(Event.current.keyCode == KeyCode.LeftControl ||
					Event.current.keyCode == KeyCode.RightControl) &&
				(Event.current.type == EventType.KeyDown ||
					Event.current.type == EventType.KeyUp))
			{
				this.parent.Editor.Repaint();
			}

			// mouse down
			if(Event.current.type == EventType.MouseDown &&
				this.CheckClick(rect))
			{
				this.mouseDown = true;
				// set hot control for out of box mouse input
				GUIUtility.hotControl = GUIUtility.GetControlID(FocusType.Passive);
				this.lastClickPosition = Event.current.mousePosition;

				if(Event.current.button == 0)
				{
					// view all node (double click)
					if(Event.current.clickCount == 2)
					{
						this.newStartNode = null;
					}
					// unselect
					else
					{
						this.ClearSelected();
						this.connectionMode = 0;
						this.connectionDragged = false;
						GUI.changed = true;
					}
					this.UseInteraction();
				}
			}
			// mouse up
			else if(Event.current.type == EventType.MouseUp)
			{
				this.mouseDown = false;
				GUIUtility.hotControl = 0;
				if(this.connectionMode == 1)
				{
					this.connectionMode = 0;
					this.connectionDragged = false;
				}
			}
			else if(this.IsContextClick() &&
				this.CheckClick(rect))
			{
				this.ClearSelected();
				this.contextPosition = Event.current.mousePosition;
				this.markContextMenuCall = true;
				this.UseInteraction();
			}
			// scroll drag
			else if(Event.current.type == EventType.MouseDrag &&
				this.connectionMode == 0 &&
				this.mouseDown)
			{
				if(Event.current.button == 0 &&
					(this.boxSelecting ||
						!Event.current.alt))
				{
					this.boxSelecting = true;
					GUI.changed = true;
					this.UseInteraction();
				}
				else if(Event.current.button == 2 ||
					(!this.boxSelecting &&
						Event.current.button == 0 &&
						Event.current.alt))
				{
					this.NodeScroll += Event.current.delta;
					GUI.changed = true;
					this.UseInteraction();
				}
			}
			// scroll wheel zoom
			else if(Event.current.type == EventType.ScrollWheel &&
				(Maki.EditorSettings.nodeScrollTrackpadMode ||
					!Maki.EditorSettings.nodeScrollZoomShift ||
					Event.current.shift) &&
				!this.boxSelecting &&
				rect.Contains(Event.current.mousePosition))
			{
				if(Maki.EditorSettings.nodeScrollTrackpadMode &&
					(!Maki.EditorSettings.nodeScrollZoomShift ||
						!Event.current.shift))
				{
					if(Event.current.control)
					{
						this.NodeScroll += Maki.EditorSettings.nodeScrollTackpadChange *
							(Maki.EditorSettings.nodeScrollTrackpadHorizontal ?
								Event.current.delta :
								new Vector2(Event.current.delta.y, 0));
					}
					else
					{
						this.NodeScroll += Maki.EditorSettings.nodeScrollTackpadChange *
							(Maki.EditorSettings.nodeScrollTrackpadHorizontal ?
								new Vector2(Event.current.delta.y, 0) :
								Event.current.delta);
					}
					GUI.changed = true;
					this.UseInteraction();
				}
				else
				{
					float tmpZoom = this.zoom;
#if Unity_2019
					this.zoom += Event.current.delta.y > 0 ?
						Maki.EditorSettings.nodeScrollZoomChange :
						-Maki.EditorSettings.nodeScrollZoomChange;
#else
					this.zoom += (Event.current.shift ? Event.current.delta.x > 0 : Event.current.delta.y > 0) ?
						Maki.EditorSettings.nodeScrollZoomChange :
						-Maki.EditorSettings.nodeScrollZoomChange;
#endif
					if(this.zoom < 1)
					{
						this.zoom = 1;
					}
					else if(this.zoom > Maki.EditorSettings.nodeMaxZoom)
					{
						this.zoom = Maki.EditorSettings.nodeMaxZoom;
					}
					if(tmpZoom != this.zoom)
					{
						this.nodeScroll -= ((this.viewBounds.size / tmpZoom) * (tmpZoom - this.zoom)) *
							((Event.current.mousePosition / this.viewBounds.size) - Vector2.one * 0.5f);
						GUI.changed = true;
					}
					this.UseInteraction();
				}
			}
			// delete
			else if(Event.current.type == EventType.KeyDown &&
				this.IsNodeSelected &&
				this.selectedNode.Contains(this.focusedNode) &&
				!this.selectedNode.Contains(this.realStartNode) &&
				Event.current.keyCode == KeyCode.Delete)
			{
				if(Event.current.alt)
				{
					if(EditorUtility.DisplayDialog("Remove Node Chain",
						"Really remove the selected node(s) and all following nodes?", "Remove Chain", "Cancel"))
					{
						this.ContextRemoveChain();
					}
				}
				else
				{
					if(EditorUtility.DisplayDialog("Remove Node(s)",
						"Really remove the selected node(s)?", "Remove", "Cancel"))
					{
						this.ContextRemoveNode();
					}
				}
				this.parent.Editor.Focus();
			}
			else if(Event.current.type == EventType.MouseDown &&
				this.focusedNode != null)
			{
				this.focusedNode = null;
				GUI.changed = true;
			}
			// focus node
			else if(Event.current.type == EventType.KeyDown &&
				Event.current.keyCode == KeyCode.F &&
				!Event.current.control &&
				rect.Contains(Event.current.mousePosition))
			{
				this.FocusSelectedNode();
				this.UseInteraction();
			}
		}

		public void NodeInteraction(BaseNode node, int index, Vector2 scrollOffset)
		{
			if(node != null &&
				node.IsOnLayer(this.currentLayer))
			{
				// position
				Vector2 nodePosition = node.GetPosition(this.currentLayer) + scrollOffset;
				int nextCount = node.GetType() == this.gateType && node.nodeLayer == this.currentLayer ?
					0 : node.GetNextCount();
				bool isSelected = false;
				if(!this.visibleArea.Contains(nodePosition) &&
					!this.visibleArea.Contains(new Vector2(nodePosition.x,
						nodePosition.y + (NodeEditor.NODE_SIZE.y - 1) * nextCount +
							(nextCount > 1 ? NodeEditor.GRID_SIZE : 0))))
				{
					isSelected = this.selectedNode.Contains(node);
					if(!this.draggingNode || !isSelected)
					{
						return;
					}
				}
				else
				{
					isSelected = this.selectedNode.Contains(node);
				}

				// node header
				Rect rect = new Rect(nodePosition.x, nodePosition.y,
					NodeEditor.NODE_SIZE.x, NodeEditor.NODE_SIZE.y);


				// box selection
				if(this.boxSelecting)
				{
					if(!isSelected &&
						Event.current.type == EventType.MouseDrag &&
						this.boxSelectionRect.Overlaps(rect))
					{
						isSelected = true;
						this.SelectNode(node, true, -1);
						this.UseInteraction();
					}
				}
				// connection handling
				else if(this.CheckConnection(rect, node, index))
				{
					GUI.changed = true;
					this.UseInteraction();
				}
				// context menu
				else if(this.IsContextClick() &&
				   this.CheckClick(rect))
				{
					if(!isSelected)
					{
						this.SelectNode(node, Event.current.shift, -1);
					}
					else
					{
						this.selectedIndex = -1;
					}
					this.markContextMenuCall = true;
					this.UseInteraction();
				}
				// view from node (double click)
				else if(Event.current.type == EventType.MouseDown &&
					Event.current.button == 0 &&
					Event.current.clickCount == 2 &&
					this.CheckClick(rect))
				{
					if(node.GetType() == this.gateType)
					{
						if(node.nodeLayer == this.currentLayer)
						{
							int tmp = 0;
							if(int.TryParse(node.GetNodeDetails(), out tmp))
							{
								this.currentLayer = tmp;
								this.isFirstFocus = true;
							}
						}
						else
						{
							this.currentLayer = node.nodeLayer;
							this.isFirstFocus = true;
						}
					}
					else
					{
						this.newStartNode = this.startNode == node ? null : node;
					}
					this.UseInteraction();
				}
				// drag handling
				else if(Event.current.type == EventType.MouseDown &&
					Event.current.button == 0 &&
					this.CheckClick(rect))
				{
					this.SelectNode(node, Event.current.shift, -1);
					if(!this.draggingNode)
					{
						this.draggingNode = true;
						this.dragStartPosition = node.GetPosition(this.currentLayer);
						this.ShowDragGroupNotification();
					}

					if(Event.current.shift)
					{
						this.dragNodes = new List<BaseNode>();
						if(this.selectedNode.Count == 1)
						{
							this.GetChildNodes(ref this.dragNodes, this.selectedNode);
						}
						else
						{
							this.dragNodes.AddRange(this.selectedNode);
						}
						this.dragStartPositions = new List<Vector2>();
						for(int i = 0; i < this.dragNodes.Count; i++)
						{
							this.dragStartPositions.Add(this.dragNodes[i].GetPosition(this.currentLayer));
						}
					}
					else
					{
						this.dragNodes = null;
						this.dragStartPositions = null;
					}

					this.UseInteraction();
				}
				else if(this.draggingNode && isSelected &&
					Event.current.type == EventType.MouseDrag)
				{
					if(this.dragNodes != null)
					{
						for(int i = 0; i < this.dragNodes.Count; i++)
						{
							if(this.dragNodes[i] != null)
							{
								Vector2 position = this.dragNodes[i].GetPosition(this.currentLayer);
								position += Event.current.delta;
								this.dragNodes[i].SetPosition(this.currentLayer, position);
							}
						}
					}
					else
					{
						Vector2 position = node.GetPosition(this.currentLayer);
						position += Event.current.delta;
						node.SetPosition(this.currentLayer, position);
					}
					this.UseInteraction();
				}
				else if(this.draggingNode && isSelected &&
					Event.current.type == EventType.KeyDown &&
					Event.current.keyCode == KeyCode.Escape)
				{
					this.draggingNode = false;
					if(this.dragNodes != null)
					{
						for(int i = 0; i < this.dragNodes.Count; i++)
						{
							if(this.dragNodes[i] != null)
							{
								this.dragNodes[i].SetPosition(this.currentLayer, this.dragStartPositions[i]);
							}
						}
					}
					else
					{
						node.SetPosition(this.currentLayer, this.dragStartPosition);
					}
					this.UseInteraction();
				}
				else if(this.draggingNode && isSelected &&
					(Event.current.type == EventType.MouseUp ||
						Event.current.type == EventType.Ignore))
				{
					this.draggingNode = false;
					int groupIndex = -1;
					if(Event.current.control)
					{
						groupIndex = this.GetNodeGroupAt(null, Event.current.mousePosition, scrollOffset, -1);
						if(this.dragNodes != null)
						{
							for(int i = 0; i < this.dragNodes.Count; i++)
							{
								if(this.dragNodes[i] != null)
								{
									int oldGroupIndex = this.dragNodes[i].GetNodeGroup(this.currentLayer);
									this.dragNodes[i].SetNodeGroup(this.currentLayer, groupIndex);
									if(this.snapToGrid &&
										oldGroupIndex >= 0)
									{
										this.SnapToGrid(this.nodeGroups[oldGroupIndex]);
									}
								}
							}
						}
						else
						{
							int oldGroupIndex = node.GetNodeGroup(this.currentLayer);
							node.SetNodeGroup(this.currentLayer, groupIndex);
							if(this.snapToGrid &&
								oldGroupIndex >= 0)
							{
								this.SnapToGrid(this.nodeGroups[oldGroupIndex]);
							}
						}
					}
					if(this.snapToGrid)
					{
						if(this.dragNodes != null)
						{
							for(int i = 0; i < this.dragNodes.Count; i++)
							{
								if(this.dragNodes[i] != null)
								{
									this.SnapToGrid(this.dragNodes[i]);
								}
							}
							this.dragNodes = null;
						}
						else
						{
							this.SnapToGrid(node);
						}
					}
					this.UseInteraction();
				}
				// selection
				else if(Event.current.type == EventType.MouseDown &&
					(Event.current.button == 0 || Event.current.button == 1) &&
					this.CheckClick(rect))
				{
					if(!isSelected || Event.current.button == 0)
					{
						this.SelectNode(node, Event.current.shift, -1);
					}
					else
					{
						this.selectedIndex = -1;
					}
					this.UseInteraction();
				}


				// node details/information
				rect.y += NodeEditor.NODE_SIZE.y - 1;

				if(nextCount == 0 || nextCount > 1 || !this.mergeSingleSlot)
				{
					// box selection
					if(this.boxSelecting)
					{
						if(!isSelected &&
							Event.current.type == EventType.MouseDrag &&
							this.boxSelectionRect.Overlaps(rect))
						{
							isSelected = true;
							this.SelectNode(node, true, -1);
							this.UseInteraction();
						}
					}
					// connection handling
					else if(this.CheckConnection(rect, node, index))
					{
						GUI.changed = true;
						this.UseInteraction();
					}
					// context menu
					else if(this.IsContextClick() &&
					   this.CheckClick(rect))
					{
						if(!isSelected)
						{
							this.SelectNode(node, Event.current.shift, -1);
						}
						else
						{
							this.selectedIndex = -1;
						}
						this.markContextMenuCall = true;
						this.UseInteraction();
					}
					// selection
					else if(Event.current.type == EventType.MouseDown &&
						(Event.current.button == 0 || Event.current.button == 1) &&
						this.CheckClick(rect))
					{
						if(!isSelected || Event.current.button == 0)
						{
							this.SelectNode(node, Event.current.shift, -1);
						}
						else
						{
							this.selectedIndex = -1;
						}
						this.UseInteraction();
					}
				}


				// node connections
				for(int i = 0; i < nextCount; i++)
				{
					if(nextCount > 1 || !this.mergeSingleSlot)
					{
						rect.y += NodeEditor.NODE_SIZE.y - 1;
					}
					Rect rect2 = new Rect(rect.x, rect.y, rect.width + 8, rect.height);
					int nextIndex = node.GetNext(i);
					if(nextIndex >= 0 && nextIndex < this.nodes.Length &&
						this.nodes[nextIndex] != null &&
						this.nodes[nextIndex].IsOnLayer(this.currentLayer) &&
						rect.x > this.nodes[nextIndex].GetPosition(this.currentLayer).x + scrollOffset.x)
					{
						rect2.x -= 8;
					}

					// box selection
					if(this.boxSelecting)
					{
						if(!isSelected &&
							Event.current.type == EventType.MouseDrag &&
							this.boxSelectionRect.Overlaps(rect))
						{
							isSelected = true;
							this.SelectNode(node, true, -1);
							this.UseInteraction();
						}
					}
					// connection handling
					else if((this.slotIndexNode != node || this.selectedIndex != i) &&
						this.CheckConnection(rect2, node, index))
					{
						GUI.changed = true;
						this.UseInteraction();
					}
					// context menu
					else if(this.IsContextClick() &&
						rect2.Contains(Event.current.mousePosition))
					{
						if(!isSelected)
						{
							this.SelectNode(node, Event.current.shift, i);
						}
						else
						{
							this.slotIndexNode = node;
							this.selectedIndex = i;
						}

						this.markContextMenuCall = true;
						this.UseInteraction();
					}
					// connection box
					else if(Event.current.type == EventType.MouseDown &&
						Event.current.button == 0 &&
						rect2.Contains(Event.current.mousePosition))
					{
						this.SelectNode(node, Event.current.shift, i);
						this.connectionMode = Event.current.clickCount == 2 ? 2 : 1;
						this.connectionDragged = this.connectionMode == 2;
						this.UseInteraction();
					}
					// select node/next
					else if(Event.current.type == EventType.MouseDown &&
						(Event.current.button == 0 || Event.current.button == 1) &&
						rect2.Contains(Event.current.mousePosition))
					{
						if(!isSelected || Event.current.button == 0)
						{
							this.SelectNode(node, Event.current.shift, i);
						}
						else
						{
							this.selectedIndex = i;
						}
						this.UseInteraction();
					}
				}
			}
		}

		public void NodeGroupInteraction(NodeGroup group, Vector2 scrollOffset)
		{
			if(group != null &&
				group.IsOnLayer(this.currentLayer))
			{
				// position
				Vector2 nodePosition = group.GetPosition(this.currentLayer) + scrollOffset;
				Rect rect = new Rect(nodePosition, group.size);

				bool isSelected = false;
				if(!this.visibleArea.Overlaps(rect))
				{
					isSelected = this.selectedNode.Contains(group);
					if(!this.draggingGroup || !isSelected)
					{
						return;
					}
				}
				else
				{
					isSelected = this.selectedNode.Contains(group);
				}

				// context menu
				if(this.IsContextClick() &&
				   this.CheckClick(rect))
				{
					if(!isSelected)
					{
						this.SelectNode(group, false, -1);
					}
					else
					{
						this.selectedIndex = -1;
					}
					this.contextPosition = Event.current.mousePosition;
					this.markContextMenuCall = true;
					this.UseInteraction();
				}
				// drag handling
				else if(Event.current.type == EventType.MouseDown &&
					Event.current.button == 0 &&
					this.CheckClick(rect))
				{
					this.SelectNode(group, false, -1);
					if(!this.draggingGroup)
					{
						this.draggingGroup = true;
						this.dragStartPosition = group.GetPosition(this.currentLayer);
						this.ShowDragGroupNotification();
					}

					this.dragNodes = new List<BaseNode>();
					this.GetGroupNodes(ref this.dragNodes, group);
					this.dragStartPositions = new List<Vector2>();
					for(int i = 0; i < this.dragNodes.Count; i++)
					{
						this.dragStartPositions.Add(this.dragNodes[i].GetPosition(this.currentLayer));
					}

					this.UseInteraction();
				}
				else if(this.draggingGroup && isSelected &&
					Event.current.type == EventType.MouseDrag)
				{
					for(int i = 0; i < this.dragNodes.Count; i++)
					{
						if(this.dragNodes[i] != null)
						{
							Vector2 position = this.dragNodes[i].GetPosition(this.currentLayer);
							position += Event.current.delta;
							this.dragNodes[i].SetPosition(this.currentLayer, position);
						}
					}
					this.UseInteraction();
				}
				else if(this.draggingGroup && isSelected &&
					Event.current.type == EventType.KeyDown &&
					Event.current.keyCode == KeyCode.Escape)
				{
					this.draggingGroup = false;
					for(int i = 0; i < this.dragNodes.Count; i++)
					{
						if(this.dragNodes[i] != null)
						{
							this.dragNodes[i].SetPosition(this.currentLayer, this.dragStartPositions[i]);
						}
					}
					this.UseInteraction();
				}
				else if(this.draggingGroup && isSelected &&
					(Event.current.type == EventType.MouseUp ||
						Event.current.type == EventType.Ignore))
				{
					this.draggingGroup = false;
					if(this.dragNodes.Count > 0 &&
						Event.current.control)
					{
						int groupIndex = this.GetNodeGroupAt(this.dragNodes[0] as NodeGroup, Event.current.mousePosition, scrollOffset, -1);
						int oldGroupIndex = this.dragNodes[0].GetNodeGroup(this.currentLayer);
						this.dragNodes[0].SetNodeGroup(this.currentLayer, groupIndex);
						if(this.snapToGrid &&
							oldGroupIndex >= 0)
						{
							this.SnapToGrid(this.nodeGroups[oldGroupIndex]);
						}
					}
					if(this.snapToGrid)
					{
						for(int i = 0; i < this.dragNodes.Count; i++)
						{
							if(this.dragNodes[i] != null)
							{
								this.SnapToGrid(this.dragNodes[i]);
							}
						}
						this.dragNodes = null;
					}
					this.UseInteraction();
				}
				// selection
				else if(Event.current.type == EventType.MouseDown &&
					(Event.current.button == 0 || Event.current.button == 1) &&
					this.CheckClick(rect))
				{
					if(!isSelected || Event.current.button == 0)
					{
						this.SelectNode(group, false, -1);
					}
					else
					{
						this.selectedIndex = -1;
					}
					this.UseInteraction();
				}
			}
		}

		private void UseInteraction()
		{
			GUI.FocusControl("");
			Event.current.Use();
		}

		private bool CheckConnection(Rect rect, BaseNode node, int nodeIndex)
		{
			if(((this.connectionMode == 1 && Event.current.type == EventType.MouseUp) ||
				(this.connectionMode == 2 && Event.current.type == EventType.MouseDown)) &&
				this.CheckClick(rect))
			{
				if(this.slotIndexNode != null &&
					node.IsConnectable(this.currentLayer))
				{
					this.slotIndexNode.SetNext(this.selectedIndex, nodeIndex);
				}
				this.connectionMode = 0;
				this.connectionDragged = false;
				this.UpdateVisit();
				return true;
			}
			return false;
		}

		private bool IsContextClick()
		{
			return Event.current.type == EventType.ContextClick;
		}

		private void SnapToGrid(BaseNode node)
		{
			Vector2 position = node.GetPosition(this.currentLayer);
			position.x = Mathf.Round(position.x / NodeEditor.GRID_SIZE) * NodeEditor.GRID_SIZE;
			position.y = Mathf.Round(position.y / NodeEditor.GRID_SIZE) * NodeEditor.GRID_SIZE;
			node.SetPosition(this.currentLayer, position);
		}

		private void LimitScroll()
		{
			if(this.NodeScroll.x + this.nodeArea.width - NodeEditor.GRID_SIZE * 2 < 0)
			{
				Vector2 tmp = this.NodeScroll;
				tmp.x = -this.nodeArea.width + NodeEditor.GRID_SIZE * 2;
				this.NodeScroll = tmp;
			}
			else if(this.viewBounds.width - this.NodeScroll.x - this.nodeArea.x -
				NodeEditor.NODE_SIZE.x - NodeEditor.GRID_SIZE * 2 < 0)
			{
				Vector2 tmp = this.NodeScroll;
				tmp.x = this.viewBounds.width - this.nodeArea.x -
					NodeEditor.NODE_SIZE.x - NodeEditor.GRID_SIZE * 2;
				this.NodeScroll = tmp;
			}
			if(this.NodeScroll.y + this.nodeArea.height - NodeEditor.GRID_SIZE * 2 < 0)
			{
				Vector2 tmp = this.NodeScroll;
				tmp.y = -this.nodeArea.height + NodeEditor.GRID_SIZE * 2;
				this.NodeScroll = tmp;
			}
			else if(this.viewBounds.height - this.NodeScroll.y - this.nodeArea.y -
				NodeEditor.NODE_SIZE.y - NodeEditor.GRID_SIZE * 2 < 0)
			{
				Vector2 tmp = this.NodeScroll;
				tmp.y = this.viewBounds.height - this.nodeArea.y -
					NodeEditor.NODE_SIZE.y - NodeEditor.GRID_SIZE * 2;
				this.NodeScroll = tmp;
			}
		}


		/*
		============================================================================
		Context menu functions
		============================================================================
		*/
		private void ShowContextMenu(Vector2 position)
		{
			bool isSelected = this.IsNodeSelected;
			bool isGateSelected = this.IsTypeSelected(this.gateType);
			bool isGroupSelected = this.IsTypeSelected(this.groupType);
			bool isStartSelected = this.selectedNode.Contains(this.realStartNode);

			bool addNode = !isGateSelected || this.selectedNode[0].nodeLayer != this.currentLayer;
			bool copyNode = isSelected && !isGateSelected && !isGroupSelected && !isStartSelected;
			bool removeConnection = isSelected && !isGroupSelected && this.selectedIndex != -1;
			bool removeNode = isSelected && !isGroupSelected && !isStartSelected;
			bool group = true;
			bool sort = true;
			bool moveLayer = isSelected && !isGateSelected && !isGroupSelected && !isStartSelected;

			List<ContextMenuPopup.Element> tree = new List<ContextMenuPopup.Element>();

			// add nodes
			if(addNode)
			{
				ContextMenuPopup.TypeElement parent = new ContextMenuPopup.TypeElement("Add Node", "");
				tree.Add(parent);
				this.AddNodesToContext(ref tree, parent);
			}

			// node groups
			if(group)
			{
				ContextMenuPopup.TypeElement parent = new ContextMenuPopup.TypeElement("Node Groups", "");
				tree.Add(parent);
				tree.Add(new ContextMenuPopup.MenuElement("Add Node Group", "", this.ContextAddNodeGroup, parent));
				if(isSelected)
				{
					if(isGroupSelected)
					{
						tree.Add(new ContextMenuPopup.MenuElement("Remove Node Group", "", this.ContextRemoveNodeGroup, parent));
					}
					ContextMenuPopup.TypeElement addToParent = new ContextMenuPopup.TypeElement("Add To Node Group", "", parent);
					tree.Add(addToParent);
					tree.Add(new ContextMenuPopup.ObjectMenuElement("Add New Node Group", "", this.ContextAddToNodeGroup, -1, addToParent));
					for(int i = 0; i < this.nodeGroups.Length; i++)
					{
						if(this.nodeGroups[i].IsOnLayer(this.currentLayer))
						{
							tree.Add(new ContextMenuPopup.ObjectMenuElement(i + ": " + this.nodeGroups[i].name, "", this.ContextAddToNodeGroup, i, addToParent));
						}
					}
					bool canRemoveFromGroup = false;
					for(int i = 0; i < this.selectedNode.Count; i++)
					{
						if(this.selectedNode[i].GetNodeGroup(this.currentLayer) >= 0)
						{
							canRemoveFromGroup = true;
							break;
						}
					}
					if(canRemoveFromGroup)
					{
						tree.Add(new ContextMenuPopup.MenuElement("Remove From Node Group", "", this.ContextRemoveFromNodeGroup, parent));
					}
				}
			}

			// copy paste
			if(copyNode || (addNode && this.clipboard.Count > 0))
			{
				ContextMenuPopup.TypeElement parent = new ContextMenuPopup.TypeElement("Copy & Paste", "");
				tree.Add(parent);

				// copy node
				if(copyNode)
				{
					tree.Add(new ContextMenuPopup.MenuElement("Copy", "", this.ContextCopyNode, parent));
					tree.Add(new ContextMenuPopup.MenuElement("Copy to Clipboard", "", this.ContextCopyNodeToClipboard, parent));
				}
				// paste from clipboard
				if(addNode && this.clipboard.Count > 0)
				{
					tree.Add(new ContextMenuPopup.MenuElement("Paste from Clipboard", "", this.ContextPasteNodeFromClipboard, parent));

					if(isSelected && !isGateSelected && !isGroupSelected && !isStartSelected)
					{
						tree.Add(new ContextMenuPopup.MenuElement("Paste Settings", "", this.ContextPasteNodeSettings, parent));
					}
				}
			}

			// remove connections
			if(removeConnection)
			{
				if(tree.Count > 0 &&
					!(tree[tree.Count - 1] is ContextMenuPopup.SeparatorElement))
				{
					tree.Add(new ContextMenuPopup.SeparatorElement());
				}

				if(this.slotIndexNode.GetNext(this.selectedIndex) != -1)
				{
					tree.Add(new ContextMenuPopup.MenuElement("Remove Connection", "", this.ContextRemoveConnection));
				}
			}

			// remove nodes
			if(removeNode && this.IsSelectedRemovable())
			{
				if(tree.Count > 0 && !removeConnection &&
					!(tree[tree.Count - 1] is ContextMenuPopup.SeparatorElement))
				{
					tree.Add(new ContextMenuPopup.SeparatorElement());
				}
				tree.Add(new ContextMenuPopup.MenuElement("Remove Node", "", this.ContextRemoveNode));
				tree.Add(new ContextMenuPopup.MenuElement("Remove Node Chain", "", this.ContextRemoveChain));
			}

			// sort
			if(sort)
			{
				if(tree.Count > 0 &&
					!(tree[tree.Count - 1] is ContextMenuPopup.SeparatorElement))
				{
					tree.Add(new ContextMenuPopup.SeparatorElement());
				}
				tree.Add(new ContextMenuPopup.MenuElement("Sort Horizontal", "", this.ContextSortHorizontal));
				tree.Add(new ContextMenuPopup.MenuElement("Sort Vertical", "", this.ContextSortVertical));
				tree.Add(new ContextMenuPopup.MenuElement("Snap nodes to grid", "", this.ContextPlaceOnGrid));

				if(this.selectedNode.Count == 2 &&
					!isGateSelected &&
					!isStartSelected)
				{
					tree.Add(new ContextMenuPopup.MenuElement("Swap Nodes", "", this.ContextSwapNodes));
				}
			}

			// move to layer
			if(moveLayer)
			{
				ContextMenuPopup.TypeElement parent = new ContextMenuPopup.TypeElement("Node Chain to Layer", "");
				tree.Add(parent);
				tree.Add(new ContextMenuPopup.ObjectMenuElement("Create New Layer", "", this.ContextMoveToLayer, -1, parent));
				for(int i = 0; i < this.layers.Length; i++)
				{
					if(i != this.currentLayer)
					{
						tree.Add(new ContextMenuPopup.ObjectMenuElement(i + ": " + this.layers[i], "", this.ContextMoveToLayer, i, parent));
					}
				}
			}

			// view from selected node
			if(isSelected && !isGroupSelected && !isStartSelected)
			{
				if(tree.Count > 0 &&
					!(tree[tree.Count - 1] is ContextMenuPopup.SeparatorElement))
				{
					tree.Add(new ContextMenuPopup.SeparatorElement());
				}
				tree.Add(new ContextMenuPopup.MenuElement("View From Here", "", this.ContextViewFromHere));
			}
			if(this.newStartNode != null)
			{
				if(tree.Count > 0 &&
					!(isSelected && !isStartSelected) &&
					!(tree[tree.Count - 1] is ContextMenuPopup.SeparatorElement))
				{
					tree.Add(new ContextMenuPopup.SeparatorElement());
				}
				tree.Add(new ContextMenuPopup.MenuElement("View All", "", this.ContextViewAll));
			}

			if(this.AddContextMenuOption != null)
			{
				this.AddContextMenuOption(tree);
			}

			PopupWindow.Show(new Rect(position, Vector2.zero),
				new ContextMenuPopup("Context Menu", tree,
					EditorGUIUtility.GUIToScreenPoint(position),
					this.parent.Editor.Focus, this.parent));
		}

		/*public void ContextAddAll(System.Object userData)
		{
			foreach(KeyValuePair<System.Type, NodeInfo> pair in this.nodeInfos)
			{
				if(pair.Key != this.gateType)
				{
					this.DoAddNode(ReflectionTypeHandler.Instance.CreateInstance(pair.Key) as BaseNode, true);
				}
			}
		}*/

		private void AddNodesToContext(ref List<ContextMenuPopup.Element> tree, ContextMenuPopup.Element parent)
		{
			Dictionary<string, ContextMenuPopup.Element> lookup = new Dictionary<string, ContextMenuPopup.Element>();
			//tree.Add(new ContextMenuPopup.ObjectMenuElement("Add All", "", this.ContextAddAll, -1));

			// layer gates
			ContextMenuPopup.TypeElement gateType = new ContextMenuPopup.TypeElement("Gate to Layer", "", parent);
			tree.Add(gateType);
			tree.Add(new ContextMenuPopup.ObjectMenuElement("Add New Layer", "", this.ContextAddGate, -1, gateType));
			for(int i = 0; i < this.layers.Length; i++)
			{
				if(i != this.currentLayer)
				{
					tree.Add(new ContextMenuPopup.ObjectMenuElement(i + ": " + this.layers[i], "", this.ContextAddGate, i, gateType));
				}
			}
			tree.Add(new ContextMenuPopup.SeparatorElement(parent));

			// add nodes alphabetically
			List<string> names = new List<string>();
			Dictionary<string, System.Type> tmp = new Dictionary<string, System.Type>();

			foreach(KeyValuePair<System.Type, NodeInfo> pair in this.nodeInfos)
			{
				if(pair.Key != this.gateType)
				{
					if(pair.Value.subMenu.Length == 0)
					{
						if(tmp.ContainsKey(pair.Value.content.text))
						{
							Debug.LogWarning("Node with the same name already exists: " +
								pair.Value.content.text + "\n" +
								"Please rename one of the nodes.");
						}
						else
						{
							names.Add(pair.Value.content.text);
							tmp.Add(pair.Value.content.text, pair.Key);
						}
					}
					else
					{
						for(int i = 0; i < pair.Value.subMenu.Length; i++)
						{
							if(tmp.ContainsKey(pair.Value.subMenu[i] + "/" + pair.Value.content.text))
							{
								Debug.LogWarning("Node with the same name already exists: " +
									pair.Value.subMenu[i] + "/" + pair.Value.content.text + "\n" +
									"Please rename one of the nodes.");
							}
							else
							{
								names.Add(pair.Value.subMenu[i] + "/" + pair.Value.content.text);
								tmp.Add(pair.Value.subMenu[i] + "/" + pair.Value.content.text, pair.Key);
							}
						}
					}
				}
			}
			names.Sort();

			string favoriteInfo = this.baseNodeType.FullName + ":";
			for(int i = 0; i < names.Count; i++)
			{
				string[] path = names[i].Split('/');
				ContextMenuPopup.Element pathParent = parent;
				string currentPath = "";
				for(int j = 0; j < path.Length; j++)
				{
					// node element
					if(j == path.Length - 1)
					{
						System.Type tmpType = tmp[names[i]];
						ContextMenuPopup.ObjectMenuElement element = new ContextMenuPopup.ObjectMenuElement(
							path[j], this.nodeInfos[tmp[names[i]]].content.tooltip,
							this.ContextAdd, tmpType, pathParent);
						element.FavoriteInformation = favoriteInfo + tmpType.Name;
						tree.Add(element);
					}
					// type element
					else
					{
						currentPath += path[j] + "/";
						ContextMenuPopup.Element tmpParent;
						if(!lookup.TryGetValue(currentPath, out tmpParent))
						{
							tmpParent = new ContextMenuPopup.TypeElement(path[j], "", pathParent);
							lookup.Add(currentPath, tmpParent);
							tree.Add(tmpParent);
						}
						pathParent = tmpParent;
					}
				}
			}
		}

		private void ContextAddGate(System.Object userData)
		{
			if(userData is int)
			{
				int layer = (int)userData;

				// new layer
				if(layer == -1)
				{
					this.layers = this.AddLayer();
					layer = this.layers.Length - 1;
				}

				// create gate
				this.DoAddNode(ReflectionTypeHandler.Instance.CreateInstance(this.gateType,
					new System.Type[] { typeof(int) },
					new System.Object[] { layer }) as BaseNode, false);
			}
		}

		private void ContextAdd(System.Object userData)
		{
			if(userData is System.Type)
			{
				this.DoAddNode(ReflectionTypeHandler.Instance.CreateInstance((System.Type)userData) as BaseNode, true);
			}
		}

		private void DoAddNode(BaseNode node, bool setNext)
		{
			node.nodeLayer = this.currentLayer;
			this.nodes = this.AddNode(node);
			NodeGroup group = null;

			if(this.IsNodeSelected)
			{
				BaseNode tmpNode = this.slotIndexNode != null ? this.slotIndexNode :
					this.focusedNode != null ? this.focusedNode :
					this.selectedNode[this.selectedNode.Count - 1];
				if(tmpNode is NodeGroup)
				{
					tmpNode = null;
					node.SetPosition(this.currentLayer, this.contextPosition - this.NodeScroll);
				}

				int parentIndex = -1;
				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					int index = this.selectedIndex == -1 || this.slotIndexNode != this.selectedNode[i] ?
						this.selectedNode[i].GetFirstFree() :
						this.selectedIndex;
					if(this.selectedNode[i] == tmpNode)
					{
						Vector2 position = tmpNode.GetPosition(this.currentLayer);
						position.x += NodeEditor.NODE_SIZE.x + NodeEditor.NODE_SPACING.x;
						position.y += (index > 0 ? index + 2 : 0) * NodeEditor.NODE_SIZE.y;
						node.SetPosition(this.currentLayer, position);
						if(setNext)
						{
							node.SetNext(0, tmpNode.GetNext(index));
						}
					}
					this.selectedNode[i].SetNext(index, this.nodes.Length - 1);

					if(group == null)
					{
						if(this.selectedNode[i] is NodeGroup)
						{
							group = this.selectedNode[i] as NodeGroup;
						}
						else
						{
							if(parentIndex == -1)
							{
								parentIndex = this.selectedNode[i].GetNodeGroup(this.currentLayer);
							}
							else if(parentIndex != this.selectedNode[i].GetNodeGroup(this.currentLayer))
							{
								parentIndex = -2;
							}
						}
					}
				}
				if(group == null &&
					parentIndex >= 0)
				{
					group = this.nodeGroups[parentIndex];
				}
			}
			else
			{
				node.SetPosition(this.currentLayer, this.contextPosition - this.NodeScroll);
			}

			if(this.snapToGrid)
			{
				this.SnapToGrid(node);
			}
			if(group != null)
			{
				this.DoAddNodeToGroup(group, node);
			}

			this.UpdateVisit();

			this.SelectNode(node, false, -1);
			this.focusedNode = node;
			this.selectedIndex = -1;
		}

		private void ContextCopyNode()
		{
			if(this.IsNodeSelected)
			{
				int nodeCount = this.nodes.Length;
				List<BaseNode> newNodes = new List<BaseNode>();
				NodeGroup group = this.GetSelectedGroup();

				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					BaseNode node = ReflectionTypeHandler.Instance.CreateInstance(this.selectedNode[i].GetType()) as BaseNode;
					node.SetData(this.selectedNode[i].GetData());

					int nextCount = node.GetType() == this.gateType &&
						node.nodeLayer == this.currentLayer ?
							0 : node.GetNextCount();
					for(int j = 0; j < nextCount; j++)
					{
						int next = this.selectedNode[i].GetNext(j);
						if(next >= 0 && next < nodeCount)
						{
							next = this.selectedNode.IndexOf(this.nodes[next]);
							if(next != -1)
							{
								next += nodeCount;
							}
						}
						else
						{
							next = -1;
						}

						node.SetNext(j, next);
					}
					this.nodes = this.AddNode(node);

					Vector2 position = this.selectedNode[i].GetPosition(this.currentLayer);
					position.x += NodeEditor.GRID_SIZE;
					position.y += NodeEditor.GRID_SIZE;
					node.SetPosition(this.currentLayer, position);

					if(this.snapToGrid)
					{
						this.SnapToGrid(node);
					}
					if(group != null)
					{
						this.DoAddNodeToGroup(group, node);
					}

					newNodes.Add(node);
				}

				this.UpdateVisit();

				this.ClearSelected();
				this.selectedNode.AddRange(newNodes);
			}
		}

		private void ContextCopyNodeToClipboard()
		{
			if(this.IsNodeSelected)
			{
				Vector2 basePosition = new Vector2(Mathf.Infinity, Mathf.Infinity);
				List<BaseNode> newNodes = new List<BaseNode>();

				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					BaseNode node = ReflectionTypeHandler.Instance.CreateInstance(this.selectedNode[i].GetType()) as BaseNode;
					node.SetData(this.selectedNode[i].GetData());

					int nextCount = node.GetType() == this.gateType &&
						node.nodeLayer == this.currentLayer ?
							0 : node.GetNextCount();
					for(int j = 0; j < nextCount; j++)
					{
						int next = this.selectedNode[i].GetNext(j);
						if(next >= 0 && next < this.nodes.Length)
						{
							next = this.selectedNode.IndexOf(this.nodes[next]);
						}
						else
						{
							next = -1;
						}

						node.SetNext(j, next);
					}

					Vector2 position = this.selectedNode[i].GetPosition(this.currentLayer);
					if(position.x < basePosition.x ||
						(position.x == basePosition.x &&
							position.y < basePosition.y))
					{
						basePosition = position;
					}

					newNodes.Add(node);
				}

				this.clipboard.Clear();

				for(int i = 0; i < newNodes.Count; i++)
				{
					newNodes[i].SetPosition(this.currentLayer,
						newNodes[i].GetPosition(this.currentLayer) - basePosition);

					this.clipboard.Add(new EditorClipboard(
						newNodes[i].GetData(),
						newNodes[i].GetType()));
				}
			}
		}

		private void ContextPasteNodeFromClipboard()
		{
			if(this.clipboard.Count > 0)
			{
				int nodeCount = this.nodes.Length;
				Vector2 basePosition = this.contextPosition - this.NodeScroll;

				BaseNode tmpNode = this.slotIndexNode != null ? this.slotIndexNode :
					this.focusedNode != null ? this.focusedNode :
					this.IsNodeSelected ?
						this.selectedNode[this.selectedNode.Count - 1] : null;
				if(tmpNode != null)
				{
					basePosition = tmpNode.GetPosition(this.currentLayer);
					basePosition.x += NodeEditor.NODE_SIZE.x + NodeEditor.NODE_SPACING.x;
					basePosition.y += tmpNode.GetFirstFree() * NodeEditor.NODE_SIZE.y;
				}

				int emptyNext = -1;
				if(this.IsNodeSelected)
				{
					if(this.selectedIndex != -1 && this.slotIndexNode != null)
					{
						emptyNext = this.slotIndexNode.GetNext(this.selectedIndex);
					}
					else
					{
						emptyNext = this.selectedNode[this.selectedNode.Count - 1].GetFirstFree();
						emptyNext = this.selectedNode[this.selectedNode.Count - 1].GetNext(emptyNext);
					}
				}

				List<int> unreferenced = new List<int>();
				for(int i = 0; i < this.clipboard.Count; i++)
				{
					unreferenced.Add(i);
				}

				BaseNode newSelection = null;
				NodeGroup group = this.GetSelectedGroup();
				for(int i = 0; i < this.clipboard.Count; i++)
				{
					BaseNode node = ReflectionTypeHandler.Instance.CreateInstance(this.clipboard[i].type) as BaseNode;
					if(newSelection == null)
					{
						newSelection = node;
					}
					node.SetData(this.clipboard[i].data);
					node.nodeLayer = this.currentLayer;
					node.SetNodeGroup(this.currentLayer, -1);

					bool nextSet = false;
					for(int j = 0; j < node.GetNextCount(); j++)
					{
						int next = node.GetNext(j);
						unreferenced.Remove(next);
						if(next == -1)
						{
							if(!nextSet)
							{
								node.SetNext(j, emptyNext);
								nextSet = true;
							}
						}
						else
						{
							node.SetNext(j, next + nodeCount);
						}
					}
					this.nodes = this.AddNode(node);

					node.SetPosition(this.currentLayer,
						node.GetPosition(this.currentLayer) + basePosition);

					if(this.snapToGrid)
					{
						this.SnapToGrid(node);
					}
					if(group != null)
					{
						this.DoAddNodeToGroup(group, node);
					}
				}

				if(unreferenced.Count > 0 && this.IsNodeSelected)
				{
					for(int i = 0; i < this.selectedNode.Count; i++)
					{
						int index = this.selectedIndex == -1 ||
							this.slotIndexNode != this.selectedNode[i] ?
								this.selectedNode[i].GetFirstFree() :
								this.selectedIndex;
						this.selectedNode[i].SetNext(index, unreferenced[0] + nodeCount);
					}
				}

				this.SelectNode(newSelection, false, -1);
			}
		}

		private void ContextPasteNodeSettings()
		{
			if(this.clipboard.Count > 0 &&
				this.IsNodeSelected)
			{
				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					if(this.selectedNode[i].GetType() != this.gateType &&
						this.selectedNode[i] != this.realStartNode)
					{
						for(int j = 0; j < this.clipboard.Count; j++)
						{
							Vector2 position = this.selectedNode[i].GetPosition(this.currentLayer);
							List<int> next = new List<int>();
							for(int k = 0; k < this.selectedNode[i].GetNextCount(); k++)
							{
								next.Add(this.selectedNode[i].GetNext(k));
							}

							int tmpGroup = this.selectedNode[i].GetNodeGroup(this.currentLayer);
							this.selectedNode[i].SetData(this.clipboard[j].data);
							this.selectedNode[i].SetNodeGroup(this.currentLayer, tmpGroup);
							this.selectedNode[i].SetPosition(this.currentLayer, position);

							for(int k = 0; k < this.selectedNode[i].GetNextCount(); k++)
							{
								this.selectedNode[i].SetNext(k, k < next.Count ? next[k] : -1);
							}
							j = this.clipboard.Count;
						}
					}
				}
			}
		}

		public void AddNodesFromExternal(List<BaseNode> addNodes)
		{
			if(addNodes.Count > 0)
			{
				int nodeCount = this.nodes.Length;
				Vector2 basePosition = this.contextPosition - this.NodeScroll;

				BaseNode tmpNode = this.slotIndexNode != null ? this.slotIndexNode :
					this.focusedNode != null ? this.focusedNode :
					this.IsNodeSelected ?
						this.selectedNode[this.selectedNode.Count - 1] : null;
				if(tmpNode != null)
				{
					basePosition = tmpNode.GetPosition(this.currentLayer);
					basePosition.x += NodeEditor.NODE_SIZE.x + NodeEditor.NODE_SPACING.x;
					basePosition.y += tmpNode.GetFirstFree() * NodeEditor.NODE_SIZE.y;
				}

				int emptyNext = -1;
				if(this.IsNodeSelected)
				{
					if(this.selectedIndex != -1 && this.slotIndexNode != null)
					{
						emptyNext = this.slotIndexNode.GetNext(this.selectedIndex);
					}
					else
					{
						emptyNext = this.selectedNode[this.selectedNode.Count - 1].GetFirstFree();
						emptyNext = this.selectedNode[this.selectedNode.Count - 1].GetNext(emptyNext);
					}
				}

				List<int> unreferenced = new List<int>();
				for(int i = 0; i < addNodes.Count; i++)
				{
					unreferenced.Add(i);
				}

				BaseNode newSelection = null;
				NodeGroup group = this.GetSelectedGroup();
				for(int i = 0; i < addNodes.Count; i++)
				{
					BaseNode node = addNodes[i];
					if(newSelection == null)
					{
						newSelection = node;
					}
					node.nodeLayer = this.currentLayer;

					bool nextSet = false;
					for(int j = 0; j < node.GetNextCount(); j++)
					{
						int next = node.GetNext(j);
						unreferenced.Remove(next);
						if(next == -1)
						{
							if(!nextSet)
							{
								node.SetNext(j, emptyNext);
								nextSet = true;
							}
						}
						else
						{
							node.SetNext(j, next + nodeCount);
						}
					}
					this.nodes = this.AddNode(node);

					node.SetPosition(this.currentLayer, basePosition);

					if(this.snapToGrid)
					{
						this.SnapToGrid(node);
					}
					if(group != null)
					{
						this.DoAddNodeToGroup(group, node);
					}
				}

				if(unreferenced.Count > 0 && this.IsNodeSelected)
				{
					for(int i = 0; i < this.selectedNode.Count; i++)
					{
						int index = this.selectedIndex == -1 ||
							this.slotIndexNode != this.selectedNode[i] ?
								this.selectedNode[i].GetFirstFree() :
								this.selectedIndex;
						this.selectedNode[i].SetNext(index, unreferenced[0] + nodeCount);
					}
				}

				this.SelectNode(newSelection, false, -1);

				if(newSelection != null)
				{
					Vector2 p = newSelection.GetPosition(this.currentLayer);
					int h = 0;
					List<BaseNode> tmp = new List<BaseNode>();
					this.SortHorizontal(addNodes, tmp, newSelection, ref p, ref h);
				}
			}
		}

		private void ContextRemoveConnection()
		{
			this.slotIndexNode.SetNext(this.selectedIndex, -1);
			this.UpdateVisit();
		}

		private void ContextRemoveNode()
		{
			if(this.IsNodeSelected)
			{
				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					if(this.selectedNode[i] is NodeGroup)
					{
						this.DoRemoveNodeGroup((NodeGroup)this.selectedNode[i]);
					}
					else
					{
						this.DoRemoveNode(this.selectedNode[i], false);
					}
				}

				this.ClearSelected();
				this.UpdateVisit();
			}
		}

		private void DoRemoveNode(BaseNode node, bool reset)
		{
			// find node index
			int index = -1;
			for(int i = 0; i < this.nodes.Length; i++)
			{
				if(this.nodes[i] == node)
				{
					index = i;
					break;
				}
			}

			if(node.GetType() == this.gateType)
			{
				reset = true;
			}

			if(index >= 0 && index < this.nodes.Length)
			{
				// check start node
				if(this.realStartNode != null)
				{
					int nextCount = this.realStartNode.GetNextCount();
					for(int j = 0; j < nextCount; j++)
					{
						NodeEditor.CheckRemovedNode(index, node.GetNext(0), this.realStartNode, j, reset);
					}
				}

				// check node list
				for(int i = 0; i < this.nodes.Length; i++)
				{
					int nextCount = this.nodes[i].GetType() == this.gateType && this.nodes[i].nodeLayer == this.currentLayer ?
						0 : this.nodes[i].GetNextCount();
					for(int j = 0; j < nextCount; j++)
					{
						NodeEditor.CheckRemovedNode(index, node.GetNext(0), this.nodes[i], j, reset);
					}
				}
				this.nodes = this.RemoveNode(node);
			}
		}

		private void ContextRemoveChain()
		{
			if(this.IsNodeSelected)
			{
				List<BaseNode> list = new List<BaseNode>();
				this.GetChildNodes(ref list, this.selectedNode);

				for(int i = 0; i < list.Count; i++)
				{
					this.DoRemoveNode(list[i], true);
				}

				this.ClearSelected();
				this.UpdateVisit();
			}
		}

		private void ContextAddNodeGroup()
		{
			NodeGroup group = new NodeGroup(this.nodeGroups.Length);
			group.ClearNodes();
			group.nodeLayer = this.currentLayer;
			this.nodeGroups = this.AddNodeGroup(group);
			group.SetPosition(this.currentLayer, this.contextPosition - this.NodeScroll);

			if(this.IsNodeSelected)
			{
				int index = this.nodeGroups.Length - 1;
				NodeGroup parentGroup = null;
				int parentIndex = -1;

				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					if(this.selectedNode[i] is NodeGroup)
					{
						if(parentGroup == null)
						{
							parentGroup = (NodeGroup)this.selectedNode[i];
						}
					}
					else
					{
						int tmpIndex = this.selectedNode[i].GetNodeGroup(this.currentLayer);
						if(tmpIndex != -1)
						{
							if(parentIndex == -1)
							{
								parentIndex = tmpIndex;
							}
							else if(parentIndex != tmpIndex)
							{
								parentIndex = -2;
							}
						}
						this.selectedNode[i].SetNodeGroup(this.currentLayer, index);
					}
				}

				if(parentGroup != null)
				{
					for(int i = 0; i < this.nodeGroups.Length; i++)
					{
						if(this.nodeGroups[i] == parentGroup)
						{
							group.SetNodeGroup(this.currentLayer, i);
							break;
						}
					}
				}
				else if(parentIndex >= 0)
				{
					group.SetNodeGroup(this.currentLayer, parentIndex);
				}
			}

			if(this.snapToGrid)
			{
				this.SnapToGrid(group);
			}

			this.SelectNode(group, false, -1);
			this.focusedNode = group;
			this.selectedIndex = -1;
		}

		private void ContextAddToNodeGroup(object value)
		{
			if(value is int)
			{
				int index = (int)value;
				if(index == -1)
				{
					NodeGroup group = new NodeGroup(this.nodeGroups.Length);
					group.ClearNodes();
					group.nodeLayer = this.currentLayer;
					this.nodeGroups = this.AddNodeGroup(group);
					group.SetPosition(this.currentLayer, this.contextPosition - this.NodeScroll);
					index = this.nodeGroups.Length - 1;

					int parentIndex = -1;
					for(int i = 0; i < this.selectedNode.Count; i++)
					{
						if(parentIndex == -1)
						{
							parentIndex = this.selectedNode[i].GetNodeGroup(this.currentLayer);
						}
						else if(parentIndex != this.selectedNode[i].GetNodeGroup(this.currentLayer))
						{
							parentIndex = -2;
						}
					}
					if(parentIndex >= 0)
					{
						group.SetNodeGroup(this.currentLayer, parentIndex);
					}
				}
				if(index >= 0 &&
					index < this.nodeGroups.Length)
				{
					for(int i = 0; i < this.selectedNode.Count; i++)
					{
						if(this.selectedNode[i] is NodeGroup)
						{
							if(this.selectedNode[i] != this.nodeGroups[index] &&
								!this.CheckGroupLoop((NodeGroup)this.selectedNode[i], index))
							{
								this.selectedNode[i].SetNodeGroup(this.currentLayer, index);
							}
						}
						else
						{
							this.selectedNode[i].SetNodeGroup(this.currentLayer, index);
						}
					}
				}
			}
		}

		private bool CheckGroupLoop(NodeGroup group, int index)
		{
			if(index >= 0)
			{
				if(this.nodeGroups[index] == group)
				{
					return true;
				}
				else
				{
					return this.CheckGroupLoop(group, this.nodeGroups[index].GetNodeGroup(this.currentLayer));
				}
			}
			return false;
		}

		private void ContextRemoveFromNodeGroup()
		{
			for(int i = 0; i < this.selectedNode.Count; i++)
			{
				this.selectedNode[i].SetNodeGroup(this.currentLayer, -1);
			}
		}

		private void ContextRemoveNodeGroup()
		{
			if(this.IsNodeSelected)
			{
				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					if(this.selectedNode[i] is NodeGroup)
					{
						this.DoRemoveNodeGroup((NodeGroup)this.selectedNode[i]);
					}
				}

				this.UpdateVisit();
			}
		}

		private void DoRemoveNodeGroup(NodeGroup group)
		{
			if(group != null)
			{
				int index = -1;
				for(int i = 0; i < this.nodeGroups.Length; i++)
				{
					if(this.nodeGroups[i] == group)
					{
						index = i;
						break;
					}
				}

				if(index >= 0)
				{
					int parentIndex = group.GetNodeGroup(this.currentLayer);
					for(int i = 0; i < group.Nodes.Count; i++)
					{
						group.Nodes[i].SetNodeGroup(this.currentLayer, parentIndex);
					}
					group.ClearNodes();


					this.nodeGroups = this.RemoveNodeGroup(group);

					for(int i = 0; i < this.nodeGroups.Length; i++)
					{
						this.nodeGroups[i].GroupRemoved(index);
					}
					for(int i = 0; i < this.nodes.Length; i++)
					{
						this.nodes[i].GroupRemoved(index);
					}
				}
			}
		}

		private void DoAddNodeToGroup(NodeGroup group, BaseNode node)
		{
			if(group != null && node != null)
			{
				for(int i = 0; i < this.nodeGroups.Length; i++)
				{
					if(this.nodeGroups[i] == group)
					{
						node.SetNodeGroup(this.currentLayer, i);
						break;
					}
				}
			}
		}

		private void ContextSortHorizontal()
		{
			Vector2 p = this.IsNodeSelected ?
				this.selectedNode[this.selectedNode.Count - 1].GetPosition(this.currentLayer) :
				NodeEditor.NODE_START_POSITION;
			int h = 0;
			List<BaseNode> tmp = new List<BaseNode>();
			this.SortHorizontal(tmp, this.IsNodeSelected ?
				this.selectedNode[this.selectedNode.Count - 1] :
				this.startNode, ref p, ref h);
		}

		private void ContextSortVertical()
		{
			Vector2 p = this.IsNodeSelected ?
				this.selectedNode[this.selectedNode.Count - 1].GetPosition(this.currentLayer) :
				NodeEditor.NODE_START_POSITION;
			List<BaseNode> tmp = new List<BaseNode>();
			this.SortVertical(tmp, this.IsNodeSelected ?
				this.selectedNode[this.selectedNode.Count - 1] :
				this.startNode, ref p);
		}

		private void ContextPlaceOnGrid()
		{
			if(this.IsNodeSelected)
			{
				List<BaseNode> tmp = new List<BaseNode>();
				for(int i = 0; i < this.selectedNode.Count; i++)
				{
					this.PlaceOnGrid(tmp, this.selectedNode[i]);
				}
			}
			else
			{
				this.SnapToGrid(this.startNode);
				for(int i = 0; i < this.nodes.Length; i++)
				{
					if(this.nodes[i].IsOnLayer(this.currentLayer))
					{
						this.SnapToGrid(this.nodes[i]);
					}
				}
			}
		}

		private void ContextSwapNodes()
		{
			if(this.selectedNode.Count == 2 &&
				!this.IsTypeSelected(this.gateType) &&
				!this.selectedNode.Contains(this.startNode))
			{
				int index = -1;
				int index2 = -1;
				for(int i = 0; i < this.nodes.Length; i++)
				{
					if(this.nodes[i] == this.selectedNode[0])
					{
						index = i;
						if(index2 != -1)
						{
							break;
						}
					}
					else if(this.nodes[i] == this.selectedNode[1])
					{
						index2 = i;
						if(index != -1)
						{
							break;
						}
					}
				}

				if(index != -1 && index2 != -1)
				{
					BaseNode node = this.nodes[index];
					this.nodes[index] = this.nodes[index2];
					this.nodes[index2] = node;

					Vector2 position = node.nodePosition;
					node.nodePosition = this.nodes[index].nodePosition;
					this.nodes[index].nodePosition = position;

					for(int i = 0; i < node.GetNextCount(); i++)
					{
						if(i < this.nodes[index].GetNextCount())
						{
							int next = this.nodes[index].GetNext(i);
							this.nodes[index].SetNext(i, node.GetNext(i));
							node.SetNext(i, next);
						}
					}
				}
			}
		}

		private void ContextMoveToLayer(System.Object userData)
		{
			if(userData is int &&
				this.IsNodeSelected)
			{
				int newLayer = (int)userData;

				// new layer
				if(newLayer == -1)
				{
					this.layers = this.AddLayer();
					newLayer = this.layers.Length - 1;
				}

				// check gates
				List<BaseNode> list = new List<BaseNode>();
				this.GetChildNodes(ref list, this.selectedNode);
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].GetType() == this.gateType &&
						list[i].IsOnLayer(newLayer))
					{
						this.DoRemoveNode(list[i], false);
					}
				}

				// move nodes to layer
				list.Clear();
				this.GetChildNodes(ref list, this.selectedNode);
				for(int i = 0; i < list.Count; i++)
				{
					list[i].nodeLayer = newLayer;
				}

				// create gate
				for(int i = 0; i < list.Count; i++)
				{
					if(this.HasConnections(list[i], false))
					{
						this.ReplaceWithGate(list[i], newLayer);
					}
				}

				// go to new layer
				this.currentLayer = newLayer;
				this.isFirstFocus = true;
				this.UpdateVisit();
			}
		}

		private void ContextViewFromHere()
		{
			this.newStartNode = this.selectedNode[this.selectedNode.Count - 1];
		}

		private void ContextViewAll()
		{
			this.newStartNode = null;
		}


		/*
		============================================================================
		Connection functions
		============================================================================
		*/
		private int GetIndex(BaseNode node)
		{
			for(int i = 0; i < this.nodes.Length; i++)
			{
				if(this.nodes[i] == node)
				{
					return i;
				}
			}
			return -1;
		}

		private bool HasConnections(BaseNode node, bool allLayers)
		{
			int index = this.GetIndex(node);

			if(index >= 0)
			{
				if(this.realStartNode != null)
				{
					int nextCount = this.realStartNode.GetNextCount();
					for(int j = 0; j < nextCount; j++)
					{
						if(this.realStartNode.GetNext(j) == index)
						{
							return true;
						}
					}
				}
				for(int i = 0; i < this.nodes.Length; i++)
				{
					if(allLayers || this.nodes[i].IsOnLayer(this.currentLayer))
					{
						int nextCount = this.nodes[i].GetType() == this.gateType &&
							this.nodes[i].nodeLayer == this.currentLayer ?
							0 : this.nodes[i].GetNextCount();
						for(int j = 0; j < nextCount; j++)
						{
							if(this.nodes[i].GetNext(j) == index)
							{
								return true;
							}
						}
					}
				}
			}
			return false;
		}

		public static void CheckRemovedNode(int index, int check, BaseNode node, int j, bool reset)
		{
			if(reset)
			{
				if(node.GetNext(j) == index)
				{
					node.SetNext(j, -1);
				}
				else if(node.GetNext(j) > index)
				{
					node.SetNext(j, node.GetNext(j) - 1);
				}
			}
			else if(node.GetNext(j) == index)
			{
				if(check == index || check == node.GetNext(j))
				{
					node.SetNext(j, -1);
				}
				else if(check > index)
				{
					node.SetNext(j, check - 1);
				}
				else
				{
					node.SetNext(j, check);
				}
			}
			else if(node.GetNext(j) > index)
			{
				node.SetNext(j, node.GetNext(j) - 1);
			}
		}

		private void ReplaceWithGate(BaseNode replace, int layer)
		{
			int index = this.GetIndex(replace);

			BaseNode node = ReflectionTypeHandler.Instance.CreateInstance(this.gateType,
				new System.Type[] { typeof(int) },
				new System.Object[] { layer }) as BaseNode;
			node.nodeLayer = this.currentLayer;
			node.SetNext(0, index);
			node.nodePosition = replace.nodePosition;
			this.nodes = this.AddNode(node);

			// change connections
			this.ChangeConnections(this.nodes.Length - 1, index, false);
		}

		private void ChangeConnections(int newIndex, int oldIndex, bool allLayers)
		{
			// check start node
			if(this.realStartNode != null)
			{
				int nextCount = this.realStartNode.GetNextCount();
				for(int j = 0; j < nextCount; j++)
				{
					this.ChangeConnection(newIndex, oldIndex, this.realStartNode, j);
				}
			}

			// check node list
			for(int i = 0; i < this.nodes.Length; i++)
			{
				if(allLayers || this.nodes[i].IsOnLayer(this.currentLayer))
				{
					int nextCount = this.nodes[i].GetType() == this.gateType &&
						this.nodes[i].nodeLayer == this.currentLayer ?
						0 : this.nodes[i].GetNextCount();
					for(int j = 0; j < nextCount; j++)
					{
						this.ChangeConnection(newIndex, oldIndex, this.nodes[i], j);
					}
				}
			}
		}

		private void ChangeConnection(int newIndex, int oldIndex, BaseNode node, int j)
		{
			if(node.GetNext(j) == oldIndex)
			{
				node.SetNext(j, newIndex);
			}
		}
	}
}
