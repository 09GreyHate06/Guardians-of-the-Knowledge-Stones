﻿
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public abstract class SceneWizard_BaseCreateObject
	{
		
	}

	[EditorSettingInfo("Music Player", "")]
	public class SceneWizard_CreateObject_MusicPlayer : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreateMusicPlayer();
		}
	}

	[EditorSettingInfo("Music Player 2D", "")]
	public class SceneWizard_CreateObject_MusicPlayer2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreateMusicPlayer2D();
		}
	}

	[EditorSettingInfo("Music Player 3D", "")]
	public class SceneWizard_CreateObject_MusicPlayer3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreateMusicPlayer3D();
		}
	}

	[EditorSettingInfo("Pool", "")]
	public class SceneWizard_CreateObject_Pool : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreatePool();
		}
	}

	[EditorSettingInfo("Camera Event", "")]
	public class SceneWizard_CreateObject_CameraEvent : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreateCameraEvent();
		}
	}

	[EditorSettingInfo("Scene Changer 2D", "")]
	public class SceneWizard_CreateObject_SceneChanger2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreateSceneChanger2D();
		}
	}

	[EditorSettingInfo("Scene Changer 3D", "")]
	public class SceneWizard_CreateObject_SceneChanger3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreateSceneChanger3D();
		}
	}

	[EditorSettingInfo("Spawn Point", "")]
	public class SceneWizard_CreateObject_SpawnPoint : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreateSpawnPoint();
		}
	}

	[EditorSettingInfo("Waypoint Path", "")]
	public class SceneWizard_CreateObject_WaypointPath : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreateWaypointPath();
		}
	}

	[EditorSettingInfo("Game Object Manager", "")]
	public class SceneWizard_CreateObject_GameObjectManager : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			SceneObjectHelper.CreateSimple<GameObjectManager>("Game Object Manager");
		}
	}

	[EditorSettingInfo("Interaction Controller 2D", "")]
	public class SceneWizard_CreateObject_InteractionController2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreateInteractionController2D();
		}
	}

	[EditorSettingInfo("Interaction Controller 3D", "")]
	public class SceneWizard_CreateObject_InteractionController3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			UnityMenuUtility.CreateInteractionController3D();
		}
	}
}
