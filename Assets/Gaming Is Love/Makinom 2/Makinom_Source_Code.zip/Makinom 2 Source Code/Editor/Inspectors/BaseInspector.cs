
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class BaseInspector : UnityEditor.Editor
	{
		protected BaseEditor baseEditor;

		protected bool fold1 = true;

		protected bool fold2 = true;

		protected bool fold3 = true;

		protected bool fold4 = true;

		protected bool fold5 = true;

		protected bool fold6 = true;

		protected bool fold7 = true;

		protected bool fold8 = true;

		public void BaseInit(bool showButtons)
		{
			if(this.baseEditor == null)
			{
				this.baseEditor = new BaseEditor(true, this.Repaint);
			}
			if(!Maki.Instantiated)
			{
				Maki.Initialize(MakinomAssetHelper.LoadProjectAsset());
			}
			if(this.baseEditor.BlockScroll &&
				Event.current.type == EventType.ScrollWheel)
			{
				Event.current.Use();
			}

			this.baseEditor.ClearShow();

			if(showButtons)
			{
				EditorGUILayout.BeginHorizontal();
				if(EditorTool.Button("Close All"))
				{
					this.CloseAll();
				}
				if(EditorTool.Button("Open All"))
				{
					this.OpenAll();
				}
				EditorGUILayout.EndHorizontal();
			}
		}

		protected virtual void CloseAll()
		{
			this.fold1 = false;
			this.fold2 = false;
			this.fold3 = false;
			this.fold4 = false;
			this.fold5 = false;
			this.fold6 = false;
			this.fold7 = false;
			this.fold8 = false;
			this.baseEditor.ExpandFoldouts(false);
		}

		protected virtual void OpenAll()
		{
			this.fold1 = true;
			this.fold2 = true;
			this.fold3 = true;
			this.fold4 = true;
			this.fold5 = true;
			this.fold6 = true;
			this.fold8 = true;
			this.baseEditor.ExpandFoldouts(true);
		}

		protected virtual void EndSetup()
		{
			serializedObject.ApplyModifiedProperties();
			PrefabUtility.RecordPrefabInstancePropertyModifications(target);
			if(GUI.changed)
			{
				EditorUtility.SetDirty(target);
			}
		}

		protected virtual void ShowSettings(IBaseData settings, bool showButtons)
		{
			Undo.RecordObject(target, "Change to " + target.GetType().Name + " on " + target.name);
			this.BaseInit(showButtons);

			EditorAutomation.Automate(settings, this.baseEditor);
			EditorGUILayout.Separator();

			this.EndSetup();
		}

		protected virtual void ShowBaseInteraction(BaseInteractionComponent target)
		{
			// start settings
			if(this.baseEditor.BeginFoldout("Start Settings", "Define how this interaction can be started.", "", true))
			{
				// quick setup
				EditorGUILayout.BeginHorizontal();
				if(GUILayout.Button(new GUIContent("None", "Disables all start types.")))
				{
					target.startSettings.DisableAll();
				}
				if(GUILayout.Button(new GUIContent("Autostart",
					"Automatically start this interaction.\n" +
					"Enables 'Start' in the 'Auto' start types, disabling all others.")))
				{
					target.startSettings.DisableAll();
					target.startSettings.autoStartSetting.isStart = true;
				}
				if(GUILayout.Button(new GUIContent("Interact",
					"Start this interaction by player interaction (e.g. 'Interaction Controller' and interact key).\n" +
					"Enables 'Interact' in the 'Interaction' start types, disabling all others.")))
				{
					target.startSettings.DisableAll();
					target.startSettings.interactStartSetting.isInteract = true;
				}
				if(GUILayout.Button(new GUIContent("Trigger Enter",
					"Start this interaction by entering an attached trigger (collider with 'Is Trigger' enabled).\n" +
					"Enables 'Trigger Enter' in the 'Trigger' start types, disabling all others.")))
				{
					target.startSettings.DisableAll();
					target.startSettings.triggerStartSetting.isTriggerEnter = true;
				}
				EditorGUILayout.EndHorizontal();
				// start type info
				List<string> startTypes = target.startSettings.GetUsedStartTypeNames();
				if(startTypes.Count == 0)
				{
					EditorGUILayout.HelpBox("No start types enabled.", MessageType.Error);
				}
				else
				{
					string text = "Start Types: " + startTypes[0];
					for(int i = 1; i < startTypes.Count; i++)
					{
						text += ", " + startTypes[i];
					}
					EditorGUILayout.HelpBox(text, MessageType.Info);
				}
				// settings
				EditorAutomation.Automate(target.startSettings, this.baseEditor);
				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();

			this.ShowBaseCondition(target);
		}

		protected virtual void ShowBaseCondition(BaseConditionComponent target)
		{
			// condition settings
			if(this.baseEditor.BeginFoldout("Condition Settings", "Define the conditions that must be valid.", "", true))
			{
				EditorAutomation.Automate(target.conditionSetting, this.baseEditor);
				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();
		}

		protected virtual void ShowSceneID<T>(T target, string infoText) where T : Behaviour, ISceneID
		{
			EditorGUILayout.BeginHorizontal();
			target.UseSceneID = EditorGUILayout.ToggleLeft("Use Scene ID", target.UseSceneID, EditorTool.WIDTH_150);
			if(target.UseSceneID)
			{
				target.SceneID = EditorGUILayout.IntField(target.SceneID);
				if(target.SceneID < 0)
				{
					target.SceneID = 0;
				}
			}
			EditorGUILayout.EndHorizontal();
			if(target.UseSceneID)
			{
				if(infoText != null)
				{
					EditorGUILayout.HelpBox(infoText, MessageType.Info);
				}
				EditorGUILayout.BeginHorizontal();
				if(GUILayout.Button("Get New Scene ID") ||
					target.SceneID == -1)
				{
					SceneObjectHelper.SetNextSceneID<T>(target);
				}
				if(GUILayout.Button("Reset All Scene IDs"))
				{
					SceneObjectHelper.ResetAllSceneIDs<T>();
				}
				EditorGUILayout.EndHorizontal();
			}
		}

		protected virtual void ShowGlobalSceneID<T>(T target, string infoText) where T : Behaviour, IGlobalSceneID
		{
			EditorGUILayout.BeginHorizontal();
			target.UseSceneID = EditorGUILayout.ToggleLeft("Use Scene ID", target.UseSceneID, EditorTool.WIDTH_150);
			if(target.UseSceneID)
			{
				target.SceneID = EditorGUILayout.IntField(target.SceneID);
				if(target.SceneID < 0)
				{
					target.SceneID = 0;
				}
				target.IsGlobalSceneID = EditorGUILayout.ToggleLeft("Is Global", target.IsGlobalSceneID, EditorTool.W_SMALL_BUTTON);
			}
			EditorGUILayout.EndHorizontal();
			if(target.UseSceneID)
			{
				if(infoText != null)
				{
					EditorGUILayout.HelpBox(infoText, MessageType.Info);
					if(!target.IsGlobalSceneID)
					{
						EditorGUILayout.BeginHorizontal();
						if(GUILayout.Button("Get New Scene ID") ||
							target.SceneID == -1)
						{
							SceneObjectHelper.SetNextSceneID<T>(target);
						}
						if(GUILayout.Button("Reset All Scene IDs"))
						{
							SceneObjectHelper.ResetAllSceneIDs<T>();
						}
						EditorGUILayout.EndHorizontal();
					}
				}
			}
		}

		protected virtual void ShowSceneGUID<T>(T target, string toggleName, string buttonName, string infoText) where T : Behaviour, ISceneGUID
		{
			EditorGUILayout.BeginHorizontal();
			target.UseSceneGUID = EditorGUILayout.ToggleLeft(toggleName, target.UseSceneGUID, EditorTool.WIDTH_150);
			if(target.UseSceneGUID)
			{
				target.SceneGUID = EditorGUILayout.TextField(target.SceneGUID);
			}
			EditorGUILayout.EndHorizontal();
			if(target.UseSceneGUID)
			{
				if(infoText != null)
				{
					EditorGUILayout.HelpBox(infoText, MessageType.Info);
				}
				if(GUILayout.Button(buttonName) ||
					target.SceneGUID == "")
				{
					target.SceneGUID = System.Guid.NewGuid().ToString();
				}
			}
		}

		protected virtual void ShowGlobalSceneGUID<T>(T target, string toggleName, string buttonName, string infoText) where T : Behaviour, IGlobalSceneGUID
		{
			EditorGUILayout.BeginHorizontal();
			target.UseSceneGUID = EditorGUILayout.ToggleLeft(toggleName, target.UseSceneGUID, EditorTool.WIDTH_150);
			if(target.UseSceneGUID)
			{
				target.SceneGUID = EditorGUILayout.TextField(target.SceneGUID);
				target.IsGlobalSceneGUID = EditorGUILayout.ToggleLeft("Is Global", target.IsGlobalSceneGUID, EditorTool.W_SMALL_BUTTON);
			}
			EditorGUILayout.EndHorizontal();
			if(target.UseSceneGUID)
			{
				if(infoText != null)
				{
					EditorGUILayout.HelpBox(infoText, MessageType.Info);
				}
				if(GUILayout.Button(buttonName) ||
					target.SceneGUID == "")
				{
					target.SceneGUID = System.Guid.NewGuid().ToString();
				}
			}
		}

		protected virtual bool ShowGameStarterProjectSettings(GameStarter target)
		{
			bool showSettings = false;
			target.useAssetBundle = EditorGUILayout.Toggle("Use Asset Bundle", target.useAssetBundle);
			if(target.useAssetBundle)
			{
				if(target.project != null)
				{
					string assetPath = AssetDatabase.GetAssetPath(target.project);
					string bundleName = AssetDatabase.GetImplicitAssetBundleName(assetPath);

					if(string.IsNullOrEmpty(bundleName))
					{
						assetPath = "";
					}
					else
					{
						string variant = AssetDatabase.GetImplicitAssetBundleVariantName(assetPath);
						if(string.IsNullOrEmpty(variant))
						{
							assetPath = bundleName;
						}
						else
						{
							assetPath = bundleName + "." + variant;
						}
					}
					target.assetBundle.assetName = target.project.name;
					target.assetBundle.assetBundleName = assetPath;
					target.project = null;
				}

				EditorAutomation.Automate(target.assetBundle, this.baseEditor);

				if(!string.IsNullOrEmpty(target.assetBundle.assetName) &&
					!string.IsNullOrEmpty(target.assetBundle.assetBundleName))
				{
					showSettings = true;
				}
			}
			else
			{
				if(!string.IsNullOrEmpty(target.assetBundle.assetName) &&
					   !string.IsNullOrEmpty(target.assetBundle.assetBundleName))
				{
					string[] paths = AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName(
						target.assetBundle.assetBundleName, target.assetBundle.assetName);
					for(int i = 0; i < paths.Length; i++)
					{
						target.project = AssetDatabase.LoadAssetAtPath<MakinomProjectAsset>(paths[i]);
						if(target.project != null)
						{
							break;
						}
					}
					target.assetBundle.assetName = "";
					target.assetBundle.assetBundleName = "";
				}

				target.project = (MakinomProjectAsset)EditorGUILayout.ObjectField("Project Asset",
					target.project, typeof(MakinomProjectAsset), false);

				if(target.project != null)
				{
					showSettings = true;
				}
			}
			return showSettings;
		}


		/*
		============================================================================
		SerializedProperty functions
		============================================================================
		*/
		protected virtual void ShowSerializedProperty(string name)
		{
			SerializedProperty property = serializedObject.FindProperty(name);
			if(property != null)
			{
				EditorGUILayout.PropertyField(property, true);
			}
		}

		protected virtual void ShowSerializedPropertyChildren(SerializedProperty property,
			string name, string helpText, string helpInfo, bool expanded)
		{
			if(property != null)
			{
				if(this.baseEditor.BeginFoldout(name, helpText, helpInfo, expanded))
				{
					foreach(SerializedProperty childProperty in property.GetVisibleChildren())
					{
						EditorGUILayout.PropertyField(childProperty);
					}
				}
				this.baseEditor.EndFoldout();
			}
		}
	}
}
