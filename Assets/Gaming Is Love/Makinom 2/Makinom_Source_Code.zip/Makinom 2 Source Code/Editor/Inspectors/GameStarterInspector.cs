
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(GameStarter))]
public class GameStarterInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as GameStarter);
	}
	
	private void ComponentSetup(GameStarter target)
	{
		Undo.RecordObject(target, "Change to 'Makinom Game Starter' on " + target.name);
		this.BaseInit(false);

		// settings
		if(this.baseEditor.BeginFoldout("Makinom Game Start Settings", "", "", true))
		{
			if(this.ShowGameStarterProjectSettings(target))
			{
				target.startGame = EditorGUILayout.Toggle("Start Game", target.startGame);

				target.schematicAsset = (GamingIsLove.Makinom.MakinomSchematicAsset)EditorGUILayout.ObjectField(
					"Start Schematic Asset", target.schematicAsset, typeof(GamingIsLove.Makinom.MakinomSchematicAsset), false);
			}

			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.EndSetup();
	}
}
