
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class BaseMachineInspector : BaseInspector
	{
		protected string lastSchematicSaveTime = "";

		protected bool firstLoad = false;

		protected virtual void BaseMachineSetup(BaseMachineComponent target)
		{
			if(!Application.isPlaying)
			{
				if(target.assetSetting.schematicAsset != null &&
					this.lastSchematicSaveTime != target.assetSetting.schematicAsset.SaveTime)
				{
					this.firstLoad = false;
				}
				if(!this.firstLoad)
				{
					this.firstLoad = true;
					target.LoadSchematicEditor();

					if(target.assetSetting.schematicAsset != null)
					{
						this.lastSchematicSaveTime = target.assetSetting.schematicAsset.SaveTime;
					}
					else
					{
						this.lastSchematicSaveTime = "";
					}
				}
			}


			// machine execution settings
			if(this.baseEditor.BeginFoldout("Machine Execution Settings", "", "", true))
			{
				this.ShowMachineSetup(target);
				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();

			if(target.assetSetting.schematicAsset != null)
			{
				this.ShowMachineActors(target);
				this.ShowMachineResources(target.resources, target.assetSetting.schematicAsset.Settings);
			}


			// condition settings
			if(this.baseEditor.BeginFoldout("Condition Settings", "", "", true))
			{
				EditorAutomation.Automate(target.conditionSetting, this.baseEditor);

				if(GUILayout.Button(new GUIContent("Add 'In Control' Condition", EditorContent.Instance.AddIcon,
					"Adds a condition for the player being in control.\n" +
					"Requires a game state that reacts to 'Unblock Player Control' (auto activate) and 'Block Player Control' (auto inactive).")))
				{
					GameStateAsset asset = Maki.GameStates.FindInControlState();
					if(asset != null)
					{
						GameStateComponentCondition stateCondition = new GameStateComponentCondition();
						stateCondition.gameStates.gameState = new GameStateConditionCheck[] { new GameStateConditionCheck() };
						stateCondition.gameStates.gameState[0].gameState.state.SetAsset(asset);
						ComponentCondition condition = new ComponentCondition();
						condition.settings = stateCondition;
						condition.type = condition.settings.GetType().ToString();
						ArrayHelper.Add(ref target.conditionSetting.condition, condition);
					}
				}
				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();


			// local start variables
			if(this.baseEditor.BeginFoldout("Local Start Variables", "", "", true))
			{
				EditorAutomation.Automate(target.startVariableSetting, this.baseEditor);
				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();


			// change after execution
			if(this.baseEditor.BeginFoldout("Change After Execution", "", "", true))
			{
				EditorAutomation.Automate(target.changeAfterSetting, this.baseEditor);
				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();
		}

		protected virtual void ShowMachineSetup(BaseMachineComponent target)
		{
			MakinomSchematicAsset tmpAsset = target.assetSetting.schematicAsset;

			// buttons
			EditorGUILayout.BeginHorizontal();
			if(EditorTool.Button(new GUIContent("Create Schematic", EditorContent.Instance.PlusIcon, "Creates a new schematic.")))
			{
				string path = EditorUtility.SaveFilePanelInProject("Save Schematic Asset", "", "asset",
					"Please enter the name of the asset file that will be created.\n" +
					"Existing files will be replaced!");
				if(path.Length != 0)
				{
					target.assetSetting.schematicAsset = MakinomAssetHelper.SaveSchematic(null, path);
					target.LoadSchematicEditor();
					MakinomEditorWindow.ShowMakinomEditor(target.assetSetting.schematicAsset, target.RuntimeSchematic);
					EditorGUIUtility.ExitGUI();
				}
			}
			EditorGUI.BeginDisabledGroup(target.assetSetting.schematicAsset == null);
			if(EditorTool.Button(new GUIContent("Edit Schematic", EditorContent.Instance.EditIcon, "Open the schematic in the editor.")))
			{
				MakinomEditorWindow.ShowMakinomEditor(target.assetSetting.schematicAsset, target.RuntimeSchematic);
				return;
			}
			EditorGUI.EndDisabledGroup();
			EditorGUILayout.EndHorizontal();

			// settings
			EditorAutomation.Automate(target.assetSetting, this.baseEditor);

			// check schematic asset file change
			if(tmpAsset != target.assetSetting.schematicAsset)
			{
				target.LoadSchematicEditor();
			}
		}

		protected virtual void ShowMachineActors(BaseMachineComponent target)
		{
			// actor settings
			if(target.DisplayActor())
			{
				if(this.baseEditor.BeginFoldout("Actors", "", "", false))
				{
					for(int i = 0; i < target.actor.Length; i++)
					{
						if(this.baseEditor.BeginFoldout("Actor " + i +
							(target.assetSetting.schematicAsset.Settings.actor[i].setName ? 
								": " + target.assetSetting.schematicAsset.Settings.actor[i].actorName.Current.text : ""), "", "", true))
						{
							if(target.assetSetting.schematicAsset.Settings.actor[i].settings.EditorSelectGameObject)
							{
								if(target.actor[i].actor == null)
								{
									target.actor[i].actor = new GameObject[1];
								}
								if(EditorTool.Button(new GUIContent("Add Actor Object", EditorContent.Instance.AddIcon)))
								{
									ArrayHelper.Add(ref target.actor[i].actor, null);
								}
								for(int j = 0; j < target.actor[i].actor.Length; j++)
								{
									EditorGUILayout.BeginHorizontal();
									if(target.actor[i].actor.Length > 1)
									{
										if(EditorTool.Button(EditorContent.Instance.RemoveIcon, EditorTool.WIDTH_30))
										{
											ArrayHelper.RemoveAt(ref target.actor[i].actor, j);
											return;
										}
									}
									target.actor[i].actor[j] = (GameObject)EditorGUILayout.ObjectField(
										target.actor[i].actor[j], typeof(GameObject), true);
									EditorGUILayout.EndHorizontal();
								}
							}
							else
							{
								target.actor[i].actor = null;
								GUILayout.Label(target.assetSetting.schematicAsset.Settings.actor[i].settings.EditorName);
							}
						}
						this.baseEditor.EndFoldout();
					}
				}
				this.baseEditor.EndFoldout();
			}
		}

		protected virtual void ShowMachineResources(MachineResourcesSetting resources, SchematicSettings settings)
		{
			if(settings != null)
			{
				// check schematic asset file changes
				resources.CheckSchematic(settings);

				if(resources.prefab.Length > 0 ||
					resources.audioClip.Length > 0 ||
					resources.audioMixer.Length > 0 ||
					resources.audioMixerGroup.Length > 0 ||
					resources.sprite.Length > 0 ||
					resources.texture.Length > 0 ||
					resources.material.Length > 0 ||
					resources.physicMaterial.Length > 0 ||
					resources.physicsMaterial2D.Length > 0)
				{
					if(this.baseEditor.BeginFoldout("Resource Overrides", "", "", false))
					{
						// prefab settings
						if(resources.prefab.Length > 0)
						{
							if(this.baseEditor.BeginFoldout("Prefabs", "", "", true))
							{
								for(int i = 0; i < resources.prefab.Length; i++)
								{
									if(i < settings.prefab.Length && settings.prefab[i].name != "")
									{
										EditorTool.BoldLabel("Prefab " + i + ": " + settings.prefab[i].name);
									}
									else
									{
										EditorTool.BoldLabel("Prefab " + i);
									}
									EditorGUI.BeginChangeCheck();
									resources.prefab[i].useOwn = EditorGUILayout.Toggle(
										"Override Prefabs", resources.prefab[i].useOwn);
									if(EditorGUI.EndChangeCheck())
									{
										if(resources.prefab[i].useOwn)
										{
											resources.prefab[i].prefabs = new GameObject[0];
										}
										else
										{
											resources.prefab[i].prefabs = null;
										}
									}
									if(resources.prefab[i].useOwn)
									{
										EditorGUILayout.Separator();
										if(EditorTool.Button(new GUIContent("Add Prefab", EditorContent.Instance.AddIcon)))
										{
											ArrayHelper.Add(ref resources.prefab[i].prefabs, null);
										}
										for(int j = 0; j < resources.prefab[i].prefabs.Length; j++)
										{
											EditorGUILayout.BeginHorizontal();
											if(EditorTool.Button(EditorContent.Instance.RemoveIcon, EditorTool.WIDTH_30))
											{
												ArrayHelper.RemoveAt(ref resources.prefab[i].prefabs, j);
												return;
											}
											resources.prefab[i].prefabs[j] = (GameObject)EditorGUILayout.ObjectField(
												resources.prefab[i].prefabs[j], typeof(GameObject), false);
											EditorGUILayout.EndHorizontal();
										}
									}
								}
								EditorGUILayout.Separator();
							}
							this.baseEditor.EndFoldout();
						}

						// audio clips settings
						if(resources.audioClip.Length > 0)
						{
							if(this.baseEditor.BeginFoldout("Audio Clips", "", "", true))
							{
								for(int i = 0; i < resources.audioClip.Length; i++)
								{
									if(i < settings.audioClip.Length && settings.audioClip[i].name != "")
									{
										EditorTool.BoldLabel("Audio Clip " + i + ": " + settings.audioClip[i].name);
									}
									else
									{
										EditorTool.BoldLabel("Audio Clip " + i);
									}
									EditorGUI.BeginChangeCheck();
									resources.audioClip[i].useOwn = EditorGUILayout.Toggle(
										"Override Audio Clips", resources.audioClip[i].useOwn);
									if(EditorGUI.EndChangeCheck())
									{
										if(resources.audioClip[i].useOwn)
										{
											resources.audioClip[i].clips = new AudioClip[0];
										}
										else
										{
											resources.audioClip[i].clips = null;
										}
									}
									if(resources.audioClip[i].useOwn)
									{
										EditorGUILayout.Separator();
										if(EditorTool.Button(new GUIContent("Add Audio Clip", EditorContent.Instance.AddIcon)))
										{
											ArrayHelper.Add(ref resources.audioClip[i].clips, null);
										}
										for(int j = 0; j < resources.audioClip[i].clips.Length; j++)
										{
											EditorGUILayout.BeginHorizontal();
											if(EditorTool.Button(EditorContent.Instance.RemoveIcon, EditorTool.WIDTH_30))
											{
												ArrayHelper.RemoveAt(ref resources.audioClip[i].clips, j);
												return;
											}
											resources.audioClip[i].clips[j] = (AudioClip)EditorGUILayout.ObjectField(
												resources.audioClip[i].clips[j], typeof(AudioClip), false);
											EditorGUILayout.EndHorizontal();
										}
									}
								}
								EditorGUILayout.Separator();
							}
							this.baseEditor.EndFoldout();
						}

						// audio mixers settings
						if(resources.audioMixer.Length > 0)
						{
							if(this.baseEditor.BeginFoldout("Audio Mixers", "", "", true))
							{
								for(int i = 0; i < resources.audioMixer.Length; i++)
								{
									if(i < settings.audioMixer.Length && settings.audioMixer[i].name != "")
									{
										EditorTool.BoldLabel("Audio Mixer " + i + ": " + settings.audioMixer[i].name);
									}
									else
									{
										EditorTool.BoldLabel("Audio Mixer " + i);
									}
									EditorGUI.BeginChangeCheck();
									resources.audioMixer[i].useOwn = EditorGUILayout.Toggle(
										"Override Audio Mixers", resources.audioMixer[i].useOwn);
									if(EditorGUI.EndChangeCheck())
									{
										if(resources.audioMixer[i].useOwn)
										{
											resources.audioMixer[i].mixers = new AudioMixer[0];
										}
										else
										{
											resources.audioMixer[i].mixers = null;
										}
									}
									if(resources.audioMixer[i].useOwn)
									{
										EditorGUILayout.Separator();
										if(EditorTool.Button(new GUIContent("Add Audio Mixer", EditorContent.Instance.AddIcon)))
										{
											ArrayHelper.Add(ref resources.audioMixer[i].mixers, null);
										}
										for(int j = 0; j < resources.audioMixer[i].mixers.Length; j++)
										{
											EditorGUILayout.BeginHorizontal();
											if(EditorTool.Button(EditorContent.Instance.RemoveIcon, EditorTool.WIDTH_30))
											{
												ArrayHelper.RemoveAt(ref resources.audioMixer[i].mixers, j);
												return;
											}
											resources.audioMixer[i].mixers[j] = (AudioMixer)EditorGUILayout.ObjectField(
												resources.audioMixer[i].mixers[j], typeof(AudioMixer), false);
											EditorGUILayout.EndHorizontal();
										}
									}
								}
								EditorGUILayout.Separator();
							}
							this.baseEditor.EndFoldout();
						}

						// audio mixer groups settings
						if(resources.audioMixerGroup.Length > 0)
						{
							if(this.baseEditor.BeginFoldout("Audio Mixer Groups", "", "", true))
							{
								for(int i = 0; i < resources.audioMixerGroup.Length; i++)
								{
									if(i < settings.audioMixerGroup.Length && settings.audioMixerGroup[i].name != "")
									{
										EditorTool.BoldLabel("Audio Mixer Group " + i + ": " + settings.audioMixerGroup[i].name);
									}
									else
									{
										EditorTool.BoldLabel("Audio Mixer Group " + i);
									}
									EditorGUI.BeginChangeCheck();
									resources.audioMixerGroup[i].useOwn = EditorGUILayout.Toggle(
										"Override Audio Mixer Groups", resources.audioMixerGroup[i].useOwn);
									if(EditorGUI.EndChangeCheck())
									{
										if(resources.audioMixerGroup[i].useOwn)
										{
											resources.audioMixerGroup[i].mixerGroups = new AudioMixerGroup[0];
										}
										else
										{
											resources.audioMixerGroup[i].mixerGroups = null;
										}
									}
									if(resources.audioMixerGroup[i].useOwn)
									{
										EditorGUILayout.Separator();
										if(EditorTool.Button(new GUIContent("Add Audio Mixer Group", EditorContent.Instance.AddIcon)))
										{
											ArrayHelper.Add(ref resources.audioMixerGroup[i].mixerGroups, null);
										}
										for(int j = 0; j < resources.audioMixerGroup[i].mixerGroups.Length; j++)
										{
											EditorGUILayout.BeginHorizontal();
											if(EditorTool.Button(EditorContent.Instance.RemoveIcon, EditorTool.WIDTH_30))
											{
												ArrayHelper.RemoveAt(ref resources.audioMixerGroup[i].mixerGroups, j);
												return;
											}
											resources.audioMixerGroup[i].mixerGroups[j] = (AudioMixerGroup)EditorGUILayout.ObjectField(
												resources.audioMixerGroup[i].mixerGroups[j], typeof(AudioMixerGroup), false);
											EditorGUILayout.EndHorizontal();
										}
									}
								}
								EditorGUILayout.Separator();
							}
							this.baseEditor.EndFoldout();
						}

						// sprite settings
						if(resources.sprite.Length > 0)
						{
							if(this.baseEditor.BeginFoldout("Sprites", "", "", true))
							{
								for(int i = 0; i < resources.sprite.Length; i++)
								{
									if(i < settings.sprite.Length && settings.sprite[i].name != "")
									{
										EditorTool.BoldLabel("Sprite " + i + ": " + settings.sprite[i].name);
									}
									else
									{
										EditorTool.BoldLabel("Sprite " + i);
									}
									EditorGUI.BeginChangeCheck();
									resources.sprite[i].useOwn = EditorGUILayout.Toggle(
										"Override Sprites", resources.sprite[i].useOwn);
									if(EditorGUI.EndChangeCheck())
									{
										if(resources.sprite[i].useOwn)
										{
											resources.sprite[i].sprites = new Sprite[0];
										}
										else
										{
											resources.sprite[i].sprites = null;
										}
									}
									if(resources.sprite[i].useOwn)
									{
										EditorGUILayout.Separator();
										if(EditorTool.Button(new GUIContent("Add Sprite", EditorContent.Instance.AddIcon)))
										{
											ArrayHelper.Add(ref resources.sprite[i].sprites, null);
										}
										for(int j = 0; j < resources.sprite[i].sprites.Length; j++)
										{
											EditorGUILayout.BeginHorizontal();
											if(EditorTool.Button(EditorContent.Instance.RemoveIcon, EditorTool.WIDTH_30))
											{
												ArrayHelper.RemoveAt(ref resources.sprite[i].sprites, j);
												return;
											}
											resources.sprite[i].sprites[j] = (Sprite)EditorGUILayout.ObjectField(
												resources.sprite[i].sprites[j], typeof(Sprite), false);
											EditorGUILayout.EndHorizontal();
										}
									}
								}
								EditorGUILayout.Separator();
							}
							this.baseEditor.EndFoldout();
						}

						// texture settings
						if(resources.texture.Length > 0)
						{
							if(this.baseEditor.BeginFoldout("Textures", "", "", true))
							{
								for(int i = 0; i < resources.texture.Length; i++)
								{
									if(i < settings.texture.Length && settings.texture[i].name != "")
									{
										EditorTool.BoldLabel("Texture " + i + ": " + settings.texture[i].name);
									}
									else
									{
										EditorTool.BoldLabel("Texture " + i);
									}
									EditorGUI.BeginChangeCheck();
									resources.texture[i].useOwn = EditorGUILayout.Toggle(
										"Override Textures", resources.texture[i].useOwn);
									if(EditorGUI.EndChangeCheck())
									{
										if(resources.texture[i].useOwn)
										{
											resources.texture[i].textures = new Texture[0];
										}
										else
										{
											resources.texture[i].textures = null;
										}
									}
									if(resources.texture[i].useOwn)
									{
										EditorGUILayout.Separator();
										if(EditorTool.Button(new GUIContent("Add Texture", EditorContent.Instance.AddIcon)))
										{
											ArrayHelper.Add(ref resources.texture[i].textures, null);
										}
										for(int j = 0; j < resources.texture[i].textures.Length; j++)
										{
											EditorGUILayout.BeginHorizontal();
											if(EditorTool.Button(EditorContent.Instance.RemoveIcon, EditorTool.WIDTH_30))
											{
												ArrayHelper.RemoveAt(ref resources.texture[i].textures, j);
												return;
											}
											resources.texture[i].textures[j] = (Texture)EditorGUILayout.ObjectField(
												resources.texture[i].textures[j], typeof(Texture), false);
											EditorGUILayout.EndHorizontal();
										}
									}
								}
								EditorGUILayout.Separator();
							}
							this.baseEditor.EndFoldout();
						}

						// material settings
						if(resources.material.Length > 0)
						{
							if(this.baseEditor.BeginFoldout("Materials", "", "", true))
							{
								for(int i = 0; i < resources.material.Length; i++)
								{
									if(i < settings.material.Length && settings.material[i].name != "")
									{
										EditorTool.BoldLabel("Material " + i + ": " + settings.material[i].name);
									}
									else
									{
										EditorTool.BoldLabel("Material " + i);
									}
									EditorGUI.BeginChangeCheck();
									resources.material[i].useOwn = EditorGUILayout.Toggle(
										"Override Materials", resources.material[i].useOwn);
									if(EditorGUI.EndChangeCheck())
									{
										if(resources.material[i].useOwn)
										{
											resources.material[i].materials = new Material[0];
										}
										else
										{
											resources.material[i].materials = null;
										}
									}
									if(resources.material[i].useOwn)
									{
										EditorGUILayout.Separator();
										if(EditorTool.Button(new GUIContent("Add Material", EditorContent.Instance.AddIcon)))
										{
											ArrayHelper.Add(ref resources.material[i].materials, null);
										}
										for(int j = 0; j < resources.material[i].materials.Length; j++)
										{
											EditorGUILayout.BeginHorizontal();
											if(EditorTool.Button(EditorContent.Instance.RemoveIcon, EditorTool.WIDTH_30))
											{
												ArrayHelper.RemoveAt(ref resources.material[i].materials, j);
												return;
											}
											resources.material[i].materials[j] = (Material)EditorGUILayout.ObjectField(
												resources.material[i].materials[j], typeof(Material), true);
											EditorGUILayout.EndHorizontal();
										}
									}
								}
								EditorGUILayout.Separator();
							}
							this.baseEditor.EndFoldout();
						}

						// physic material settings
						if(resources.physicMaterial.Length > 0)
						{
							if(this.baseEditor.BeginFoldout("Physic Materials", "", "", true))
							{
								for(int i = 0; i < resources.physicMaterial.Length; i++)
								{
									if(i < settings.physicMaterial.Length && settings.physicMaterial[i].name != "")
									{
										EditorTool.BoldLabel("Physic Material " + i + ": " + settings.physicMaterial[i].name);
									}
									else
									{
										EditorTool.BoldLabel("Physic Material " + i);
									}
									EditorGUI.BeginChangeCheck();
									resources.physicMaterial[i].useOwn = EditorGUILayout.Toggle(
										"Override Physic Materials", resources.physicMaterial[i].useOwn);
									if(EditorGUI.EndChangeCheck())
									{
										if(resources.physicMaterial[i].useOwn)
										{
#if Unity_2019
											resources.physicMaterial[i].materials = new PhysicMaterial[0];
#else
											resources.physicMaterial[i].materials = new PhysicsMaterial[0];
#endif
										}
										else
										{
											resources.physicMaterial[i].materials = null;
										}
									}
									if(resources.physicMaterial[i].useOwn)
									{
										EditorGUILayout.Separator();
										if(EditorTool.Button(new GUIContent("Add Physic Material", EditorContent.Instance.AddIcon)))
										{
											ArrayHelper.Add(ref resources.physicMaterial[i].materials, null);
										}
										for(int j = 0; j < resources.physicMaterial[i].materials.Length; j++)
										{
											EditorGUILayout.BeginHorizontal();
											if(EditorTool.Button(EditorContent.Instance.RemoveIcon, EditorTool.WIDTH_30))
											{
												ArrayHelper.RemoveAt(ref resources.physicMaterial[i].materials, j);
												return;
											}
#if Unity_2019
											resources.physicMaterial[i].materials[j] = (PhysicMaterial)EditorGUILayout.ObjectField(
												resources.physicMaterial[i].materials[j], typeof(PhysicMaterial), true);
#else
											resources.physicMaterial[i].materials[j] = (PhysicsMaterial)EditorGUILayout.ObjectField(
												resources.physicMaterial[i].materials[j], typeof(PhysicsMaterial), true);
#endif
											EditorGUILayout.EndHorizontal();
										}
									}
								}
								EditorGUILayout.Separator();
							}
							this.baseEditor.EndFoldout();
						}

						// physics material 2D settings
						if(resources.physicsMaterial2D.Length > 0)
						{
							if(this.baseEditor.BeginFoldout("Physics Material 2Ds", "", "", true))
							{
								for(int i = 0; i < resources.physicsMaterial2D.Length; i++)
								{
									if(i < settings.physicsMaterial2D.Length && settings.physicsMaterial2D[i].name != "")
									{
										EditorTool.BoldLabel("Physics Material 2D " + i + ": " + settings.physicsMaterial2D[i].name);
									}
									else
									{
										EditorTool.BoldLabel("Physics Material 2D " + i);
									}
									EditorGUI.BeginChangeCheck();
									resources.physicsMaterial2D[i].useOwn = EditorGUILayout.Toggle(
										"Override Physics Material 2Ds", resources.physicMaterial[i].useOwn);
									if(EditorGUI.EndChangeCheck())
									{
										if(resources.physicsMaterial2D[i].useOwn)
										{
											resources.physicsMaterial2D[i].materials = new PhysicsMaterial2D[0];
										}
										else
										{
											resources.physicsMaterial2D[i].materials = null;
										}
									}
									if(resources.physicsMaterial2D[i].useOwn)
									{
										EditorGUILayout.Separator();
										if(EditorTool.Button(new GUIContent("Add Physics Material 2D", EditorContent.Instance.AddIcon)))
										{
											ArrayHelper.Add(ref resources.physicsMaterial2D[i].materials, null);
										}
										for(int j = 0; j < resources.physicsMaterial2D[i].materials.Length; j++)
										{
											EditorGUILayout.BeginHorizontal();
											if(EditorTool.Button(EditorContent.Instance.RemoveIcon, EditorTool.WIDTH_30))
											{
												ArrayHelper.RemoveAt(ref resources.physicsMaterial2D[i].materials, j);
												return;
											}
											resources.physicsMaterial2D[i].materials[j] = (PhysicsMaterial2D)EditorGUILayout.ObjectField(
												resources.physicsMaterial2D[i].materials[j], typeof(PhysicsMaterial2D), true);
											EditorGUILayout.EndHorizontal();
										}
									}
								}
								EditorGUILayout.Separator();
							}
							this.baseEditor.EndFoldout();
						}
						EditorGUILayout.Separator();
					}
					this.baseEditor.EndFoldout();
				}
			}
		}
	}
}
