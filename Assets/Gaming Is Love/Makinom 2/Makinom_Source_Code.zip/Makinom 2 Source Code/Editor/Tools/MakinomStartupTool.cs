﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	[InitializeOnLoad]
	public class MakinomStartupTool
	{
		static MakinomStartupTool()
		{
			EditorApplication.playModeStateChanged += MakinomStartupTool.PlayModeStateChanged;
		}

		private static void PlayModeStateChanged(PlayModeStateChange state)
		{
			if(PlayModeStateChange.ExitingEditMode == state)
			{
				VisibilityCheck.ClearInstance();
				if(Maki.Initialized)
				{
					Maki.Game.Running = false;
					Maki.MachineHandler.ClearDebug();
					Maki.Clear(true, false, true);
					GameStarter.Reinitialize = true;
				}
			}
			else if(PlayModeStateChange.ExitingPlayMode == state)
			{
				if(Maki.Initialized)
				{
					Maki.Game.Running = false;
                    Maki.MachineHandler.StopAll();
					Maki.Pooling.Clear(true);
				}
				if(AssetSourceCache.Initialized)
				{
					AssetSourceCache.Instance.Clear(true, true);
				}
			}
			else if(PlayModeStateChange.EnteredEditMode == state)
			{
				VisibilityCheck.ClearInstance();
				if(Maki.Initialized)
				{
					Maki.Clear(true, false, true);
				}
				MakinomGenericAssetCache.Clear();
			}
		}
	}
}
