
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	public class AttributeHelper
	{
		public EditorHelpAttribute help;

		public int hide = 0;

		public int highlightSettings = -1;

		public EditorInfoAttribute info;

		public EditorWidthAttribute width;

		public EditorLimitAttribute limit;

		public EditorArrayAttribute array;

		public EditorReflectionFieldAttribute reflection;


		// layout
		public EditorFoldoutAttribute foldout;

		public EditorEndFoldoutAttribute endFoldout;

		public int separator = 0;

		public int indent = 0;

		public EditorTitleLabelAttribute titleLabel;

		public EditorLabelAttribute label;

		public EditorCombinedFieldAttribute combinedField;


		// conditions
		public EditorConditionAttribute[] condition;

		public EditorConditionCallbackAttribute[] conditionCallback;

		public EditorElseConditionAttribute elseCondition;

		public EditorEndConditionAttribute endCondition;

		public EditorAutoInitAttribute autoInit;

		public EditorDefaultValueAttribute defaultValue;

		public EditorAssetSelectionConditionAttribute assetSelectionCondition;


		// callbacks
		public EditorCallbackAttribute[] callback;

		public AttributeHelper()
		{

		}

		public void BeforeField(IBaseData instance, BaseEditor baseEditor)
		{
			if(this.separator > 0)
			{
				for(int i = 0; i < this.separator; i++)
				{
					EditorGUILayout.Separator();
				}
			}
			if(this.indent > 0)
			{
				EditorGUI.indentLevel += this.indent;
			}

			// labels
			if(this.titleLabel != null)
			{
				EditorTool.BoldLabel(this.titleLabel.text);
			}
			if(this.label != null)
			{
				EditorGUILayout.HelpBox(this.label.text, MessageType.Info, true);
			}

			this.Callback(instance, baseEditor, EditorCallbackType.Before);
		}

		public void AfterField(IBaseData instance, BaseEditor baseEditor)
		{
			this.Callback(instance, baseEditor, EditorCallbackType.After);

			if(this.indent > 0)
			{
				EditorGUI.indentLevel -= this.indent;
			}
		}


		/*
		============================================================================
		Foldout functions
		============================================================================
		*/
		public void BeginFoldout(IBaseData contextInstance, BaseEditor baseEditor, bool ignoreHide, ref bool blockFoldout)
		{
			if(this.foldout != null)
			{
				blockFoldout = this.endFoldout != null &&
					baseEditor.checkGroupStack.Count > 0 &&
					!baseEditor.checkGroupStack.Peek();
				if(!blockFoldout &&
					(this.endFoldout == null || (this.hide == 0 || (ignoreHide && this.hide == 1))))
				{
					if(this.foldout.subFoldouts != null)
					{
						baseEditor.BeginFoldout(this.foldout.content, this.foldout.info, this.foldout.initialState);

						int index = 0;
						int max = this.foldout.subFoldouts.Length / 3;
						for(int i = 0; i < max; i++)
						{
							index = i * 3;
							if(contextInstance != null &&
								i == max - 1)
							{
								EditorAutomation.StartContextClick(baseEditor, contextInstance, false);
							}
							baseEditor.BeginFoldout(
								this.foldout.subFoldouts[index],
								this.foldout.subFoldouts[index + 1],
								this.foldout.subFoldouts[index + 2], true);
						}
					}
					else
					{
						if(contextInstance != null)
						{
							EditorAutomation.StartContextClick(baseEditor, contextInstance, false);
						}
						baseEditor.BeginFoldout(this.foldout.content, this.foldout.info, this.foldout.initialState);
					}
				}
			}
		}

		public void EndFoldout(IBaseData contextInstance, BaseEditor baseEditor, bool blockFoldout)
		{
			if(this.endFoldout != null)
			{
				for(int i = blockFoldout ? 1 : 0; i < this.endFoldout.count; i++)
				{
					baseEditor.EndFoldout();
					if(contextInstance != null)
					{
						EditorAutomation.EndContextClick(baseEditor, contextInstance, false);
						contextInstance = null;
					}
				}
			}
		}


		/*
		============================================================================
		Condition functions
		============================================================================
		*/
		public void StartConditions(IBaseData instance, BaseEditor baseEditor)
		{
			// conditions
			if((this.condition != null &&
					this.condition.Length > 0) ||
				(this.conditionCallback != null &&
					this.conditionCallback.Length > 0))
			{
				if(baseEditor.checkGroupStack.Count == 0 || baseEditor.checkGroupStack.Peek())
				{
					baseEditor.checkGroupStack.Push(
						this.CheckConditions(instance, baseEditor));
				}
				else
				{
					baseEditor.checkGroupStack.Push(false);
				}
			}
			// else condition
			if(this.elseCondition != null &&
				baseEditor.checkGroupStack.Count > 0)
			{
				bool checkGroup = baseEditor.checkGroupStack.Pop();
				if(baseEditor.checkGroupStack.Count == 0 || baseEditor.checkGroupStack.Peek())
				{
					baseEditor.checkGroupStack.Push(!checkGroup);
				}
				else
				{
					baseEditor.checkGroupStack.Push(checkGroup);
				}
			}
		}

		public bool CheckConditions(IBaseData instance, BaseEditor baseEditor)
		{
			if(this.condition != null)
			{
				for(int i = 0; i < this.condition.Length; i++)
				{
					if(EditorAutomation.CheckConditions(instance,
						this.condition[i].checkField,
						this.condition[i].fieldValue,
						Needed.All))
					{
						return true;
					}
				}
			}
			if(this.conditionCallback != null)
			{
				for(int i = 0; i < this.conditionCallback.Length; i++)
				{
					if(baseEditor.AutomationCheck(this.conditionCallback[i].callback))
					{
						return true;
					}
				}
			}
			return false;
		}

		public void EndConditions(BaseEditor baseEditor)
		{
			if(this.endCondition != null &&
				baseEditor.checkGroupStack.Count > 0)
			{
				for(int i = 0; i < this.endCondition.count; i++)
				{
					baseEditor.checkGroupStack.Pop();
				}
			}
		}

		public void AutoInit(IBaseData instance, FieldInfo fieldInfo, bool valid)
		{
			if(this.autoInit != null)
			{
				if(valid)
				{
					if(fieldInfo.GetValue(instance) == null)
					{
						if(fieldInfo.FieldType.IsArray)
						{
							if(fieldInfo.FieldType.GetElementType().Equals(typeof(int)))
							{
								fieldInfo.SetValue(instance, new int[this.autoInit.autoSize]);
							}
							else if(fieldInfo.FieldType.GetElementType().Equals(typeof(float)))
							{
								fieldInfo.SetValue(instance, new float[this.autoInit.autoSize]);
							}
							else if(fieldInfo.FieldType.GetElementType().Equals(typeof(bool)))
							{
								fieldInfo.SetValue(instance, new bool[this.autoInit.autoSize]);
							}
							else
							{
								if(this.autoInit.constTypes != null &&
									this.autoInit.constValues != null)
								{
									fieldInfo.SetValue(instance,
										ArrayHelper.CreateArray(this.autoInit.autoSize,
											fieldInfo.FieldType.GetElementType(), fieldInfo.FieldType,
											this.autoInit.constTypes, this.autoInit.constValues));
								}
								else
								{
									fieldInfo.SetValue(instance,
										ArrayHelper.CreateArray(this.autoInit.autoSize,
											fieldInfo.FieldType.GetElementType(), fieldInfo.FieldType));
								}
							}
						}
						else if(this.autoInit.constTypes != null &&
							this.autoInit.constValues != null)
						{
							fieldInfo.SetValue(instance,
								ReflectionTypeHandler.Instance.CreateInstance(fieldInfo.FieldType,
									this.autoInit.constTypes, this.autoInit.constValues));
						}
						else
						{
							fieldInfo.SetValue(instance,
								ReflectionTypeHandler.Instance.CreateInstance(fieldInfo.FieldType));
						}
					}
				}
				else if(fieldInfo.GetValue(instance) != null)
				{
					fieldInfo.SetValue(instance, null);
				}
			}
			else if(!valid &&
				this.defaultValue != null)
			{
				fieldInfo.SetValue(instance, this.defaultValue.value);
			}
		}


		/*
		============================================================================
		Callback functions
		============================================================================
		*/
		public void Callback(IBaseData instance, BaseEditor baseEditor, EditorCallbackType type)
		{
			if(this.callback != null)
			{
				for(int i = 0; i < this.callback.Length; i++)
				{
					if(this.callback[i].type == type)
					{
						if(EditorCallbackType.InstanceBefore == type ||
							EditorCallbackType.InstanceAfter == type)
						{
							baseEditor.InstanceCallback(this.callback[i].info, instance);
						}
						else
						{
							baseEditor.AutomationCallback(this.callback[i].info);
						}
					}
				}
			}
		}

		public void CombinedField(IBaseData instance, BaseEditor baseEditor, bool showRest)
		{
			if(this.combinedField != null)
			{
				if(baseEditor.isInspector)
				{
					try
					{
						bool foundFirst = false;
						int tmpIndent = EditorGUI.indentLevel;
						if(this.combinedField.noInspectorHorizontal)
						{
							for(int i = 0; i < this.combinedField.field.Length; i++)
							{
								int index = this.combinedField.field[i].LastIndexOf(".");
								if(index != -1)
								{
									object tmpInstance = null;
									ReflectionTypeHandler.GetFieldValue(out tmpInstance, instance,
										this.combinedField.field[i].Substring(0, index));
									if(tmpInstance != null &&
										tmpInstance is IBaseData)
									{
										EditorAutomation.Automate(
											this.combinedField.field[i].Substring(index + 1),
											(IBaseData)tmpInstance, baseEditor, true);
									}
								}
								else
								{
									EditorAutomation.Automate(this.combinedField.field[i], instance, baseEditor, true);
								}
								if(!foundFirst &&
									!baseEditor.inspectorHideNextName)
								{
									foundFirst = true;
									EditorGUI.indentLevel++;
								}
							}
						}
						else
						{
							EditorGUILayout.BeginHorizontal();
							EditorTool.Title(this.help.content, this.help.info);
							EditorGUI.indentLevel = 0;
							baseEditor.inspectorHideNextName = true;
							for(int i = 0; i < this.combinedField.field.Length; i++)
							{
								int index = this.combinedField.field[i].LastIndexOf(".");
								if(index != -1)
								{
									object tmpInstance = null;
									ReflectionTypeHandler.GetFieldValue(out tmpInstance, instance,
										this.combinedField.field[i].Substring(0, index));
									if(tmpInstance != null &&
										tmpInstance is IBaseData)
									{
										EditorAutomation.Automate(
											this.combinedField.field[i].Substring(index + 1),
											(IBaseData)tmpInstance, baseEditor, true);
									}
								}
								else
								{
									EditorAutomation.Automate(this.combinedField.field[i], instance, baseEditor, true);
								}
								if(!foundFirst &&
									!baseEditor.inspectorHideNextName)
								{
									foundFirst = true;
									EditorGUILayout.EndHorizontal();
									EditorGUI.indentLevel++;
								}
							}
						}
						EditorGUI.indentLevel = tmpIndent;

						if(showRest)
						{
							EditorAutomation.Automate(instance, baseEditor);
						}
					}
					catch(System.Exception ex)
					{
						EditorGUIUtility.ExitGUI();
					}
				}
				else
				{
					try
					{
						EditorGUILayout.BeginHorizontal();
						if(this.width == null ||
							!this.width.hideName)
						{
							EditorTool.Title(this.help.content, this.help.info);
						}
						int tmpIndent = EditorGUI.indentLevel;
						EditorGUI.indentLevel = 0;
						for(int i = 0; i < this.combinedField.field.Length; i++)
						{
							int index = this.combinedField.field[i].LastIndexOf(".");
							if(index != -1)
							{
								object tmpInstance = null;
								ReflectionTypeHandler.GetFieldValue(out tmpInstance, instance,
									this.combinedField.field[i].Substring(0, index));
								if(tmpInstance != null &&
									tmpInstance is IBaseData)
								{
									EditorAutomation.Automate(
										this.combinedField.field[i].Substring(index + 1),
										(IBaseData)tmpInstance, baseEditor, true);
								}
							}
							else
							{
								EditorAutomation.Automate(this.combinedField.field[i], instance, baseEditor, true);
							}
						}
						if(this.combinedField.flexibleSpace)
						{
							GUILayout.FlexibleSpace();
						}
						EditorGUI.indentLevel = tmpIndent;
						EditorGUILayout.EndHorizontal();

						if(showRest)
						{
							EditorAutomation.Automate(instance, baseEditor);
						}
					}
					catch(System.Exception ex)
					{
						EditorGUIUtility.ExitGUI();
					}
				}
			}
			else
			{
				EditorAutomation.Automate(instance, baseEditor, true);
			}
		}
	}
}
